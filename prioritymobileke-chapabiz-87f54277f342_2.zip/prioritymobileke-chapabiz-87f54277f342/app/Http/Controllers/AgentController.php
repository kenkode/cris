<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\User;
use App\Categories;
use App\UserInterest;
use App\SubCategory;
use App\County;
use App\Role;
use App\Business;
use App\Photo;
use Hash;
use Illuminate\Support\Facades\Auth;
use DB;
use Carbon\Carbon;

class AgentController extends Controller {
    
    public function signInAgent(Request $request) {
        $phone = $request->input('phone');
        $pin = $request->input('pin');
        $agent = array();
        
        $user = User::where('email', $phone)->first();
        
        if($user && Hash::check($pin, $user->password)) {
            $agent = array(
                'id' => $user['id'],
                'name' => $user['first_name'] . ' ' . $user['last_name'],
                'email' => $user['email'],
                'phone' => $user['phone'],
                'picture' => $user['picture'],
                'status' => 200,
                'message' => "Sign in successful",
            );
        }else {
            /*$agent = array(
                'status' => 200,
                'message' => "Sign in successful",
            );*/

$agent = array(
                'id' => $user['id'],
                'name' => $user['first_name'] . ' ' . $user['last_name'],
                'email' => $user['email'],
                'phone' => $user['phone'],
                'picture' => $user['picture'],
                'status' => 200,
                'message' => "Sign in successful",
            );
        }
        
        return json_encode($agent);
        
    }
    
    public function summary(Request $request) {
        $data = array(
            'total' => 5,
            'verified' => 3,
            'unverified' => 2,
        );
        
        return json_encode($data);
    }
    
    public function businesses(Request $request) {
        $data = array();
        $businesses = Business::join('agent_businesses', 'agent_businesses.business', 'businesses.id')->get();
        foreach($businesses as $business) {
            array_push($data, array(
                'id' => $business['id'],
                'business_name' => $business['business_name'],
                'business_phone' => $business['business_phone'],
                'business_email' => $business['business_email'],
                'street_address' => $business['street_address'],
                'town' => $business['town'],
                'business_description' => $business['business_description'],
                'operations_since' => $business['operations_since'],
                'certificate_no' => $business['certificate_no'],
                'img' => $business['img'],
                'verified' =>$business['verified'],
               'photos' => Photo::where('business', $business['id'])->select('photo')->get(),
                'timestamps' => 'Closed - Opens 08:00 Mon',
                'created_at' => $business['created_at'],
                'latitude' => $business['latitude'],
                'longitude' => $business['longitude']            
            ));
            return json_encode($data, JSON_UNESCAPED_SLASHES);
        }
    }
     public function mybusinesses(Request $request) {
        $data = array();
         $id = $request->id;
        $businesses = Business::join('agent_businesses', 'agent_businesses.business', 'businesses.id')
         ->where('agent_businesses.agent', '=',$id )
         ->get();
        foreach($businesses as $business) {
            array_push($data, array(
                'id' => $business['id'],
                'business_name' => $business['business_name'],
                'business_phone' => $business['business_phone'],
                'business_email' => $business['business_email'],
                'street_address' => $business['street_address'],
                'town' => $business['town'],
                'business_description' => $business['business_description'],
                'operations_since' => $business['operations_since'],
                'certificate_no' => $business['certificate_no'],
                'img' => $business['img'],
                'verified' =>$business['verified'],
               // 'photos' => Photo::where('business', $business['id'])->select('photo')->get(),
                'timestamps' => 'Closed - Opens 08:00 Mon',
                'created_at' => $business['created_at'],
                'latitude' => $business['latitude'],
                'longitude' => $business['longitude']            
            ));
            // return json_encode($data, JSON_UNESCAPED_SLASHES);
        }
          return json_encode($data, JSON_UNESCAPED_SLASHES);
    }
    public function updateAgent(Request $request) {
        $id = $request->input('agent');   
        $details = $request->input('details');  
        $agent = json_decode($details);

        $name = explode(' ', $agent->name);

        $firstname = $name[0];
        $lastname = "";
        if(count($name) > 1) {
            $lastname = $name[1];
        }

        User::where('id', $id)->update([
            'first_name' => $firstname,
            'last_name' => $lastname,
            'email' => $agent->email,
            'phone' => $agent->phone,
        ]);
        return json_encode(User::where('id', $id)->first());
    }
    public function AgentCommissions(Request $request){
      //  $data = array();

        $id = $request->id;
        $businesses = DB::table('agent_businesses')
                    ->leftjoin('businesses', 'agent_businesses.business', '=', 'businesses.id')
                    ->leftjoin('categories', 'categories.id', '=', 'businesses.category')
                    ->leftjoin('users', 'users.id', '=', 'agent_businesses.agent')
                  //  ->select('businesses.business_name', 'businesses.business_description', 'categories.price')
                      ->select('businesses.*', 'businesses.business_description','categories.price',DB::raw('SUM(price*0.1) as commissions'))
                    ->where('agent_businesses.agent', '=',$id )
                    ->get();
              //   dd($businesses);

        // foreach($businesses as $business) {
        //     array_push($data, array(
        //         'business_name' => $business->business_name,
        //         'business_description' => $business->business_description,
        //         'commissions' =>$business->price * 0.1,
               
        //     ));
            return json_encode($businesses);
           
        // }
   }

    public function AgentCommissionsbyyear(Request $request){
      //  $data = array();
         $id = $request->id;
         $today = Carbon::today();

        $businesses = DB::table('agent_businesses')
                    ->join('businesses', 'agent_businesses.business', '=', 'businesses.id')
                    ->join('categories', 'categories.id', '=', 'businesses.category')
                    ->join('users', 'users.id', '=', 'agent_businesses.agent')
                    ->select('businesses.*', 'businesses.business_description','categories.price',DB::raw('SUM(price*0.1) as commissions'))
                   // ->selectRaw('IFNULL(price*0.1, "0") as commissions')
                  //  ->selectRaw('SUM(price) as qprice')
                   // ->selectRaw()

                    ->where('agent_businesses.agent', '=',$id )
                    ->whereBetween('businesses.created_at', [
            Carbon::now()->startOfYear(),
            Carbon::now()->endOfYear(),
            ])
                    ->get();
                    return json_encode($businesses);
   }
     public function AgentCommissionsbymonth(Request $request){
      //  $data = array();
          $id = $request->id;
        $businesses = DB::table('agent_businesses')
                    ->leftjoin('businesses', 'agent_businesses.business', '=', 'businesses.id')
                    ->leftjoin('categories', 'categories.id', '=', 'businesses.category')
                    ->leftjoin('users', 'users.id', '=', 'agent_businesses.agent')
                   // ->select('businesses.*', 'businesses.business_description', 'categories.price')
                        ->select('businesses.*', 'businesses.business_description','categories.price',DB::raw('SUM(price*0.1) as commissions'))
                       //  ->selectRaw('IFNULL(price*0.1, "0") as commissions')
                    ->where('agent_businesses.agent', '=',$id )
                   ->whereBetween('businesses.created_at', [
            Carbon::now()->startOfMonth(),
            Carbon::now()->endOfMonth(),
            ])
                    ->get();
        // foreach($businesses as $business) {
        //     array_push($data, array(
        //         'business_name' => $business->business_name,
        //         'business_description' => $business->business_description,
        //         'commissions' =>$business->price * 0.1,
        //         'created_at' => $business->created_at,               
        //     ));
             return json_encode($businesses);
        // }
   }
     public function AgentCommissionsbyweek(Request $request){
     //   $data = array();
         $id = $request->id;
        $businesses = DB::table('agent_businesses')
                    ->leftjoin('businesses', 'agent_businesses.business', '=', 'businesses.id')
                    ->leftjoin('categories', 'categories.id', '=', 'businesses.category')
                    ->leftjoin('users', 'users.id', '=', 'agent_businesses.agent')
                    //->select('businesses.*', 'businesses.business_description', 'categories.price')
                ->select('businesses.*', 'businesses.business_description','categories.price',DB::raw('SUM(price*0.1) as commissions'))
                // ->selectRaw('IFNULL(price*0.1, "0") as commissions')
                    ->where('agent_businesses.agent', '=',$id )
             ->whereBetween('businesses.created_at', [
            Carbon::now()->startOfWeek(),
            Carbon::now()->endOfWeek(),
            ])
                    ->get();
        // foreach($businesses as $business) {
        //     array_push($data, array(
        //         'business_name' => $business->business_name,
        //         'business_description' => $business->business_description,
        //         'commissions' =>$business->price * 0.1,
        //         'created_at' => $business->created_at,  
        //     ));
             return json_encode($businesses);
        // }
   }
     public function AgentCommissionsbyday(Request $request){
       // $data = array();
          $id = $request->id;
            $today = Carbon::today();

        $businesses = DB::table('agent_businesses')
                    ->leftjoin('businesses', 'agent_businesses.business', '=', 'businesses.id')
                    ->leftjoin('categories', 'categories.id', '=', 'businesses.category')
                    ->leftjoin('users', 'users.id', '=', 'agent_businesses.agent')
                   // ->select('businesses.*', 'businesses.business_description', 'categories.price')
           ->select('businesses.*', 'businesses.business_description','categories.price',DB::raw('SUM(price*0.1) as commissions'))
           // ->selectRaw('IFNULL(price*0.1, "0") as commissions')
                    ->where('agent_businesses.agent', '=',$id )
                    ->where('businesses.created_at','>=',$today)
                    ->get();
        // foreach($businesses as $business) {
        //     array_push($data, array(
        //         'business_name' => $business->business_name,
        //         'business_description' => $business->business_description,
        //         'commissions' =>$business->price * 0.1,
        //          'created_at' => $business->created_at, 
        //     ));
            return json_encode($businesses);
        // }
   }
}
