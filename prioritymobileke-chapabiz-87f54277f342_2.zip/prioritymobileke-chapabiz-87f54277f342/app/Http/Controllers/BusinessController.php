<?php

namespace App\Http\Controllers;

use App\Business;
use App\Categories;
use App\County;
use Auth;
use Hash;
use DB;
use Illuminate\Support\Facades\Input;
use App\Photo;
use App\User;
use App\Invoice;
use App\Location;

use Illuminate\Http\Request;

class BusinessController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        if(Auth::user()->role=='Agent'){

           $data['businesses']=Business::where('verified','=',Auth::user()->id)
                                         ->orWhere('verified','=',0)
                                         ->get();
        }elseif(Auth::user()->role=='Owner'){
        $data['businesses']=Business::where('owner_id','=',Auth::user()->id)->get();

        }else{

           $data['businesses']=Business::all();

        }


        return view('businesses.index',$data);
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        if(Auth::user()->role!='Owner'){
          $data['owner_id']=$_REQUEST['owner_id'];
        }


        $data['categories']=Categories::all();
        $data['counties']=County::all();
        return view('businesses.create',$data);
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $cert=Controller::upload_file($request);
        if($file=$request->file('img'))$img= Controller::upload_img($file); else $img= "";

        if(Auth::user()->role=='Agent'||Auth::user()->role=='Administrator'){
            $verified=Auth::user()->id;
        }else{
            $verified=0;
        }

        $business=Business::create(['business_name'=>$request->business_name,'owner_id'=>$request->owner_id,'category'=>$request->category, 'business_phone'=>$request->business_phone, 'business_email'=>$request->business_email, 'street_address'=>$request->street_address, 'town'=>$request->town, 'county'=>$request->county,'business_description'=>$request->business_description, 'operations_since'=>$request->operations_since, 'certificate_no'=>$request->certificate_no, 'certificate_copy'=>$cert, 'img'=>$img, 'verified'=>$verified]);

        $amount=Categories::find($request->category)->price;

        $vat=(16/100)*$amount;

        $balance=$amount+$vat;

        Invoice::create(['user_id'=>$request->owner_id,'business_id'=>$business->id,'amount'=>$amount,'balance'=>$balance,'status'=>'Pending']);


           return redirect('business');


    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Business  $business
     * @return \Illuminate\Http\Response
     */
    public function show(Business $business)
    {
        $data['business']=$business;


        return view('businesses.show',$data);
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Business  $business
     * @return \Illuminate\Http\Response
     */
    public function edit(Business $business)
    {
        $data['business']=$business;
        $data['categories']=Categories::all();
        $data['counties']=County::all();

        return view('businesses.edit',$data);
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Business  $business
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, Business $business)
    {



        if($file=$request->file('img')){
          $img= Controller::upload_img($file);
          $business->update(array('img'=>$img));

        }

        if($file2=$request->file('thefile')){
          $cert= Controller::upload_img($file2);
          $business->update(array('certificate_copy'=>$cert));

        }

        $business->update(['business_name'=>$request->business_name,'owner_id'=>$request->owner_id,'category'=>$request->category, 'business_phone'=>$request->business_phone, 'business_email'=>$request->business_email, 'street_address'=>$request->street_address, 'town'=>$request->town, 'county'=>$request->county,'business_description'=>$request->business_description, 'operations_since'=>$request->operations_since, 'certificate_no'=>$request->certificate_no]);


           return redirect('business');

    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Business  $business
     * @return \Illuminate\Http\Response
     */
    public function destroy(Business $business)
    {
        $business->delete();

           return redirect('business');

    }

    public function verify($id)
    {

        $business=Business::find($id);
        $business->update(['verified'=>Auth::user()->id]);

           return redirect('business');

    }

    public function per_region()
    {

        $county=$_REQUEST['region'];

        $data['county']=$county;
        $data['businesses']=Business::where('county','=',$county)->get();



        return view('businesses.per_region',$data);



    }

    //    Chapabiz application(Android) - eddie
//    Business Sign In
//    Phone and Pin

    public function signUpBusiness(Request $request) {
        $details = $request->input('business');
        $business = json_decode($details);
        $data = array();

        if(Business::where('business_email', $business->business_email)->exists()) {
            $data['status'] = 301;
            $data['message'] = "Business email exists";
        }else if(Business::where('business_phone', $business->business_phone)->exists()) {
            $data['status'] = 301;
            $data['message'] = "Business phone exists";
        }else {
            $newBusiness = new Business();
            $newBusiness->business_name = $business->business_name;
            $newBusiness->category = $business->category;
            $newBusiness->business_email = $business->business_email;
            $newBusiness->county = $business->county_name;
            $newBusiness->business_description = $business->business_description;
            $newBusiness->state = 1;
            $newBusiness->save();

            $location = new Location();
            $location->business = $newBusiness->id;
            $location->latitude = $business->latitude;
            $location->longitude = $business->longitude;
            $location->save();


            $data['status'] = 200;
            $data['message'] = "Business Created Successfully";
            $data['business'] = $business;
        }
        return json_encode($data);

    }

    public function signInBusiness(Request $request) {
        $data = array();
        $phone = $request->input('phone');
        $pin = $request->input('pin');
        $email = "";

//        Get email
        $business = Business::where('business_phone', $phone)->first();
        if($business == null) {
            $data['status'] = 404;
            $data['message'] = "Business not registered!";
            return json_encode($data);
        }else {
            $email = $business['business_email'];
        }
        $user   = User::where('email', $email)->first();
        $photos = Photo::where('business', $business->id)->select('id', 'photo')->get();

        if($user && Hash::check($pin, $user->password)) {
            $data['status'] = 200;
            $data['message'] = "Successfully logged in!";
            $imagePath = $business['img'];
            $business['img'] = env('APP_URL') . '/storage/business/images/' . $imagePath;
            $data['business'] = $business;
            $data['photos']   = $photos;
        }else {
            $data['status'] = 302;
            $data['message'] = "Wrong credentials! Please try again";
        }

        return json_encode($data, JSON_UNESCAPED_SLASHES);

    }

    public function updateBusiness(Request $request) {
        $businessString = $request->input('business');
        $id = $request->input('id');
        $business = json_decode($businessString);

        Business::where('id', $id)->update([
            'business_name' => $business->business_name,
//            'category' => $business->category,
            'business_email' => $business->business_email,
//            'county' => $business->county_name,
            'business_phone' => $business->business_phone,
            'business_description' => $business->business_description,
        ]);
//        name, email, phone, region, years,

    }

    public function updateBusinessStatusForShopper(Request $request) {
        // $status = $request->input('state');
        // $id = $request->input('id');

        // Business::where('id', $id)->update([
        //     'state' => $status,
        // ]);

        //new 
        // public function setInterests(Request $request) {
        $user = $request->input('id');
        $business = $request->input('business');
        $state = $request->input('state');
        $data = array(
            'user' => $user,
            'category' => $business
        );
        $insertData = array(
            'user' => $user,
            'category' => $business,
            'active' => $state,
        );

        if(UserInterest::where($data)->exists()) {
            UserInterest::where($data)->update([
               'active' => $state
            ]);
        }else {
            UserInterest::create($insertData);
        }

   // }

    }

    public function updateBusinessStatus(Request $request) {
        $status = $request->input('state');
        $id = $request->input('id');

        Business::where('id', $id)->update([
            'state' => $status,
        ]);

    }
//tbc
    public function updateBusinessVerification(Request $request){
        $id = $request->input('id');

            Business::where('id', $id)->update([
            'verified' => $id,
        ]);

    }

    public function getConversations() {

    }

    public function uploadFile(Request $request) {
        $docFile = $request->file('file');
        $business = $request->input('business');
        $type = $request->input('type');
       // Input::file('file');\
      //  $docFile = Input::file('file');
        $docPath = uniqid() . '.' . $docFile->getClientOriginalExtension();

        switch($type) {
            case 0:
                $docFile->move(storage_path('app/public') . '/businesses/logos/', $docPath);
                Business::where('id', $business)->update([
                    'img' => $docPath
                ]);
                echo $docPath;
                break;
            case 22:
                $docFile->move(storage_path('app/public') . '/businesses/files/', $docPath);
                Business::where('id', $business)->update([
                    'certificate_copy' => $docPath
                ]);
                echo $docFile->getClientOriginalName();
                break;
             case 25:
                $docFile->move(storage_path('app/public') . '/businesses/images/', $docPath);
                Photo::create([
                    'business' => $business,
                    'photo' => $docPath

                ]);
               // echo $docFile->getClientOriginalName();
                echo $docPath;
                break;
        }

    }

    public function uploadPhoto(Request $request) {
        $bs = $request->input('id');

        $path = $request->input('picture')->store('/businesses/images');

        Photo::create([
            'business' => $bs,
            'photo' => $path
        ]);

    }

    public function recordSearch() {

    }

    public function getSubCategories() {
        $categories = SubCategory::orderby('name', 'asc')->get();
        return json_encode($categories);
    }

    public function getPhotos(Request $request) {
        $id = $request->input('id');
        $photos = Photo::where('business', $id)->select('id', 'photo')->get();
        return json_encode($photos, JSON_UNESCAPED_SLASHES);
    }

    public function deletePhoto(Request $request) {
        $id = $request->input('id');
        Photo::where('id', $id)->delete();
    }

    public function getChats(Request $request) {
        $user = $request->input('user');
        $users = User::select('id', 'first_name as name', 'created_at as time_stamp')->whereNotIn('id', [$user])->get();
   //   ->get();
        ///->whereNotIn('id', [$user])->get();
        return json_encode($users);
    }

    
//count chats
     public function getTotalBusinessChats(Request $request) {
        $user = $request->input('user');
        $users = DB::table('chat_rooms')->get();
      //  ->count();
      //  ->get()->count();
      //  $prescriptionstots = DB::table('prescriptions')
//->select(DB::raw('count(prescriptions.id) as totprescriptions'))
          $array = array();
        $array['users']=$users;
        $array['count']=count($users);



        return json_encode($array);
    }


    public function addChat(Request $request) {
        $user = $request->input('user');
        $rec = $request->input('rec');

        $data = array(
            'user' => $user,
            'rec' => $rec
        );

        if(!Chat::where($data)->exists()) {
            Chat::create($data);
        }

    }

    public function getCounties() {
        $counties = County::select('id', 'county_name as name')->get();
        return json_encode($counties);
    }


}
