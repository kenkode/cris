<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Auth;
use App\User;
use App\County;
use App\Categories;
use App\Business;
class HomeController extends Controller
{
    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct()
    {
        $this->middleware('auth');
    }

    /**
     * Show the application dashboard.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        
        $data['categories']=Categories::all();

        if(Auth::user()->role=="Administrator"){
          $data['agents']=User::where('role','=','Agent')->get();
          $data['users']=User::where('role','=','Agent')->get();
          $data['counties']=County::all();
          return view('admin',$data);   
        }elseif(Auth::user()->role=="Agent"){

          $data['bussinesses']=Business::where('verified','=',Auth::user()->id)->get();
          return view('agent',$data);   
        }elseif(Auth::user()->role=="Owner"){
          return view('owner',$data);   
        }
             

    }
}
