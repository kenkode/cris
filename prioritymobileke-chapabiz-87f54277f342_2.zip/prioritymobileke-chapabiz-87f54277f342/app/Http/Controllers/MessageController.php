<?php

namespace App\Http\Controllers;

use App\Message;
use Illuminate\Http\Request;
use Auth;
use App\Business;
use App\User;

class MessageController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
       if(Auth::user()->role=='Owner')
       {

        $data['messages']=Message::select('messages.*')
                                 ->join('businesses','businesses.id','=','messages.business_id')
                                 ->where('businesses.owner_id','=',Auth::user()->id)
                                 ->get();
       }else{

        $data['messages']=Message::all();
       }
        

        return view('messages.index',$data);
    }

    public function ccare()
    {
       if(Auth::user()->role=='Owner')
       {

        $data['messages']=Message::select('messages.*')
                                 ->join('businesses','businesses.id','=','messages.business_id')
                                 ->where('businesses.owner_id','=',Auth::user()->id)
                                 ->get();
       }
       elseif(Auth::user()->role=='Agent')
       {

        $data['messages']=Message::select('messages.*')                                 
                                 ->where('user_id','=',Auth::user()->id)
                                 ->get();
       }else{

        $data['messages']=Message::all();
       }
        

        return view('messages.ccare',$data);
    }



    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
       
       $biz_id= $_REQUEST['biz_id'];

       $data['business']=Business::find($biz_id);
       $data['owner']=User::find($data['business']->owner_id);

        return view('messages.create',$data);
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        Message::create($request->all());

       return redirect()->back();
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Message  $message
     * @return \Illuminate\Http\Response
     */
    public function show(Message $message)
    {
        $message->update(['status'=>'read']);

        $data['message']=$message;

        return view('messages.show',$data);
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Message  $message
     * @return \Illuminate\Http\Response
     */
    public function edit(Message $message)
    {
        $data['message']=$message;

        return view('messages.edit',$data);
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Message  $message
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, Message $message)
    {
     
      $message->update(['replied'=>1]);
    Controller::send_mail(Auth::user()->email,Auth::user()->first_name,$request->email,$request->msg_title,$request->msg_body);
    Message::create($request->all());

       return redirect('messages');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Message  $message
     * @return \Illuminate\Http\Response
     */
    public function destroy(Message $message)
    {
        //
    }

    public function delete($id)
    {
        Message::find($id)->delete();

        return redirect('meassages');
    }
}

