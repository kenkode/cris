<?php

namespace App\Http\Controllers;
use App\Business;
use App\Categories;
use App\County;
use Auth;
use App\User;
use App\Invoice;

use Illuminate\Http\Request;
class OwnersController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        $data['categories']=Categories::all();
        $data['counties']=County::all();
        return view('owners.create',$data);
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $this->validate($request,[
            'first_name' => 'required|string|max:255',
            'last_name' => 'required|string|max:255',
            'email' => 'required|string|email|max:255|unique:users',
            'password' => 'required|string|min:6|confirmed',
        ]);

         $user=User::create([
            'first_name' => $request->first_name,
            'last_name' => $request->last_name,
            'email' => $request->email,
            'role' => 'Owner',         
            'gender' => $request->gender, 
            'nat_id' => $request->nat_id,    
            'password' => bcrypt($request->password)
            
        ]); 

         $cert=Controller::uploadFile($request);

      if($file=$request->file('img'))$img= Controller::upload_img($file); else $img= "";

    $business=Business::create(['business_name'=>$request->business_name,'owner_id'=>$user->id, 'category'=>$request->category, 'business_phone'=>$request->business_phone, 'business_email'=>$request->business_email, 'street_address'=>$request->street_address, 'town'=>$request->town, 'county'=>$request->county,'business_description'=>$request->business_description, 'operations_since'=>$request->operations_since, 'certificate_no'=>$request->certificate_no, 'certificate_copy'=>$cert,'img'=>$img, 'verified'=>0]);

      $amount=Categories::find($request->category)->price;

        $vat=(16/100)*$amount;

        $balance=$amount+$vat;
 
       
        Invoice::create(['user_id'=>$user->id,'business_id'=>$business->id,'amount'=>$amount,'balance'=>$balance,'status'=>'Pending']);


          Auth::login($user);
          return redirect('home');

    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //
    }


   
}


