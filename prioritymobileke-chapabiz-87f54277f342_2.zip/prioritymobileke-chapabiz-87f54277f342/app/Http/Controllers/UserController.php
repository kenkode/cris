<?php

namespace App\Http\Controllers;


use Illuminate\Http\Request;
use App\User;
use App\Photo;
use App\Categories;
use App\County;
use App\Role;
use App\SubCategory;
use App\UserInterest;
use App\Business;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Hash;
class UserController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        if(Auth::user()->role=='Agent'){

          $data['users']= User::where('role','=','Owner')->get();
        }
        else{

            $data['users']= User::all();
            $data['owners']= User::where('role','=','Owner')->get();
            $data['agents']= User::where('role','=','Agent')->get();
            $data['admins']= User::where('role','=','Administrator')->get();
        }



    return view('users.index',$data);

    }



    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
       $data['roles']=Role::all();
       return view('users.create',$data);
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request ,User $user)
    {
        $this->validate($request,[
            'first_name' => 'required|string|max:255',
            'last_name' => 'required|string|max:255',
            'email' => 'required|string|email|max:255|unique:users',
            'password' => 'required|string|min:6|confirmed',
        ]);

         $user=User::create([
            'first_name' => $request->first_name,
            'last_name' => $request->last_name,
            'email' => $request->email,
            'role' => $request->role,
            'gender' => $request->gender,
            'nat_id' => $request->nat_id,
            'password' => bcrypt($request->password)

        ]);

        if(Auth::user()->role=='Agent') {
            $data['owner_id']=$user->id;
            $data['categories']=Categories::all();
            $data['counties']=County::all();
            return view('businesses.create',$data);
        }else{
           return redirect('users');
        }


    }

    public function register_supplier(Request $request)
    {
        $token=str_random(60);
        $user = new User;
        $insert=$user->create_user($request->name,$request->email,$request->phone,$request->password,$request->role);

        return redirect('welcome');

    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit( User $user)
    {
         $data['user'] = $user;
         $data['roles']=Role::all();

        return view('users.edit',$data);
    }



    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, User $user)
    {


        $update=$user->update(array('first_name'=>$request->first_name,'last_name'=>$request->last_name,'nat_id'=>$request->nat_id,'email'=>$request->email,'phone_number'=>$request->phone_number,'postal_address'=>$request->postal_address,'role'=>$request->role,'county'=>$request->county));


        return redirect('users');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {

        user::find($id)->delete();
        $data['status'] = 'User deleted!';
        $data['status_class'] = 'alert-success';

        return redirect('users')->with($data);
    }



    public static function name_by_id($id)
    {

      $data = User::select('*')
               ->where('id', '=', $id)
               ->get();

    return $data[0]->name;

    }

    public function profile()
    {

        $data['user']=Auth::user();

        return view('users.profile',$data);


    }

    public function profile_edit()
    {

        $data['user']=Auth::user();

        return view('users.profile_edit',$data);
    }

    public function profile_update(Request $request)
    {
        $user=Auth::user();

        $user->update($request->all());

        return redirect('profile');

    }

    public function password_edit()
    {
        $data['user']=Auth::user();

        return view('users.password_edit',$data);;

    }

    public function password_update(Request $request)
    {
        $user=Auth::user();
         $this->validate($request,[
            'password' => 'required|string|min:6|confirmed',
        ]);




     if (Hash::check($request->current_password, $user->password)) {

         $user->update(['password' => bcrypt($request->password)]);

               flash('Password changed')->success()->important();
                return redirect('password-edit');

            } else {

                flash('Current Password is incorrect')->error()->important();
               return redirect('password-edit');
            }


    }

     public function signInShopper(Request $request) {
        $method = $request->input('method');
        $json = $request->input('shopper');
        $shopper = json_decode($json);

        switch($method) {
            case "google":
                if(User::where('email', $shopper->email)->exists()) {
                    $getUser = User::where('email', $shopper->email)->first();

                    $user = array();
                    $user['id'] = $getUser['id'];
                    $user['gender'] = $getUser['gender'];
                    $user['email'] = $getUser['email'];
                    $user['picture'] = $getUser['picture'];
                    $user['name'] = $getUser['first_name'] . ' ' . $getUser['last_name'];
                    $user['status'] = 200;
                    return json_encode($user, JSON_UNESCAPED_SLASHES);
                }else {
                    $user = new User();
                    $name = $shopper->name;
                    $names = explode(' ',$name);
                    $user->first_name = $names[0];
                    if(count($names) > 1) {
                        $user->last_name = $names[1];
                    }
                    $user->gender = $shopper->gender;
                    $user->email = $shopper->email;
                    $user->picture = $shopper->picture;
                    $user->save();
                    $user->name = $user->first_name . ' ' . $user->last_name;
                    $user->status = 200;
                    return json_encode($user, JSON_UNESCAPED_SLASHES);
                }
                break;
            case "facebook":
             if(User::where('email', $shopper->email)->exists()) {
                    $getUser = User::where('email', $shopper->email)->first();

                    $user = array();
                    $user['id'] = $getUser['id'];
                    $user['gender'] = $getUser['gender'];
                    $user['email'] = $getUser['email'];
                    $user['picture'] = $getUser['picture'];
                    $user['name'] = $getUser['first_name'] . ' ' . $getUser['last_name'];
                    $user['status'] = 200;
                    return json_encode($user, JSON_UNESCAPED_SLASHES);
                }else {
                    $user = new User();
                    $name = $shopper->name;
                    $names = explode(' ', $name);
                    $user->first_name = $name;
                    if(count($names) > 1) {
                        $user->last_name = $names[1];
                    }
                    $user->gender = $shopper->gender;
                    $user->email = $shopper->email;
                    $user->picture = $shopper->picture;
                    $user->save();
                    $user->name = $user->first_name . ' ' . $user->last_name;
                    $user->status = 200;
                    return json_encode($user, JSON_UNESCAPED_SLASHES);
                }
                break;
            case "email":
                if(User::where('email', $shopper->email)->exists()) {
                    $getUser = User::where('email', $shopper->email)->first();

                    $user = array();
                    $user['id'] = $getUser['id'];
                   // $user['gender'] = $getUser['gender'];
                    $user['email'] = $getUser['email'];
                  //  $user['picture'] = $getUser['picture'];
                    // $user['name'] = $getUser['first_name'] . ' ' . $getUser['last_name'];
                    $user['first_name'] = $getUser['first_name'];
                    $user['last_name'] = $getUser['last_name'];
                    $user['status'] = 200;
                    return json_encode($user, JSON_UNESCAPED_SLASHES);
                }else {
                    $user = new User();

                    $user->first_name = $shopper->first_name;
                    $user->last_name = $shopper->last_name;
                    $user->email = $shopper->email;
                    $user->password = bcrypt($shopper->password);
                    $user->save();
                    //$user->name = $user->first_name . ' ' . $user->last_name;
                    $user->status = 200;
                    return json_encode($user, JSON_UNESCAPED_SLASHES);
                }
                break;
        }

    }

    public function getCategories(Request $request) {
        $user = $request->input('id');
        $results = array();
        $categories = Categories::all();
        foreach($categories as $category) {
            $interest = array();
            $interestDetails = array();
            $interest['name'] = $category['name'];
            $subCategories = SubCategory::where('category', $category['id'])->get();
            foreach($subCategories as $subCategory) {
                $hasSelected = UserInterest::where('user', $user)->where('category', $subCategory['id'])->where('active', 1)->exists();
                $subCat = array(
                    'id' => $subCategory['id'],
                    'name' => $subCategory['name'],
                    'photo' => $subCategory['photo'],
                    'selected' => $hasSelected
                );
                //array_push($interestDetails, $subCat);
                array_push($results, $subCat);
            }


            //$interest['interest_list'] = $interestDetails;
            //array_push($results, $interest);
        }

        return json_encode($results);

    }

    //android subcats

    public function getSubCategories() {


        $categories = SubCategory::select('id', 'name')

        ->get();
        return json_encode($categories);
    }
     public function getSubCategories1() {

          $id = 1;
        // $categories = SubCategory::select('id', 'name')
        // ->where('id','=',$id)
        // ->get();

         $businesses = Business::select('businesses.id' )->where('category', $id)
            ->select('businesses.id', 'business_name', 'business_phone', 'business_email')
            ->get();
        return json_encode($businesses);
    }
     public function getSubCategories2() {
        $id = 2;
        $businesses = Business::select('businesses.id' )->where('category', $id)
            ->select('businesses.id', 'business_name', 'business_phone', 'business_email')

            ->get();
        return json_encode($businesses);
    }
     public function getSubCategories3() {
        $id = 3;
       $businesses = Business::select('businesses.id' )->where('category', $id)
            ->select('businesses.id', 'business_name', 'business_phone', 'business_email')
            ->get();
        return json_encode($businesses);
    }
     public function getSubCategories4() {
         $id = 4;
       $businesses = Business::select('businesses.id' )->where('category', $id)
            ->select('businesses.id', 'business_name', 'business_phone', 'business_email')
            ->get();
        return json_encode($businesses);
    }
     public function getSubCategories5() {
         $id = 5;
        $businesses = Business::select('businesses.id' )->where('category', $id)
            ->select('businesses.id', 'business_name', 'business_phone', 'business_email')
            ->get();
        return json_encode($businesses);
    }
      public function getSubCategories6() {
         $id = 6;
        $businesses = Business::select('businesses.id' )->where('category', $id)
            ->select('businesses.id', 'business_name', 'business_phone', 'business_email')
            ->get();
        return json_encode($businesses);
    }

  public function getSubCategories7() {
         $id = 7;
        $businesses = Business::select('businesses.id' )->where('category', $id)
            ->select('businesses.id', 'business_name', 'business_phone', 'business_email')
            ->get();
        return json_encode($businesses);
    }
      public function getSubCategories8() {
         $id = 8;
        $businesses = Business::select('businesses.id' )->where('category', $id)
            ->select('businesses.id', 'business_name', 'business_phone', 'business_email')
            ->get();
        return json_encode($businesses);
    }
      public function getSubCategories9() {
         $id = 9;
        $businesses = Business::select('businesses.id' )->where('category', $id)
            ->select('businesses.id', 'business_name', 'business_phone', 'business_email')
            ->get();
        return json_encode($businesses);
    }
       public function getChapaBizs() {
         
        $businesses = Business::select('businesses.id' )
            ->select('businesses.id', 'business_name', 'business_phone', 'business_email')
            ->get();
        return json_encode($businesses);
    }
    public function getInterests(Request $request) {
        $user = $request->input('id');

        $interests = UserInterest::join('sub_categories', 'sub_categories.id', 'user_interests.category')
        ->where('user', $user)->where('user_interests.active', 1)
        ->select('sub_categories.id', 'sub_categories.name')->get();

        return json_encode($interests);
    }
      public function getBusinessInterests(Request $request) {
        $user = $request->input('id');

        $interests = UserInterest::join('businesses', 'businesses.id', 'user_interests.category')
        ->where('user', $user)->where('user_interests.active', 1)
        ->select('businesses.id', 'businesses.business_name')->get();

        return json_encode($interests);
    }

    public function setInterests(Request $request) {
        $user = $request->input('id');
        $interest = $request->input('interest');
        $state = $request->input('state');
        $data = array(
            'user' => $user,
            'category' => $interest
        );
        $insertData = array(
            'user' => $user,
            'category' => $interest,
            'active' => $state,
        );

        if(UserInterest::where($data)->exists()) {
            UserInterest::where($data)->update([
               'active' => $state
            ]);
        }else {
            UserInterest::create($insertData);
        }

    }

    public function getBusinesses(Request $request) {
        $interest = $request->input('interest');
        $businesses = Business::join('locations', 'businesses.id', 'locations.business')->where('category', $interest)->where("state",1)
            ->select('businesses.id', 'business_name', 'business_phone', 'business_email', 'street_address', 'town', 'business_description', 'operations_since', 'certificate_no', 'img', 'businesses.created_at', 'latitude', 'longitude')
            ->get();

        $data = array();

        foreach($businesses as $business) {
            array_push($data, array(
                'id' => $business['id'],
                'business_name' => $business['business_name'],
                'business_phone' => $business['business_phone'],
                'business_email' => $business['business_email'],
                'street_address' => $business['street_address'],
                'town' => $business['town'],
                'business_description' => $business['business_description'],
                'operations_since' => $business['operations_since'],
                'certificate_no' => $business['certificate_no'],
                'img' => $business['img'],
                //'photos' => Photo::where('business', $business['id'])->select('photo')->get(),
                'timestamps' => 'Closed - Opens 08:00 Mon',
                'created_at' => $business['created_at'],
                'latitude' => $business['latitude'],
                'longitude' => $business['longitude']
            ));
        }

        //calculate opens closes when

        // Format
        // Closed - Opens 08:00 Mon
        // Closes Soon - 21:00
        // Open - Closes 22:00


        echo json_encode($data);
        //get business using sub_categories
    }
      public function getAllBusinesses() {

        $businesses = Business::select('businesses.id' )
            ->select('businesses.id', 'business_name', 'business_phone', 'business_email')

            ->get();
        return json_encode($businesses);
    }

    public function getChatUsers(Request $request) {

    }

    public function getPhotos(Request $request) {

    }

      public function getNewAccount(Request $request) {
        // $details = $request->input('shopper');
        // $user = json_decode($details);
        // $data = array();

        // if(User::where('email', $user->email)->exists()) {
        //     $data['status'] = 301;
        //     $data['message'] = "User email exists";
        // // }else if(User::where('phone', $business->business_phone)->exists()) {
        // //     $data['status'] = 301;
        // //     $data['message'] = "Business phone exists";
        // }else {
        //     $newShopper = new User();
        //     $newShopper->first_name = $user->first_name;
        //     $newShopper->last_name = $user->last_name;
        //     $newShopper->email = $user->email;

        //     $newShopper->save();

        //     $data['status'] = 200;
        //     $data['message'] = "User Account created Successfully";
        //     $data['user'] = $user;
        // }
        // return json_encode($data);

        //sai tu
          $details = $request->input('shopper');
        $shopper = json_decode($details);
        $data = array();

        if(User::where('email', $business->email)->exists()) {
            $data['status'] = 301;
            $data['message'] = "User email exists";
        }else if(User::where('phone', $shopper->phone)->exists()) {
            $data['status'] = 301;
            $data['message'] = "User phone exists";
        }else {
            $newShopper = new User();
            $newShopper->first_name = $user->first_name;
            $newShopper->last_name = $user->last_name;
            //$newShopper->category = $business->category;
            $newShopper->email = $user->email;
           //ad paswd
           //  $user->password = bcrypt($user->password);

            $newShopper->save();

            $data['status'] = 200;
            $data['message'] = "User Account Created Successfully";
            $data['shopper'] = $user;
        }
        return json_encode($data);

    }

}





