<?php

namespace App\Http\Models;

use Illuminate\Database\Eloquent\Model;

class Chat extends Model
{
    protected $table = "chat_rooms";
    protected $fillable=['user', 'rec'];
}
