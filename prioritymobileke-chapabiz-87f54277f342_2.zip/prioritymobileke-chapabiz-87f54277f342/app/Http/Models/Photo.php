<?php

namespace App\Http\Models;

use Illuminate\Database\Eloquent\Model;

class Photo extends Model
{
    protected $fillable=['business', 'url'];
}
