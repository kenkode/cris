<?php

namespace App\Http\Models;

use Illuminate\Database\Eloquent\Model;

class UserInterest extends Model
{
    protected $fillable=['user','category', 'active'];
}
