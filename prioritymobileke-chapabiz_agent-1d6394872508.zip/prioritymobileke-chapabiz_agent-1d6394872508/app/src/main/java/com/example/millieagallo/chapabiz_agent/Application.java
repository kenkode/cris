package com.example.millieagallo.chapabiz_agent;

import com.qiscus.sdk.Qiscus;

import com.example.millieagallo.chapabiz_agent.helpers.CbSession;

public class Application extends android.app.Application {

    public static final String TAG = Application.class
            .getSimpleName();

    private static Application mInstance;

    private CbSession pref;

    @Override
    public void onCreate() {
        super.onCreate();
        mInstance = this;
        Qiscus.init(this, getResources().getString(R.string.qiscus_api));
    }

    public static synchronized Application getInstance() {
        return mInstance;
    }

    public CbSession getPrefManager() {
        if (pref == null) {
            pref = new CbSession(this);
        }

        return pref;
    }
}