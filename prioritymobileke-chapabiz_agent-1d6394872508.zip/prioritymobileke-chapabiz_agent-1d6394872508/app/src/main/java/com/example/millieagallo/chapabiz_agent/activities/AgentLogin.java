package com.example.millieagallo.chapabiz_agent.activities;

import android.app.ProgressDialog;
import android.content.Intent;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.content.pm.Signature;
import android.os.Bundle;
import android.support.v4.content.ContextCompat;
import android.support.v7.app.AppCompatActivity;
import android.text.InputType;
import android.text.TextUtils;
import android.util.Base64;
import android.util.Log;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.Toast;

import com.facebook.AccessToken;
import com.facebook.AccessTokenTracker;
import com.facebook.CallbackManager;
import com.facebook.FacebookCallback;
import com.facebook.FacebookException;
import com.facebook.GraphRequest;
import com.facebook.GraphResponse;
import com.facebook.login.LoginManager;
import com.facebook.login.LoginResult;
import com.facebook.login.widget.LoginButton;
import com.google.android.gms.auth.api.signin.GoogleSignIn;
import com.google.android.gms.auth.api.signin.GoogleSignInAccount;
import com.google.android.gms.auth.api.signin.GoogleSignInClient;
import com.google.android.gms.auth.api.signin.GoogleSignInOptions;
import com.google.android.gms.common.SignInButton;
import com.google.android.gms.common.api.ApiException;
import com.google.android.gms.tasks.Task;
import com.google.gson.Gson;

import org.json.JSONObject;

import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.ArrayList;
import java.util.Arrays;

import com.example.millieagallo.chapabiz_agent.R;
import com.example.millieagallo.chapabiz_agent.agent.Agent;
import com.example.millieagallo.chapabiz_agent.agent.activities.AgentActivity;
import com.example.millieagallo.chapabiz_agent.agent.activities.AgentHome;
import com.example.millieagallo.chapabiz_agent.business.activities.BusinessActivity;
import com.example.millieagallo.chapabiz_agent.business.activities.SignUpActivity;
import com.example.millieagallo.chapabiz_agent.entities.Response;
import com.example.millieagallo.chapabiz_agent.helpers.CbSession;
//import com.example.millieagallo.chapabiz_agent.helpers.LoginUserSelect;
import com.example.millieagallo.chapabiz_agent.retrofit.RetrofitSetup;
//import com.example.millieagallo.chapabiz_agent.shopper.activities.UserHome;
//import com.example.millieagallo.chapabiz_agent.shopper.entities.Shopper;
import retrofit2.Call;
import retrofit2.Callback;
//
//import static ke.co.prioritymobile.chapabiz.helpers.CbSession.FACEBOOK;
//import static ke.co.prioritymobile.chapabiz.helpers.CbSession.GOOGLE;

/**
 * Created by Millie Agallo on 4/16/2018.
 */

public class AgentLogin extends AppCompatActivity  {

    private CallbackManager callbackManager;
    private static final String EMAIL = "email";
    private static final String BUSINESS_TAG = "business_tag";
    private static final String AGENT_TAG = "agent_tag";
    private static final String SHOPPER_TAG = "shopper_tag";
    private static final int RC_SIGN_IN = 1001;
    private LoginButton loginButton;
    private SignInButton signInButton;
    private GoogleSignInClient googleSignInClient;
    private Button businessButton, agentButton, shopperButton, createAccount;
    private EditText username, password;
    ArrayList<Button> buttons;
    private LinearLayout orContainer, socialContainer;
  //  private LoginUserSelect loginUserSelect;
    private AccessTokenTracker accessTokenTracker;
    private Button signUpBusiness;
   // private Button signUpBusiness;

    CbSession session;

    @Override

    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_agent_login);


//        FacebookSdk.sdkInitialize(getApplicationContext());
//        AppEventsLogger.activateApp(this);

        session = new CbSession(this);

        loginButton = (LoginButton) findViewById(R.id.login_button);
        signInButton = (SignInButton) findViewById(R.id.sign_in_button);

    //    signUpBusiness = (Button) findViewById(R.id.sign_up_business);

        username = (EditText) findViewById(R.id.username);
        password = (EditText) findViewById(R.id.password);

        signInButton = (SignInButton) findViewById(R.id.sign_in_button);
        createAccount = (Button) findViewById(R.id.create_account);

     //   signUpBusiness = (Button) findViewById(R.id.sign_up_business);

        ImageView imageView = (ImageView) findViewById(R.id.back);

        imageView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
               // startActivity(new Intent(AgentLogin.this, MainLogin.class));
            }
        });

//        signUpBusiness.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View view) {
//                startActivity(new Intent(AgentLogin.this, SignUpActivity.class));
//            }
//        });


        createAccount.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String m = username.getText().toString();
                String p = password.getText().toString();

                if (TextUtils.isEmpty(m) || TextUtils.isEmpty(p)) {
                    Toast.makeText(AgentLogin.this, "Provide credentials", Toast.LENGTH_SHORT).show();
                    return;
                }


                        String agentPhone = username.getText().toString().trim();
                        String agentPin = password.getText().toString().trim();
                        final ProgressDialog progressDialog1 = new ProgressDialog(AgentLogin.this);
                        progressDialog1.setIndeterminate(true);
                        progressDialog1.setMessage("Authenticating..");
                        progressDialog1.show();
                        Call<Agent> agentCall = RetrofitSetup.retrofitInterface.signInAgent(agentPhone, agentPin);
                        agentCall.enqueue(new Callback<Agent>() {
                            @Override
                            public void onResponse(Call<Agent> call, retrofit2.Response<Agent> response) {
                                if (response.isSuccessful()) {
                                    Agent agent = response.body();
                                    if (agent.getStatus() == 200) {
                                        session.setAgent(agent);
                                        session.setSignInMethod(EMAIL);
                                        startActivity(new Intent(AgentLogin.this, AgentHome.class));
                                    }
                                    Toast.makeText(AgentLogin.this, agent.getMessage(), Toast.LENGTH_SHORT).show();
                                } else {
                                    Toast.makeText(AgentLogin.this, "Could not sign you at the moment", Toast.LENGTH_SHORT).show();
                                }
                                progressDialog1.dismiss();
                            }

                            @Override
                            public void onFailure(Call<Agent> call, Throwable t) {
                                t.printStackTrace();
                                progressDialog1.dismiss();
                                Toast.makeText(AgentLogin.this, "Could not sign you at the moment", Toast.LENGTH_SHORT).show();
                            }
                        });

                }
//                finish();

        });

        updateInput();

    }
    @Override
    protected void onStart() {
        super.onStart();

                if (session.getAgent() != null) {
                    startActivity(new Intent(AgentLogin.this, AgentHome.class));
                    finish();
                }

    }

    public void updateInput() {


                password.setHint("Agent Password");
                username.setHint("Agent Email");
                username.setInputType(InputType.TYPE_TEXT_VARIATION_EMAIL_ADDRESS);

    }

}

