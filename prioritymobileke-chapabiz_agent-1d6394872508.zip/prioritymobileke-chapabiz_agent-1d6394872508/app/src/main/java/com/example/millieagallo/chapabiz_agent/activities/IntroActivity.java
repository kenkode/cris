package com.example.millieagallo.chapabiz_agent.activities;

import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.support.annotation.ColorInt;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.support.v4.content.ContextCompat;
import android.widget.ImageView;

import com.example.millieagallo.chapabiz_agent.agent.Agent;
import com.github.paolorotolo.appintro.AppIntro;
import com.github.paolorotolo.appintro.AppIntroFragment;
import com.github.paolorotolo.appintro.ISlideBackgroundColorHolder;

import com.example.millieagallo.chapabiz_agent.R;
import com.example.millieagallo.chapabiz_agent.helpers.CbSession;

public class IntroActivity extends AppIntro implements ISlideBackgroundColorHolder {

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        setFadeAnimation();

        addSlide(AppIntroFragment.newInstance(" ", "Businesses, Shoppers, Agents", R.drawable.splashscreen,
                ContextCompat.getColor(this, R.color.colorPrimary)));

        addSlide(AppIntroFragment.newInstance(" ", "Connect with sellers of unique products", R.drawable.splashscreen,
                ContextCompat.getColor(this, R.color.colorPrimary)));

        addSlide(AppIntroFragment.newInstance(" ", "Connect with sellers of unique products", R.drawable.splashscreen,
                ContextCompat.getColor(this, R.color.colorPrimary)));

        showSkipButton(true);
        setProgressButtonEnabled(true);

    }

    @Override
    public void onSkipPressed(Fragment currentFragment) {
        super.onSkipPressed(currentFragment);
        CbSession session = new CbSession(this);
        session.setFirstTimeIntro(false);
        startActivity(new Intent(IntroActivity.this, AgentLogin.class));
        finish();
    }

    @Override
    public void onDonePressed(Fragment currentFragment) {
        super.onDonePressed(currentFragment);
        CbSession session = new CbSession(this);
        session.setFirstTimeIntro(false);
        startActivity(new Intent(IntroActivity.this, AgentLogin.class));
        finish();
    }

    @Override
    public void onSlideChanged(@Nullable Fragment oldFragment, @Nullable Fragment newFragment) {
        super.onSlideChanged(oldFragment, newFragment);
    }

    @Override
    public int getDefaultBackgroundColor() {
        return Color.parseColor("#3c48b8");
    }

    @Override
    public void setBackgroundColor(@ColorInt int backgroundColor) {
        // Set the background color of the view within your slide to which the transition should be applied.
//        if (layoutContainer != null) {
//            layoutContainer.setBackgroundColor(backgroundColor);
//        }
    }

}