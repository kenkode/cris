package com.example.millieagallo.chapabiz_agent.activities;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

import com.github.paolorotolo.appintro.AppIntro;

import com.example.millieagallo.chapabiz_agent.helpers.CbSession;

public class SplashScreen extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        CbSession session = new CbSession(this);
        if(session.isFirstTimeIntro()) {
            startActivity(new Intent(SplashScreen.this, IntroActivity.class));
        }else {
            startActivity(new Intent(SplashScreen.this, AgentLogin.class));
       }
        finish();
    }
}
