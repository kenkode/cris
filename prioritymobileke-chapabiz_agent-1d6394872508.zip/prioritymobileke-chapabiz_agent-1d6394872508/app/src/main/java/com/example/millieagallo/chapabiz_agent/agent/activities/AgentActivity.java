package com.example.millieagallo.chapabiz_agent.agent.activities;

import android.app.ProgressDialog;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.support.design.widget.FloatingActionButton;
import android.support.design.widget.Snackbar;
import android.support.v4.app.FragmentTransaction;
import android.support.v4.content.ContextCompat;
import android.view.View;
import android.support.design.widget.NavigationView;
import android.support.v4.view.GravityCompat;
import android.support.v4.widget.DrawerLayout;
import android.support.v7.app.ActionBarDrawerToggle;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import com.example.millieagallo.chapabiz_agent.activities.AgentLogin;
import com.ipaulpro.afilechooser.utils.FileUtils;
import com.makeramen.roundedimageview.RoundedImageView;
import com.squareup.picasso.Picasso;

import java.io.File;

import de.hdodenhof.circleimageview.CircleImageView;
import com.example.millieagallo.chapabiz_agent.R;
//import com.example.millieagallo.chapabiz_agent.activities.LoginActivity;
//import com.example.millieagallo.chapabiz_agent.activities.MainLogin;
import com.example.millieagallo.chapabiz_agent.agent.Agent;
import com.example.millieagallo.chapabiz_agent.agent.fragments.BusinessDetails;
import com.example.millieagallo.chapabiz_agent.agent.fragments.BusinessFragment;
import com.example.millieagallo.chapabiz_agent.agent.fragments.DashboardFragment;
import com.example.millieagallo.chapabiz_agent.agent.fragments.ProfileFragment;
import com.example.millieagallo.chapabiz_agent.business.activities.BusinessActivity;
import com.example.millieagallo.chapabiz_agent.business.adapters.PhotoAdapter;
import com.example.millieagallo.chapabiz_agent.business.fragments.ImageFragment;
import com.example.millieagallo.chapabiz_agent.business.fragments.PhotoFragment;
import com.example.millieagallo.chapabiz_agent.entities.Photo;
import com.example.millieagallo.chapabiz_agent.helpers.CbSession;
import com.example.millieagallo.chapabiz_agent.helpers.UploadFile;
import com.example.millieagallo.chapabiz_agent.retrofit.RetrofitSetup;
import okhttp3.ResponseBody;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

import static com.example.millieagallo.chapabiz_agent.business.activities.BusinessActivity.LOGO_MEDIA_FILE;

public class AgentActivity extends AppCompatActivity
        implements // NavigationView.OnNavigationItemSelectedListener,
      //  ProfileFragment.Clicked,
        BusinessDetails.Clicked,
        PhotoFragment.Clicked, PhotoAdapter.Clicked, ImageFragment.Clicked {

    private CbSession session;
    private ProgressBar progressBar;
    private TextView progressText;
    private RoundedImageView roundedImageView;
    private ImageView businessImage;
    private String business;
    boolean doubleBackToExitPressedOnce = false;

    private static final int LOGO_CLICKED = 2;
    private static final int PROFILE_CLICKED = 11;
    private static final int FILE_CLICKED = 1;
    private static final int UPLOAD_PHOTO = 0;

    RoundedImageView imageView;
    TextView username;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_agent);

       // session = new CbSession(this);

        CbSession session = new CbSession(this);
        try {
            TextView username = findViewById(R.id.username);

            //   name.setText(session.getShopper().getName());

            ImageView imageView = findViewById(R.id.im1);
       //     Picasso.with(this).load(session.getShopper().getPicture())
        //            .placeholder(ContextCompat.getDrawable(this, R.drawable.user))
       //             .into(imageView);
        } catch (Exception e) {
            if (session.getSignInMethod() == CbSession.FACEBOOK) {

            }
        }

        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        DrawerLayout drawer = (DrawerLayout) findViewById(R.id.drawer_layout);
        ActionBarDrawerToggle toggle = new ActionBarDrawerToggle(
                this, drawer, toolbar, R.string.navigation_drawer_open, R.string.navigation_drawer_close);

        drawer.addDrawerListener(toggle);
        toggle.syncState();

//        NavigationView navigationView = (NavigationView) findViewById(R.id.nav_view);
//        navigationView.setNavigationItemSelectedListener(this);

   //     View view = navigationView.getHeaderView(0);

//        imageView = view.findViewById(R.id.imageView);
//        username = view.findViewById(R.id.username);

        Agent agent = session.getAgent();
        String url = agent.getPicture();
        if (url == null) {
            url = "Image";
        }

//        username.setText(agent.getName());
//        Picasso.with(this).load(url).placeholder(R.drawable.splash_logo).into(imageView);

        DashboardFragment dashboardFragment = new DashboardFragment();
        FragmentTransaction fragmentTransaction = getSupportFragmentManager().beginTransaction();
        fragmentTransaction.add(R.id.agent_content_frame, dashboardFragment);
        fragmentTransaction.commit();

    }

    @Override
    protected void onStart() {
        super.onStart();
        Agent agent = session.getAgent();
        username.setText(agent.getName());
        String url = agent.getPicture();
        if (url == null) {
            url = "Image";
        }
        Picasso.with(this).load(url).placeholder(R.drawable.splash_logo).into(imageView);
    }

    public void startDashboard() {
        DashboardFragment dashboardFragment = new DashboardFragment();
        FragmentTransaction fragmentTransaction = getSupportFragmentManager().beginTransaction();
        fragmentTransaction.replace(R.id.agent_content_frame, dashboardFragment);
        fragmentTransaction.commit();
    }

    public void startBusinesses() {
//        BusinessFragment businessFragment = new BusinessFragment();
//        FragmentTransaction fragmentTransaction = getSupportFragmentManager().beginTransaction();
//        fragmentTransaction.replace(R.id.agent_content_frame, businessFragment);
//        fragmentTransaction.commit();
    }

    public void startProfile() {
//        ProfileFragment profileFragment = new ProfileFragment();
//        FragmentTransaction fragmentTransaction = getSupportFragmentManager().beginTransaction();
//        fragmentTransaction.replace(R.id.agent_content_frame, profileFragment);
//        fragmentTransaction.commit();
    }

    @Override
    public void onBackPressed() {
        DrawerLayout drawer = (DrawerLayout) findViewById(R.id.drawer_layout);
        if (drawer.isDrawerOpen(GravityCompat.START)) {
            drawer.closeDrawer(GravityCompat.START);
        } else {
            if (doubleBackToExitPressedOnce) {
                super.onBackPressed();
                return;
            }

            this.doubleBackToExitPressedOnce = true;
            Toast.makeText(this, "Press again to exit", Toast.LENGTH_SHORT).show();

            new Handler().postDelayed(new Runnable() {

                @Override
                public void run() {
                    doubleBackToExitPressedOnce=false;
                }
            }, 2000);
        }
    }

    @SuppressWarnings("StatementWithEmptyBody")
//    @Override
//    public boolean onNavigationItemSelected(MenuItem item) {
//        // Handle navigation view item clicks here.
//        int id = item.getItemId();
//
//        if (id == R.id.dashboard) {
//            startDashboard();
//        } else if (id == R.id.businesses) {
//            startBusinesses();
//        } else if (id == R.id.profile) {
//            startProfile();
//        } else if (id == R.id.logout) {
//            session.clear();
//            startActivity(new Intent(AgentActivity.this, MainLogin.class));
//        }
//
//        DrawerLayout drawer = (DrawerLayout) findViewById(R.id.drawer_layout);
//        drawer.closeDrawer(GravityCompat.START);
//        return true;
//    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.agent_main, menu);
        return super.onCreateOptionsMenu(menu);
    }

//    @Override
//    public void pictureClicked(RoundedImageView roundedImageView, ProgressBar progressBar) {
//        this.progressBar = progressBar;
//        this.roundedImageView = roundedImageView;
//        Intent getContentIntent = FileUtils.createGetContentIntent();
//        Intent intent = Intent.createChooser(getContentIntent, "Select a file");
//        startActivityForResult(intent, PROFILE_CLICKED);
//    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case R.id.logout:
                session.clear();
                startActivity(new Intent(AgentActivity.this, AgentLogin.class));
                break;
        }
        return false;
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        if (resultCode == RESULT_OK) {
            final Uri uri = data.getData();
            String path = FileUtils.getPath(this, uri);

            if (path != null && FileUtils.isLocal(path)) {
                File file = new File(path);

                if (requestCode == PROFILE_CLICKED) {
                    UploadFile uploadFile = new UploadFile(this, requestCode, null, progressBar, session.getAgent().getId(), file);
                    uploadFile.setRoundedImageView(roundedImageView);
                    uploadFile.execute();
                } else if (requestCode == LOGO_CLICKED) {
                    UploadFile uploadFile = new UploadFile(this, requestCode, null, progressBar, business, file);
                    uploadFile.setImage(businessImage);
                    uploadFile.execute();
                } else if(requestCode == FILE_CLICKED) {
                    UploadFile uploadFile = new UploadFile(this, requestCode, progressText, progressBar, business, file);
                    uploadFile.execute();
                }else if(requestCode == UPLOAD_PHOTO) {
                    UploadFile uploadFile = new UploadFile(this, requestCode, progressText, progressBar, business, file);
                    uploadFile.setFragment(getSupportFragmentManager());
                    uploadFile.execute();
                }

            }
        }
    }

    @Override
    public void logoClicked(ProgressBar progressBar, TextView progressText, RoundedImageView businessImage, String business) {
        this.businessImage = businessImage;
        this.progressBar = progressBar;
        this.business = business;
        Intent getContentIntent = FileUtils.createGetContentIntent();
        Intent intent = Intent.createChooser(getContentIntent, "Select a file");
        startActivityForResult(intent, LOGO_CLICKED);
    }

    @Override
    public void uploadFile(ProgressBar progressBar, TextView progressText, String business) {
        this.progressBar = progressBar;
        this.progressText = progressText;
        this.business = business;
        Intent getContentIntent = FileUtils.createGetContentIntent();
        Intent intent = Intent.createChooser(getContentIntent, "Select a file");
        startActivityForResult(intent, FILE_CLICKED);
    }

    @Override
    public void takePhoto(ProgressBar progressBar, TextView progressText, String business) {
        this.progressBar = progressBar;
        this.progressText = progressText;
        this.business = business;
        Intent getContentIntent = FileUtils.createGetContentIntent();
        Intent intent = Intent.createChooser(getContentIntent, "Select a file");
        startActivityForResult(intent, UPLOAD_PHOTO);
    }

    @Override
    public void clicked(Photo photo) {
        ImageFragment imageFragment = new ImageFragment();
        Bundle bundle = new Bundle();
        bundle.putString("url", photo.getUrl());
        bundle.putString("id", photo.getId());
        imageFragment.setArguments(bundle);
        FragmentTransaction fragmentTransaction = getSupportFragmentManager().beginTransaction();
        fragmentTransaction.replace(R.id.agent_content_frame, imageFragment);
        fragmentTransaction.setTransition(FragmentTransaction.TRANSIT_ENTER_MASK);
        fragmentTransaction.commit();
    }

    @Override
    public void clicked(String id) {
        final ProgressDialog progressDialog = new ProgressDialog(this);
        progressDialog.setMessage("Deleting...");
        progressDialog.setIndeterminate(true);
        progressDialog.setCancelable(false);
        progressDialog.show();
        Call<ResponseBody> call = RetrofitSetup.retrofitInterface.deletePhoto(id);
        call.enqueue(new Callback<ResponseBody>() {
            @Override
            public void onResponse(Call<ResponseBody> call, Response<ResponseBody> response) {
                if (response.isSuccessful()) {
                    Toast.makeText(AgentActivity.this, "Deleted photo", Toast.LENGTH_SHORT).show();
                    PhotoFragment photoFragment = new PhotoFragment();
                    Bundle bundle = new Bundle();
                    bundle.putString("business", business);
                    photoFragment.setArguments(bundle);
                    FragmentTransaction profFrag = AgentActivity.this.getSupportFragmentManager().beginTransaction();
                    profFrag.replace(R.id.agent_content_frame, photoFragment);
                    profFrag.setTransition(FragmentTransaction.TRANSIT_FRAGMENT_FADE);
                    profFrag.commit();
                } else {
                    Toast.makeText(AgentActivity.this, "Unable to delete photo", Toast.LENGTH_SHORT).show();
                }
                progressDialog.dismiss();
            }

            @Override
            public void onFailure(Call<ResponseBody> call, Throwable t) {
                progressDialog.dismiss();
                Toast.makeText(AgentActivity.this, "Unable to delete photo", Toast.LENGTH_SHORT).show();
            }
        });
    }
}
