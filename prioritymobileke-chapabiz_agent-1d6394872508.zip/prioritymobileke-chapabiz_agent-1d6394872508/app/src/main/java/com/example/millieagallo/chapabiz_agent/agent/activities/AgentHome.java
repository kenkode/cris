package com.example.millieagallo.chapabiz_agent.agent.activities;

import android.app.ProgressDialog;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.os.Looper;
import android.support.annotation.NonNull;
import android.support.design.widget.FloatingActionButton;
import android.support.design.widget.NavigationView;
import android.support.design.widget.Snackbar;
import android.support.v4.app.FragmentTransaction;
import android.support.v4.content.ContextCompat;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import com.example.millieagallo.chapabiz_agent.R;
import com.example.millieagallo.chapabiz_agent.activities.AgentLogin;
import com.example.millieagallo.chapabiz_agent.agent.Agent;
import com.example.millieagallo.chapabiz_agent.agent.fragments.BusinessDetails;
import com.example.millieagallo.chapabiz_agent.agent.fragments.BusinessFragment;
import com.example.millieagallo.chapabiz_agent.agent.fragments.ProfileFragment;
import com.example.millieagallo.chapabiz_agent.business.activities.SignUpActivity;
import com.example.millieagallo.chapabiz_agent.business.adapters.PhotoAdapter;
import com.example.millieagallo.chapabiz_agent.business.fragments.ImageFragment;
import com.example.millieagallo.chapabiz_agent.business.fragments.PhotoFragment;
import com.example.millieagallo.chapabiz_agent.entities.Photo;
import com.example.millieagallo.chapabiz_agent.entities.User;
import com.example.millieagallo.chapabiz_agent.helpers.CbSession;
import com.example.millieagallo.chapabiz_agent.helpers.UploadFile;
import com.example.millieagallo.chapabiz_agent.retrofit.RetrofitSetup;
import com.facebook.AccessToken;
import com.facebook.login.LoginManager;
import com.google.android.gms.auth.api.signin.GoogleSignIn;
import com.google.android.gms.auth.api.signin.GoogleSignInClient;
import com.google.android.gms.auth.api.signin.GoogleSignInOptions;
import com.ipaulpro.afilechooser.utils.FileUtils;
import com.makeramen.roundedimageview.RoundedImageView;
import com.squareup.picasso.Picasso;

import java.io.File;


import okhttp3.ResponseBody;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class AgentHome extends AppCompatActivity  implements  BusinessDetails.Clicked,
        PhotoFragment.Clicked, PhotoAdapter.Clicked, ImageFragment.Clicked {

    private boolean isInFront;
  //  private GoogleSignInClient googleSignInClient;
    private CbSession session;
    TextView name;
    ImageView imageView;

    private ProgressBar progressBar;
    private TextView progressText;
    private RoundedImageView roundedImageView;
    private ImageView businessImage;
    private String business;
    boolean doubleBackToExitPressedOnce = false;


    private static final int LOGO_CLICKED = 2;
    private static final int PROFILE_CLICKED = 11;
    private static final int FILE_CLICKED = 1;
    private static final int UPLOAD_PHOTO = 0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_agent_home);

        session = new CbSession(this);

        Agent agent = session.getAgent();
        if (session.getUser() == null) {
            String id = session.getAgent().getId();
            String name = session.getAgent().getName();
            String email = session.getAgent().getEmail();
            User user = new User(id, name, email);
            session.storeUser(user);
        }

        CbSession session = new CbSession(this);
        //
//        String url = business.getImage();
//        if (url == null) {
//            url = "Image";
//        }
//        Picasso.with(context).load(url)
//                .placeholder(ContextCompat.getDrawable(context,R.drawable.splash_logo))
//                .into(holder.imageView);
        //
        try {
            TextView name = findViewById(R.id.name);

           name.setText(agent.getName());

            RoundedImageView imageView = findViewById(R.id.im1);
            Picasso.with(this).load(session.getAgent().getPicture())
                    .placeholder(ContextCompat.getDrawable(this, R.drawable.user))
                    .into(imageView);
        } catch (Exception e) {
            if (session.getSignInMethod() == CbSession.FACEBOOK) {

            }
        }
//        FloatingActionButton fab = (FloatingActionButton) findViewById(R.id.fab);
//        fab.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View view) {
//                Snackbar.make(view, "Replace with your own action", Snackbar.LENGTH_LONG)
//                        .setAction("Action", null).show();
//            }
//        });
    }


//    @Override
//    protected void onStart() {
//        super.onStart();
//        Agent agent = session.getAgent();
//       username.setText(agent.getName());
//        String url = agent.getPicture();
//        if (url == null) {
//            url = "Image";
//        }
//        Picasso.with(this).load(url).placeholder(R.drawable.splash_logo).into(imageView);
//    }


    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.user_home, menu);
        return true;
    }


    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()){
            case R.id.logout:
            session.clear();
            startActivity(new Intent(AgentHome.this, AgentLogin.class));
            break;
        }
        return false;
    }

    @Override
    public Looper getMainLooper() {
        return super.getMainLooper();
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        if (resultCode == RESULT_OK) {
            final Uri uri = data.getData();
            String path = FileUtils.getPath(this, uri);

            if (path != null && FileUtils.isLocal(path)) {
                File file = new File(path);

                if (requestCode == PROFILE_CLICKED) {
                    UploadFile uploadFile = new UploadFile(this, requestCode, null, progressBar, session.getAgent().getId(), file);
                    uploadFile.setRoundedImageView(roundedImageView);
                    uploadFile.execute();
                } else if (requestCode == LOGO_CLICKED) {
                    UploadFile uploadFile = new UploadFile(this, requestCode, null, progressBar, business, file);
                    uploadFile.setImage(businessImage);
                    uploadFile.execute();
                } else if(requestCode == FILE_CLICKED) {
                    UploadFile uploadFile = new UploadFile(this, requestCode, progressText, progressBar, business, file);
                    uploadFile.execute();
                }else if(requestCode == UPLOAD_PHOTO) {
                    UploadFile uploadFile = new UploadFile(this, requestCode, progressText, progressBar, business, file);
                    uploadFile.setFragment(getSupportFragmentManager());
                    uploadFile.execute();
                }

            }
        }
    }

    @Override
    public void logoClicked(ProgressBar progressBar, TextView progressText, RoundedImageView businessImage, String business) {
        this.businessImage = businessImage;
        this.progressBar = progressBar;
        this.business = business;
        Intent getContentIntent = FileUtils.createGetContentIntent();
        Intent intent = Intent.createChooser(getContentIntent, "Select a file");
        startActivityForResult(intent, LOGO_CLICKED);
    }

    @Override
    public void uploadFile(ProgressBar progressBar, TextView progressText, String business) {
        this.progressBar = progressBar;
        this.progressText = progressText;
        this.business = business;
        Intent getContentIntent = FileUtils.createGetContentIntent();
        Intent intent = Intent.createChooser(getContentIntent, "Select a file");
        startActivityForResult(intent, FILE_CLICKED);
    }

    @Override
    public void takePhoto(ProgressBar progressBar, TextView progressText, String business) {
        this.progressBar = progressBar;
        this.progressText = progressText;
        this.business = business;
        Intent getContentIntent = FileUtils.createGetContentIntent();
        Intent intent = Intent.createChooser(getContentIntent, "Select a file");
        startActivityForResult(intent, UPLOAD_PHOTO);
    }

    @Override
    public void clicked(Photo photo) {
        ImageFragment imageFragment = new ImageFragment();
        Bundle bundle = new Bundle();
        bundle.putString("url", photo.getUrl());
        bundle.putString("id", photo.getId());
        imageFragment.setArguments(bundle);
        FragmentTransaction fragmentTransaction = getSupportFragmentManager().beginTransaction();
        fragmentTransaction.replace(R.id.agent_content_frame, imageFragment);
        fragmentTransaction.setTransition(FragmentTransaction.TRANSIT_ENTER_MASK);
        fragmentTransaction.commit();
    }

    @Override
    public void clicked(String id) {
        final ProgressDialog progressDialog = new ProgressDialog(this);
        progressDialog.setMessage("Deleting...");
        progressDialog.setIndeterminate(true);
        progressDialog.setCancelable(false);
        progressDialog.show();
        Call<ResponseBody> call = RetrofitSetup.retrofitInterface.deletePhoto(id);
        call.enqueue(new Callback<ResponseBody>() {
            @Override
            public void onResponse(Call<ResponseBody> call, Response<ResponseBody> response) {
                if (response.isSuccessful()) {
                    Toast.makeText(AgentHome.this, "Deleted photo", Toast.LENGTH_SHORT).show();
                    PhotoFragment photoFragment = new PhotoFragment();
                    Bundle bundle = new Bundle();
                    bundle.putString("business", business);
                    photoFragment.setArguments(bundle);
                    FragmentTransaction profFrag = AgentHome.this.getSupportFragmentManager().beginTransaction();
                    profFrag.replace(R.id.agent_content_frame, photoFragment);
                    profFrag.setTransition(FragmentTransaction.TRANSIT_FRAGMENT_FADE);
                    profFrag.commit();
                } else {
                    Toast.makeText(AgentHome.this, "Unable to delete photo", Toast.LENGTH_SHORT).show();
                }
                progressDialog.dismiss();
            }

            @Override
            public void onFailure(Call<ResponseBody> call, Throwable t) {
                progressDialog.dismiss();
                Toast.makeText(AgentHome.this, "Unable to delete photo", Toast.LENGTH_SHORT).show();
            }
        });
    }
    //sign up businesses
    public void card1(View view)
    {
        Intent joboneIntent = new Intent(AgentHome.this, SignUpActivity.class);
        startActivity(joboneIntent);

    }
    //view businesses
    public void card2(View view)
    {
        Intent joboneIntent = new Intent(AgentHome.this, BusinessFragment.class);
        startActivity(joboneIntent);
        //startBusinesses();

    }
    //commissions
    public void card3(View view)
    {
        Intent joboneIntent = new Intent(AgentHome.this, Commisions.class);
        startActivity(joboneIntent);

    }
    //logout
    public void card4(View view)
    {

        logout();

    }
    //profile
    public void textview(View view)
    {
        Intent jobz = new Intent(AgentHome.this, ProfileFragment.class);
        startActivity(jobz);
       // startProfile();
    }

    private void logout() {


        session.clear();
        startActivity(new Intent(AgentHome.this, AgentLogin.class));
    }

//    @Override
//    public boolean onNavigationItemSelected(@NonNull MenuItem item) {
//        return false;
//    }

//    public void img(View view) {
//    }
}
