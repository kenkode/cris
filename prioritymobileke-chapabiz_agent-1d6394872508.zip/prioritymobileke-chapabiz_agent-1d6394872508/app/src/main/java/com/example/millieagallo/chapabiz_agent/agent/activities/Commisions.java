package com.example.millieagallo.chapabiz_agent.agent.activities;

import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.design.widget.NavigationView;
import android.support.v4.content.ContextCompat;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.RecyclerView;
import android.view.Gravity;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;
import android.support.v7.widget.Toolbar;

import com.example.millieagallo.chapabiz_agent.activities.AgentLogin;
import com.squareup.picasso.Picasso;

import java.util.ArrayList;

import com.example.millieagallo.chapabiz_agent.R;
//import com.example.millieagallo.chapabiz_agent.activities.MainLogin;
import com.example.millieagallo.chapabiz_agent.agent.Agent;
import com.example.millieagallo.chapabiz_agent .agent.adapters.CommissionsAdapter;
import com.example.millieagallo.chapabiz_agent.agent.fragments.BusinessFragment;
import com.example.millieagallo.chapabiz_agent.agent.fragments.ProfileFragment;
import com.example.millieagallo.chapabiz_agent.business.activities.SignUpActivity;
import com.example.millieagallo.chapabiz_agent.business.entities.Business;
import com.example.millieagallo.chapabiz_agent.entities.User;
import com.example.millieagallo.chapabiz_agent.helpers.CbSession;
import com.example.millieagallo.chapabiz_agent.retrofit.RetrofitSetup;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

/**
 * Created by Millie Agallo on 4/17/2018.
 */

public class Commisions extends AppCompatActivity  {
    private boolean isInFront;
    //  private GoogleSignInClient googleSignInClient;
    private CbSession session;
    TextView username;
    ImageView imageView;

    RecyclerView.LayoutManager mLinearLayoutManager;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main_commissions);
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);

        session = new CbSession(this);
        Agent agent = session.getAgent();
        if (session.getUser() == null) {
            String id = session.getAgent().getId();
            String name = session.getAgent().getName();
            String email = session.getAgent().getEmail();
            User user = new User(id, name, email);
            session.storeUser(user);
        }

       // Agent agent = session.getAgent();
        String url = agent.getPicture();
        if (url == null) {
            url = "Image";
        }

//        username.setText(agent.getName());

        CbSession session = new CbSession(this);

        final RecyclerView recyclerView = findViewById(R.id.commissions_list1);

        final RecyclerView recyclerView2 = findViewById(R.id.commissions_list2);

        final RecyclerView recyclerView3 = findViewById(R.id.commissions_list3);

        final RecyclerView recyclerView4 = findViewById(R.id.commissions_list4);

        final RecyclerView recyclerView5 = findViewById(R.id.commissions_list5);

//day commissions
        Call<ArrayList<Business>> call = RetrofitSetup.retrofitInterface.getAgentCommissionsDay(session.getAgent().getId());
        call.enqueue(new Callback<ArrayList<Business>>() {
            @Override
            public void onResponse(Call<ArrayList<Business>> call, Response<ArrayList<Business>> response) {
                if (response.isSuccessful()) {

                    ArrayList<Business> businesses = response.body();

                    CommissionsAdapter commissionsAdapter = new CommissionsAdapter(Commisions.this, businesses);
                    recyclerView.setAdapter(commissionsAdapter);
                } else{
                    Toast toast = Toast.makeText(Commisions.this, "Your commissions could not be loaded at the moment", Toast.LENGTH_SHORT);
                    toast.setGravity(Gravity.CENTER, 0, 0);
                    toast.show();
                }
            }
            @Override
            public void onFailure(Call<ArrayList<Business>> call, Throwable t) {
                t.printStackTrace();
            }
        });

        //week commissions
        Call<ArrayList<Business>> call2 = RetrofitSetup.retrofitInterface.getAgentCommissionsWeek(session.getAgent().getId());
        call2.enqueue(new Callback<ArrayList<Business>>() {
            @Override
            public void onResponse(Call<ArrayList<Business>> call2, Response<ArrayList<Business>> response2) {
                if (response2.isSuccessful()) {

                    ArrayList<Business> businesses2 = response2.body();

                    CommissionsAdapter commissionsAdapter = new CommissionsAdapter(Commisions.this, businesses2);
                    recyclerView2.setAdapter(commissionsAdapter);
                } else{
                    Toast toast = Toast.makeText(Commisions.this, "Your commissions could not be loaded at the moment", Toast.LENGTH_SHORT);
                    toast.setGravity(Gravity.CENTER, 0, 0);
                    toast.show();
                }
            }
            @Override
            public void onFailure(Call<ArrayList<Business>> call2, Throwable t) {
                t.printStackTrace();
            }
        });

        //month commissions
        Call<ArrayList<Business>> call3 = RetrofitSetup.retrofitInterface.getAgentCommissionsMonth(session.getAgent().getId());
        call3.enqueue(new Callback<ArrayList<Business>>() {
            @Override
            public void onResponse(Call<ArrayList<Business>> call3, Response<ArrayList<Business>> response3) {
                if (response3.isSuccessful()) {

                    ArrayList<Business> businesses3 = response3.body();

                    CommissionsAdapter commissionsAdapter = new CommissionsAdapter(Commisions.this, businesses3);
                    recyclerView3.setAdapter(commissionsAdapter);
                } else{
                    Toast toast = Toast.makeText(Commisions.this, "Your commissions could not be loaded at the moment", Toast.LENGTH_SHORT);
                    toast.setGravity(Gravity.CENTER, 0, 0);
                    toast.show();
                }
            }
            @Override
            public void onFailure(Call<ArrayList<Business>> call3, Throwable t) {
                t.printStackTrace();
            }
        });

        //year commissions
        Call<ArrayList<Business>> call4 = RetrofitSetup.retrofitInterface.getAgentCommissionsYear(session.getAgent().getId());
        call4.enqueue(new Callback<ArrayList<Business>>() {
            @Override
            public void onResponse(Call<ArrayList<Business>> call4, Response<ArrayList<Business>> response4) {
                if (response4.isSuccessful()) {

                    ArrayList<Business> businesses4 = response4.body();

                    CommissionsAdapter commissionsAdapter = new CommissionsAdapter(Commisions.this, businesses4);
                    recyclerView4.setAdapter(commissionsAdapter);
                } else{
                    Toast toast = Toast.makeText(Commisions.this, "Your commissions could not be loaded at the moment", Toast.LENGTH_SHORT);
                    toast.setGravity(Gravity.CENTER, 0, 0);
                    toast.show();
                }
            }
            @Override
            public void onFailure(Call<ArrayList<Business>> call4, Throwable t) {
                t.printStackTrace();
            }
        });

        //all commissions
        Call<ArrayList<Business>> call5 = RetrofitSetup.retrofitInterface.getAgentCommissionsAll(session.getAgent().getId());
        call5.enqueue(new Callback<ArrayList<Business>>() {
            @Override
            public void onResponse(Call<ArrayList<Business>> call5, Response<ArrayList<Business>> response5) {
                if (response5.isSuccessful()) {

                    ArrayList<Business> businesses5 = response5.body();

                    CommissionsAdapter commissionsAdapter = new CommissionsAdapter(Commisions.this, businesses5);
                    recyclerView5.setAdapter(commissionsAdapter);
                } else{
                    Toast toast = Toast.makeText(Commisions.this, "Your commissions could not be loaded at the moment", Toast.LENGTH_SHORT);
                    toast.setGravity(Gravity.CENTER, 0, 0);
                    toast.show();
                }
            }
            @Override
            public void onFailure(Call<ArrayList<Business>> call5, Throwable t) {
                t.printStackTrace();
            }
        });
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.action_settings) {
            return true;
        }

        return super.onOptionsItemSelected(item);
    }
    //today commission
    public void card1(View view)
    {
        Intent joboneIntent = new Intent(Commisions.this, DayCommisions.class);
       // startActivity(joboneIntent);

    }
    //week
    public void card2(View view)
    {
        Intent joboneIntent = new Intent(Commisions.this, WeekComissions.class);
      //  startActivity(joboneIntent);
        //startBusinesses();

    }
    //month
    public void card3(View view)
    {
        Intent joboneIntent = new Intent(Commisions.this, MonthCommissions.class);
       // startActivity(joboneIntent);

    }
    //year
    public void card4(View view)
    {

       Intent jobo = new Intent(Commisions.this, YearCommisions.class);
      // startActivity(jobo);

    }

    //all
    public void card5(View view)
    {
        Intent jjb = new Intent(Commisions.this, AllCommissions.class);
       // startActivity(jjb);
    }
    //back
    public void img(View view)
    {
        Intent jbz = new Intent(Commisions.this,AgentHome.class);
       // startActivity(jbz);
    }


    private void logout() {


        session.clear();
        startActivity(new Intent(Commisions.this, AgentLogin.class));

    }
}
