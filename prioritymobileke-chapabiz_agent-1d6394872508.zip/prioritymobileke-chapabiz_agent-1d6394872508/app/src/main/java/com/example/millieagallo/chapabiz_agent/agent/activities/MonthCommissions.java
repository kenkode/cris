package com.example.millieagallo.chapabiz_agent.agent.activities;

import android.os.Bundle;
import android.support.design.widget.FloatingActionButton;
import android.support.design.widget.Snackbar;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.RecyclerView;
import android.support.v7.widget.Toolbar;
import android.util.Log;
import android.view.Gravity;
import android.view.View;
import android.widget.Toast;

import com.google.gson.Gson;

import java.util.ArrayList;


import com.example.millieagallo.chapabiz_agent.R;
import com.example.millieagallo.chapabiz_agent.agent.adapters.CommissionsAdapter;
import com.example.millieagallo.chapabiz_agent.business.entities.Business;
import com.example.millieagallo.chapabiz_agent.helpers.CbSession;
import com.example.millieagallo.chapabiz_agent.retrofit.RetrofitSetup;

import com.example.millieagallo.chapabiz_agent.agent.Agent;

import com.example.millieagallo.chapabiz_agent.entities.User;


import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class MonthCommissions extends AppCompatActivity  {

    RecyclerView.LayoutManager LinearLayoutManager;
    // private CbSession session;
    // @Nullable
    @Override
    protected void onCreate( Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_month_commissions);
        CbSession session = new CbSession(this);
        Agent agent = session.getAgent();
        if (session.getUser() == null) {
            String id = session.getAgent().getId();
            String name = session.getAgent().getName();
            String email = session.getAgent().getEmail();
            User user = new User(id, name, email);
            session.storeUser(user);
        }

        final RecyclerView recyclerView = findViewById(R.id.commissions_list);
       Log.e("id",new Gson().toJson(agent));
        //(agent.getPhone()) session.getAgent().getId()
        Call<ArrayList<Business>> call = RetrofitSetup.retrofitInterface.getAgentCommissionsMonth(agent.getId());
        call.enqueue(new Callback<ArrayList<Business>>() {
            @Override
            public void onResponse(Call<ArrayList<Business>> call, Response<ArrayList<Business>> response) {
                if (response.isSuccessful()) {

                    ArrayList<Business> businesses = response.body();

                    Log.e("db",new Gson().toJson(businesses));

                    CommissionsAdapter commissionsAdapter = new CommissionsAdapter(MonthCommissions.this, businesses);
                    recyclerView.setAdapter(commissionsAdapter);
                } else{
                    Toast toast = Toast.makeText(MonthCommissions.this, "Your commissions could not be loaded at the moment", Toast.LENGTH_SHORT);
                    toast.setGravity(Gravity.CENTER, 0, 0);
                    toast.show();
                }
            }
            @Override
            public void onFailure(Call<ArrayList<Business>> call, Throwable t) {
                t.printStackTrace();
            }
        });
    }
}
