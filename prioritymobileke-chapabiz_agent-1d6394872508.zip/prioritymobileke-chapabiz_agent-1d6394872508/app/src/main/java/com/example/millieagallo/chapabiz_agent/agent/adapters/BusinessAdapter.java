package com.example.millieagallo.chapabiz_agent.agent.adapters;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentTransaction;
import android.support.v4.content.ContextCompat;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import android.widget.Toast;

import com.makeramen.roundedimageview.RoundedImageView;
import com.squareup.picasso.Picasso;

import java.util.ArrayList;

import com.example.millieagallo.chapabiz_agent.R;
import com.example.millieagallo.chapabiz_agent.agent.activities.AgentHome;
import com.example.millieagallo.chapabiz_agent.agent.fragments.BusinessDetails;
import com.example.millieagallo.chapabiz_agent.business.entities.Business;
import com.example.millieagallo.chapabiz_agent.helpers.CbSession;

import static android.app.PendingIntent.getActivity;

public class BusinessAdapter extends RecyclerView.Adapter<BusinessAdapter.ViewHolder> {

    private Context context;
    private FragmentManager fragmentManager;
    private ArrayList<Business> businesses;

   // private CbSession session;
   // FragmentTransaction fragmentTransaction;
  //  FragmentManager manager = getActivity().getSupportFragmentManager();

  //  private final View.OnClickListener mOnClickListener = new MyOnClickListener();

    public BusinessAdapter(Context context,  ArrayList<Business> businesses) {
        this.context = context;
        this.businesses = businesses;
        this.fragmentManager = fragmentManager;
       // session = new CbSession(context);
    }

    @Override
    public BusinessAdapter.ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(context).inflate(R.layout.agent_business_item, parent, false);
     //   view.setOnClickListener(mOnClickListener);
        return new BusinessAdapter.ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(BusinessAdapter.ViewHolder holder, int position) {
        Business business = businesses.get(position);

        holder.name.setText(business.getName());
        String url = business.getImage();
        if (url == null) {
            url = "Image";
        }
        Picasso.with(context).load(url)
                .placeholder(ContextCompat.getDrawable(context,R.drawable.splash_logo))
                .into(holder.imageView);
        holder.status.setTextColor(ContextCompat.getColor(context, android.R.color.black));
        switch (business.getVerified()) {
            case 0:
                holder.status.setText("Not Verified");
                holder.status.setTextColor(ContextCompat.getColor(context, R.color.colorRedAccent));
                break;
            case 1:
                holder.status.setTextColor(ContextCompat.getColor(context, R.color.colorGreenAccent));
                holder.status.setText("Verified");
                break;
        }
    }

    @Override
    public int getItemCount() {
        return businesses.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder implements View.OnClickListener {

        public TextView name, status;
        public RoundedImageView imageView;

        public ViewHolder(View view) {
            super(view);

           view.setOnClickListener(this);

            name = view.findViewById(R.id.name);
            status = view.findViewById(R.id.status);
            imageView = view.findViewById(R.id.imageView);
        }

@Override
public void onClick(View view) {
    Business business = businesses.get(getAdapterPosition());
    CbSession session = new CbSession(context);
    session.setBusiness(business);
    BusinessDetails businessDetails = new BusinessDetails();
   Bundle bundle = new Bundle();
    bundle.putString("business", business.getId());
    businessDetails.setArguments(bundle);
   FragmentTransaction fragmentTransaction = ((AppCompatActivity) context).getSupportFragmentManager().beginTransaction();
 //FragmentTransaction fragmentTransaction = fragmentManager().beginTransaction();
    //FragmentTransaction fragmentTransaction = getActivity().getSupportFragmentManager().beginTransaction();
    fragmentTransaction.replace(R.id.test1, businessDetails);
    fragmentTransaction.commit();

    //works for activity
//    view.getContext().startActivity(new
//            Intent(view.getContext(),AgentHome.class));
        }

    }
}
