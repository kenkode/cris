package com.example.millieagallo.chapabiz_agent.agent.adapters;

import android.content.Context;
import android.os.Bundle;
import android.support.v4.content.ContextCompat;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import com.makeramen.roundedimageview.RoundedImageView;
import com.squareup.picasso.Picasso;

import java.util.ArrayList;

import com.example.millieagallo.chapabiz_agent.R;
import com.example.millieagallo.chapabiz_agent.agent.fragments.BusinessDetails;
import com.example.millieagallo.chapabiz_agent.business.entities.Business;
import com.example.millieagallo.chapabiz_agent.helpers.CbSession;

/**
 * Created by Millie Agallo on 4/19/2018.
 */

public class CommissionsAdapter extends RecyclerView.Adapter<CommissionsAdapter.ViewHolder> {

    private Context context;
    private ArrayList<Business> businesses;
    // private CbSession session;

    public CommissionsAdapter(Context context, ArrayList<Business> businesses) {
        this.context = context;
        this.businesses = businesses;
        // session = new CbSession(context);
    }

    @Override
    public CommissionsAdapter.ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(context).inflate(R.layout.agent_commission_item, parent, false);
        return new CommissionsAdapter.ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(CommissionsAdapter.ViewHolder holder, int position) {
        Business business = businesses.get(position);

//        holder.name.setText(business.getName());
        holder.commissions.setText(business.getCommissions());

    }

    @Override
    public int getItemCount() {
        return businesses.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder {

        public TextView name, commissions;
      //  public RoundedImageView imageView;

        public ViewHolder(View view) {
            super(view);

         //   name = view.findViewById(R.id.business_name1);
            commissions = view.findViewById(R.id.textView90);
         ///   imageView = view.findViewById(R.id.imageView);
        }


    }
}
