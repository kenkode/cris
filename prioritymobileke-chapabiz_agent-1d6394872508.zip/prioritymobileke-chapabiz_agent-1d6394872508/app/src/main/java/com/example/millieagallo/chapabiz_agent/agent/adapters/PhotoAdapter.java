package com.example.millieagallo.chapabiz_agent.agent.adapters;

import android.content.Context;
import android.content.DialogInterface;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentTransaction;
import android.support.v4.content.ContextCompat;
import android.support.v7.app.AlertDialog;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import com.squareup.picasso.Picasso;

import java.util.ArrayList;

import com.example.millieagallo.chapabiz_agent.R;
import com.example.millieagallo.chapabiz_agent.agent.fragments.BusinessDetails;
import com.example.millieagallo.chapabiz_agent.business.entities.Business;
import com.example.millieagallo.chapabiz_agent.entities.Photo;
import com.example.millieagallo.chapabiz_agent.helpers.CbSession;

public class PhotoAdapter extends RecyclerView.Adapter<PhotoAdapter.ViewHolder> {

    private Context context;
    private ArrayList<Photo> photos;

    public PhotoAdapter(Context context, ArrayList<Photo> photos) {
        this.photos = photos;
        this.context = context;
    }

    @Override
    public PhotoAdapter.ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(context).inflate(R.layout.photo_item, parent, false);
        return new PhotoAdapter.ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(PhotoAdapter.ViewHolder holder, int position) {
        final Photo photo = photos.get(position);
        Picasso.with(context)
                .load(photo.getUrl())
                .placeholder(ContextCompat.getDrawable(context, R.drawable.ic_chapabiz_logo_vert))
                .into(holder.photo);
    }

    @Override
    public int getItemCount() {
        return photos.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder implements View.OnClickListener {

        public ImageView photo;

        public ViewHolder(View view) {
            super(view);
            photo = view.findViewById(R.id.photo);
            photo.setScaleType(ImageView.ScaleType.FIT_CENTER);
            photo.setMaxHeight(90);
            photo.setOnClickListener(this);
        }

        @Override
        public void onClick(View view) {
            AlertDialog.Builder builder = new AlertDialog.Builder(context);
            View v = LayoutInflater.from(context).inflate(R.layout.photo_item, null, false);
            ImageView imageView = v.findViewById(R.id.photo);

            final Photo photo = photos.get(getAdapterPosition());
            Picasso.with(context)
                    .load(photo.getUrl())
                    .placeholder(ContextCompat.getDrawable(context, R.drawable.ic_chapabiz_logo_vert))
                    .into(imageView);

            builder.setView(v);
            builder.setPositiveButton("Close", new DialogInterface.OnClickListener() {
                @Override
                public void onClick(DialogInterface dialogInterface, int i) {
                    dialogInterface.dismiss();
                }
            });
            if (new CbSession(context).getAgent() != null) {
                builder.setNeutralButton("Remove", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {
                        //remove photo
                    }
                });
            }
            builder.create().show();
        }
    }

}
