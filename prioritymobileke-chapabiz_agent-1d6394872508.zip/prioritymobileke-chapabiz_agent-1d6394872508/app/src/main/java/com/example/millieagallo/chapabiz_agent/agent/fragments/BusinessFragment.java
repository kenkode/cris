package com.example.millieagallo.chapabiz_agent.agent.fragments;

import android.app.ProgressDialog;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentTransaction;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.GridLayoutManager;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;
import android.support.v7.widget.Toolbar;

import com.ipaulpro.afilechooser.utils.FileUtils;
import com.makeramen.roundedimageview.RoundedImageView;

import java.io.File;
import java.util.ArrayList;

import com.example.millieagallo.chapabiz_agent.R;
import com.example.millieagallo.chapabiz_agent.agent.Agent;
import com.example.millieagallo.chapabiz_agent.agent.activities.AgentHome;
import com.example.millieagallo.chapabiz_agent.agent.adapters.BusinessAdapter;
import com.example.millieagallo.chapabiz_agent.business.adapters.PhotoAdapter;
import com.example.millieagallo.chapabiz_agent.business.entities.Business;
import com.example.millieagallo.chapabiz_agent.business.fragments.ImageFragment;
import com.example.millieagallo.chapabiz_agent.business.fragments.PhotoFragment;
import com.example.millieagallo.chapabiz_agent.entities.Photo;
import com.example.millieagallo.chapabiz_agent.entities.User;
import com.example.millieagallo.chapabiz_agent.helpers.CbSession;
import com.example.millieagallo.chapabiz_agent.helpers.UploadFile;
import com.example.millieagallo.chapabiz_agent.retrofit.RetrofitSetup;
//import com.example.millieagallo.chapabiz_agent.shopper.activities.InterestActivity;
import okhttp3.ResponseBody;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

import static java.security.AccessController.getContext;

public class BusinessFragment extends AppCompatActivity  implements  BusinessDetails.Clicked,
        PhotoFragment.Clicked, PhotoAdapter.Clicked, ImageFragment.Clicked {

    RecyclerView.LayoutManager mLinearLayoutManager;

   // FragmentManager manager = FragmentManager();
   // private CbSession session;
   // @Nullable
   private boolean isInFront;
    //  private GoogleSignInClient googleSignInClient;
    private CbSession session;
    TextView name;
    ImageView imageView;

    private ProgressBar progressBar;
    private TextView progressText;
    private RoundedImageView roundedImageView;
    private ImageView businessImage;
    private String business;
    boolean doubleBackToExitPressedOnce = false;


    private static final int LOGO_CLICKED = 2;
    private static final int PROFILE_CLICKED = 11;
    private static final int FILE_CLICKED = 1;
    private static final int UPLOAD_PHOTO = 0;
    @Override
    protected void onCreate( Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
       setContentView(R.layout.activity_layout_agent_b);
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);

      CbSession  session = new CbSession(this);

        Agent agent = session.getAgent();
        if (session.getUser() == null) {
            String id = session.getAgent().getId();
            String name = session.getAgent().getName();
            String email = session.getAgent().getEmail();
            User user = new User(id, name, email);
            session.storeUser(user);
        }



        final RecyclerView recyclerView = findViewById(R.id.businesses);
        /*mLinearLayoutManager = new LinearLayoutManager(BusinessFragment.this);
                    recyclerView.setLayoutManager(llm);*/

        Call<ArrayList<Business>> call = RetrofitSetup.retrofitInterface.getAgentRegBusinesses(session.getAgent().getId());
        call.enqueue(new Callback<ArrayList<Business>>() {
            @Override
            public void onResponse(Call<ArrayList<Business>> call, Response<ArrayList<Business>> response) {
                if (response.isSuccessful()) {

                    ArrayList<Business> businesses = response.body();

                BusinessAdapter businessAdapter = new BusinessAdapter(BusinessFragment.this, businesses);
               //     BusinessAdapter businessAdapter = new BusinessAdapter(getApplicationContext(), getFragmentManager(), businesses);
                    recyclerView.setAdapter(businessAdapter);
                } else{
                    Toast toast = Toast.makeText(BusinessFragment.this, "Your businesses could not be loaded at the moment", Toast.LENGTH_SHORT);
                    toast.setGravity(Gravity.CENTER, 0, 0);
                    toast.show();
                }
            }
            @Override
            public void onFailure(Call<ArrayList<Business>> call, Throwable t) {
                t.printStackTrace();
            }
        });
    }
//    @Override
//    public boolean onCreateOptionsMenu(Menu menu) {
//        // Inflate the menu; this adds items to the action bar if it is present.
//        getMenuInflater().inflate(R.menu.user_home, menu);
//        return true;
//    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        if (resultCode == RESULT_OK) {
            final Uri uri = data.getData();
            String path = FileUtils.getPath(this, uri);

            if (path != null && FileUtils.isLocal(path)) {
                File file = new File(path);

                if (requestCode == PROFILE_CLICKED) {
                    UploadFile uploadFile = new UploadFile(this, requestCode, null, progressBar, session.getAgent().getId(), file);
                    uploadFile.setRoundedImageView(roundedImageView);
                    uploadFile.execute();
                } else if (requestCode == LOGO_CLICKED) {
                    UploadFile uploadFile = new UploadFile(this, requestCode, null, progressBar, business, file);
                    uploadFile.setImage(businessImage);
                    uploadFile.execute();
                } else if(requestCode == FILE_CLICKED) {
                    UploadFile uploadFile = new UploadFile(this, requestCode, progressText, progressBar, business, file);
                    uploadFile.execute();
                }else if(requestCode == UPLOAD_PHOTO) {
                    UploadFile uploadFile = new UploadFile(this, requestCode, progressText, progressBar, business, file);
                    uploadFile.setFragment(getSupportFragmentManager());
                    uploadFile.execute();
                }

            }
        }
    }

    @Override
    public void logoClicked(ProgressBar progressBar, TextView progressText, RoundedImageView businessImage, String business) {
        this.businessImage = businessImage;
        this.progressBar = progressBar;
        this.business = business;
        Intent getContentIntent = FileUtils.createGetContentIntent();
        Intent intent = Intent.createChooser(getContentIntent, "Select a file");
        startActivityForResult(intent, LOGO_CLICKED);
    }

    @Override
    public void uploadFile(ProgressBar progressBar, TextView progressText, String business) {
        this.progressBar = progressBar;
        this.progressText = progressText;
        this.business = business;
        Intent getContentIntent = FileUtils.createGetContentIntent();
        Intent intent = Intent.createChooser(getContentIntent, "Select a file");
        startActivityForResult(intent, FILE_CLICKED);
    }

    @Override
    public void takePhoto(ProgressBar progressBar, TextView progressText, String business) {
        this.progressBar = progressBar;
        this.progressText = progressText;
        this.business = business;
        Intent getContentIntent = FileUtils.createGetContentIntent();
        Intent intent = Intent.createChooser(getContentIntent, "Select a file");
        startActivityForResult(intent, UPLOAD_PHOTO);
    }

    @Override
    public void clicked(Photo photo) {
        ImageFragment imageFragment = new ImageFragment();
        Bundle bundle = new Bundle();
        bundle.putString("photo", photo.getUrl());
        bundle.putString("id", photo.getId());
        imageFragment.setArguments(bundle);
        FragmentTransaction fragmentTransaction = getSupportFragmentManager().beginTransaction();
        fragmentTransaction.replace(R.id.agent_content_frame, imageFragment);
        fragmentTransaction.setTransition(FragmentTransaction.TRANSIT_ENTER_MASK);
        fragmentTransaction.commit();
    }

    @Override
    public void clicked(String id) {
        final ProgressDialog progressDialog = new ProgressDialog(this);
        progressDialog.setMessage("Deleting...");
        progressDialog.setIndeterminate(true);
        progressDialog.setCancelable(false);
        progressDialog.show();
        Call<ResponseBody> call = RetrofitSetup.retrofitInterface.deletePhoto(id);
        call.enqueue(new Callback<ResponseBody>() {
            @Override
            public void onResponse(Call<ResponseBody> call, Response<ResponseBody> response) {
                if (response.isSuccessful()) {
                    Toast.makeText(BusinessFragment.this, "Deleted photo", Toast.LENGTH_SHORT).show();
                    PhotoFragment photoFragment = new PhotoFragment();
                    Bundle bundle = new Bundle();
                    bundle.putString("business", business);
                    photoFragment.setArguments(bundle);
                    FragmentTransaction profFrag = BusinessFragment.this.getSupportFragmentManager().beginTransaction();
                    profFrag.replace(R.id.ttbb2, photoFragment);
                    profFrag.setTransition(FragmentTransaction.TRANSIT_FRAGMENT_FADE);
                    profFrag.commit();
                } else {
                    Toast.makeText(BusinessFragment.this, "Unable to delete photo", Toast.LENGTH_SHORT).show();
                }
                progressDialog.dismiss();
            }

            @Override
            public void onFailure(Call<ResponseBody> call, Throwable t) {
                progressDialog.dismiss();
                Toast.makeText(BusinessFragment.this, "Unable to delete photo", Toast.LENGTH_SHORT).show();
            }
        });
    }
}
