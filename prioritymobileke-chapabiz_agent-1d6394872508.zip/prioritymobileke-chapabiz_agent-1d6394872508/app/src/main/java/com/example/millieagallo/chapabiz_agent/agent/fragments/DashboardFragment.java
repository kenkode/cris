package com.example.millieagallo.chapabiz_agent.agent.fragments;

import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import com.example.millieagallo.chapabiz_agent.R;
import com.example.millieagallo.chapabiz_agent.agent.entities.Summary;
import com.example.millieagallo.chapabiz_agent.helpers.CbSession;
import com.example.millieagallo.chapabiz_agent.retrofit.RetrofitSetup;
import okhttp3.ResponseBody;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class DashboardFragment extends Fragment {

    private CbSession session;

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        session = new CbSession(getContext());
    }

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.agent_dashboard, container, false);

        final TextView totalBusiness, verified;
        totalBusiness = view.findViewById(R.id.total);
        verified = view.findViewById(R.id.verified);

        Call<Summary> call = RetrofitSetup.retrofitInterface.agentSummary(session.getAgent().getId());
        call.enqueue(new Callback<Summary>() {
            @Override
            public void onResponse(Call<Summary> call, Response<Summary> response) {
                if (response.isSuccessful()) {
                    Summary summary = response.body();
                    totalBusiness.setText(summary.getTotal());
                    verified.setText(summary.getVerified());
                }

            }

            @Override
            public void onFailure(Call<Summary> call, Throwable t) {

            }
        });

        return view;
    }
}
