package com.example.millieagallo.chapabiz_agent.agent.fragments;

import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.design.widget.TextInputLayout;
import android.support.v4.app.Fragment;
import android.support.v7.app.AppCompatActivity;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ProgressBar;
import android.widget.Toast;

import com.google.gson.Gson;
import com.makeramen.roundedimageview.RoundedImageView;
import com.squareup.picasso.Picasso;

import com.example.millieagallo.chapabiz_agent.R;
//import com.example.millieagallo.chapabiz_agent.activities.LoginActivity;
import com.example.millieagallo.chapabiz_agent.agent.Agent;
import com.example.millieagallo.chapabiz_agent.agent.activities.AgentHome;
import com.example.millieagallo.chapabiz_agent.helpers.CbSession;
import com.example.millieagallo.chapabiz_agent.retrofit.RetrofitSetup;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class ProfileFragment extends AppCompatActivity {

    private TextInputLayout phone, email, name;
    private CbSession session;

//    public interface Clicked {
//        void pictureClicked(RoundedImageView roundedImageView, ProgressBar progressBar);
//    }
//
//    private Clicked clicked;
//
//    @Override
//    public void onAttach(Context context) {
//        super.onAttach(context);
//        clicked = (Clicked) context;
//    }
//
//    @Override
//    public void onCreate(@Nullable Bundle savedInstanceState) {
//        super.onCreate(savedInstanceState);
//        session = new CbSession(getContext());
//        setHasOptionsMenu(true);
//    }

   // @Nullable
    @Override
    protected void onCreate( Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.agent_activity_first);

        session = new CbSession(this);

        final RoundedImageView roundedImageView = findViewById(R.id.imageView);
//        if (session.getAgent().getPicture() != null) {
//            Picasso.with(ProfileFragment.this).load(session.getAgent().getPicture()).into(roundedImageView);
//        }

        final ProgressBar progressBar = findViewById(R.id.progress_bar);

//        roundedImageView.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View view) {
//                clicked.pictureClicked(roundedImageView, progressBar);
//            }
//        });

        phone = findViewById(R.id.phone);
        email = findViewById(R.id.email);
        name = findViewById(R.id.name);

        Agent agent = session.getAgent();
        phone.getEditText().setText(agent.getPhone());
        email.getEditText().setText(agent.getEmail());
        name.getEditText().setText(agent.getName());

        String url = agent.getPicture();
        if(url == null) {
            url = "Image";
        }

        Picasso.with(ProfileFragment.this).load(url).placeholder(R.drawable.splash_logo).into(roundedImageView);

      //  return view;
    }

    public void button(View view)
    {
        Kawangwa();

    }
    public boolean Kawangwa() {

                try {
                    String strName = name.getEditText().getText().toString().trim();
                    String strEmail = email.getEditText().getText().toString().trim();
                    String strPhone = phone.getEditText().getText().toString().trim();
                    String agent = session.getAgent().getId();

                    if (TextUtils.isEmpty(strEmail) || TextUtils.isEmpty(strPhone) || TextUtils.isEmpty(strName)) {
                        Toast.makeText(ProfileFragment.this, "Provide all the details", Toast.LENGTH_SHORT).show();
                        return false;
                    }

                    Agent agent1 = new Agent();
                    agent1.setPhone(strPhone);
                    agent1.setName(strName);
                    agent1.setEmail(strEmail);

                    final ProgressDialog progressDialog1 = new ProgressDialog(ProfileFragment.this);
                    progressDialog1.setIndeterminate(true);
                    progressDialog1.setMessage("Updating..");
                    progressDialog1.show();

                    Call<Agent> updateCall = RetrofitSetup.retrofitInterface.updateAgent(agent, new Gson().toJson(agent1));
                    updateCall.enqueue(new Callback<Agent>() {
                        @Override
                        public void onResponse(Call<Agent> call, Response<Agent> response) {
                            if (response.isSuccessful()) {
                                Agent agent2 = response.body();
//                                switch (agent2) {
//                                    case 200:
                                        session.setAgent(agent2);
                                        onStart();
//                                        break;
//                                    case 302:
//
//                                        break;
//                                }

                                Toast.makeText(ProfileFragment.this, "Update Successful", Toast.LENGTH_SHORT).show();
                            } else {
                                Toast.makeText(ProfileFragment.this, "Update failed, try again later", Toast.LENGTH_SHORT).show();
                            }
                            progressDialog1.dismiss();
                        }

                        @Override
                        public void onFailure(Call<Agent> call, Throwable t) {
                            progressDialog1.dismiss();
                            Toast.makeText(ProfileFragment.this, "Updated failed, try again later", Toast.LENGTH_SHORT).show();
                        }
                    });

                } catch (Exception ignored) {
                }

               // break;
        return false;
    }
      //  return super.onOptionsItemSelected(item);
   // }

    @Override
    public void onStart() {
        super.onStart();
    }
}
