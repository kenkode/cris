package com.example.millieagallo.chapabiz_agent.business;

import java.util.Arrays;
import java.util.List;

public class Constants {

    public static List<String> extensions = Arrays.asList("jpg", "png", "jpeg");

    public static String DIRECTORY_NAME = "Chapabiz Directory";

}
