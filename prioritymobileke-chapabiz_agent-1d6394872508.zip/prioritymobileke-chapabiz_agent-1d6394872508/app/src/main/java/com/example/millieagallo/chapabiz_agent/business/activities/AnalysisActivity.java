package com.example.millieagallo.chapabiz_agent.business.activities;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.example.millieagallo.chapabiz_agent.R;

public class AnalysisActivity extends AppCompatActivity {

    private TextView name, type, description, status;
//    private LinearLayout

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_analysis);


    }
}
