package com.example.millieagallo.chapabiz_agent.business.activities;

import android.Manifest;
import android.app.ProgressDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Bundle;
import android.os.Environment;
import android.os.Handler;
import android.provider.MediaStore;
import android.provider.OpenableColumns;
import android.support.design.widget.FloatingActionButton;
import android.support.design.widget.Snackbar;
import android.support.design.widget.TabLayout;
import android.support.v4.app.ActivityCompat;
import android.support.v4.app.FragmentTransaction;
import android.support.v4.content.ContextCompat;
import android.support.v4.content.FileProvider;
import android.support.v7.app.AlertDialog;
import android.util.Config;
import android.util.Log;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.support.design.widget.NavigationView;
import android.support.v4.view.GravityCompat;
import android.support.v4.widget.DrawerLayout;
import android.support.v7.app.ActionBarDrawerToggle;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import com.example.millieagallo.chapabiz_agent.activities.AgentLogin;
import com.google.gson.Gson;
import com.ipaulpro.afilechooser.utils.FileUtils;
import com.makeramen.roundedimageview.RoundedImageView;
import com.qiscus.sdk.Qiscus;
import com.qiscus.sdk.data.model.QiscusAccount;

import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.client.ClientProtocolException;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpPost;
import org.apache.http.entity.mime.content.FileBody;
import org.apache.http.entity.mime.content.StringBody;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.util.EntityUtils;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

import de.hdodenhof.circleimageview.CircleImageView;
import com.example.millieagallo.chapabiz_agent.BuildConfig;
import com.example.millieagallo.chapabiz_agent.Constants;
import com.example.millieagallo.chapabiz_agent.R;
//import com.example.millieagallo.chapabiz_agent.activities.LoginActivity;
//import com.example.millieagallo.chapabiz_agent.activities.MainLogin;
import com.example.millieagallo.chapabiz_agent.agent.fragments.BusinessDetails;
import com.example.millieagallo.chapabiz_agent.business.adapters.PhotoAdapter;
import com.example.millieagallo.chapabiz_agent.business.entities.Business;
import com.example.millieagallo.chapabiz_agent.business.fragments.HomeFragment;
import com.example.millieagallo.chapabiz_agent.business.fragments.ImageFragment;
import com.example.millieagallo.chapabiz_agent.business.fragments.MessageFragment;
import com.example.millieagallo.chapabiz_agent.business.fragments.PhotoFragment;
import com.example.millieagallo.chapabiz_agent.business.fragments.ProfileFragment;
import com.example.millieagallo.chapabiz_agent.entities.Photo;
import com.example.millieagallo.chapabiz_agent.entities.User;
import com.example.millieagallo.chapabiz_agent.helpers.AndroidMultiPartEntity;
import com.example.millieagallo.chapabiz_agent.helpers.CbSession;
import com.example.millieagallo.chapabiz_agent.helpers.FilePathResolver;
import com.example.millieagallo.chapabiz_agent.helpers.GenericFileProvider;
import com.example.millieagallo.chapabiz_agent.helpers.ProgressRequestBody;
import com.example.millieagallo.chapabiz_agent.helpers.UploadFile;
import com.example.millieagallo.chapabiz_agent.retrofit.RetrofitSetup;
//import com.example.millieagallo.chapabiz_agent.shopper.activities.BusinessDetailsActivity;
import okhttp3.MediaType;
import okhttp3.MultipartBody;
import okhttp3.RequestBody;
import okhttp3.ResponseBody;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

import static android.provider.MediaStore.Files.FileColumns.MEDIA_TYPE_IMAGE;
import static com.example.millieagallo.chapabiz_agent.business.Constants.DIRECTORY_NAME;
import static com.example.millieagallo.chapabiz_agent.retrofit.EndPoint.BASE_URL;
import static com.example.millieagallo.chapabiz_agent.retrofit.EndPoint.UPLOAD_FILE;

public class BusinessActivity extends AppCompatActivity implements
        PhotoFragment.Clicked,
        BusinessDetails.Clicked,
        PhotoAdapter.Clicked,
        ImageFragment.Clicked {

    private Toolbar toolbar;
    private TextView title;
    private TabLayout tabLayout;
    private static final int CAMERA_CAPTURE_IMAGE_REQUEST_CODE = 100;
    private static final int CAMERA_CAPTURE_VIDEO_REQUEST_CODE = 200;

    private static final int MY_PERMISSIONS_REQUEST_WRITE_EXTERNAL_STORAGE = 800;

    public static final int MEDIA_TYPE_IMAGE = 1;
    public static final int MEDIA_TYPE_VIDEO = 2;
    public static final int FILE = 22;
    public static final int LOGO_MEDIA_FILE = 25;

    private String path;
    private String business;

    boolean doubleBackToExitPressedOnce = false;

    private Uri fileUri; // file url to store image/video
    private ProgressBar progressBar;
    private TextView progressText;
    private ImageView businessImage;
    private AlertDialog.Builder builder;
    private CbSession session;
    long totalSize = 0;
    private RoundedImageView logoImage;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.business_layout);

        session = new CbSession(this);

        if (session.getUser() == null) {
            String id = session.getBusiness().getId();
            String name = session.getBusiness().getName();
            String email = session.getBusiness().getEmail();
            User user = new User(id, name, email);
            session.storeUser(user);
        }

        Qiscus.setUser(session.getBusiness().getId(), session.getBusiness().getEmail())
                .withUsername(session.getBusiness().getName())
                .withAvatarUrl(session.getBusiness().getImage())
                .save(new Qiscus.SetUserListener() {
                    @Override
                    public void onSuccess(QiscusAccount qiscusAccount) {
                        //on success followup
                    }

                    @Override
                    public void onError(Throwable throwable) {
                        //do anything if error occurs
                    }
                });

        tabLayout = findViewById(R.id.tab_layout);

        toolbar = findViewById(R.id.toolbar);

        title = findViewById(R.id.title);

        setSupportActionBar(toolbar);

        tabLayout.addOnTabSelectedListener(new TabLayout.OnTabSelectedListener() {
            @Override
            public void onTabSelected(TabLayout.Tab tab) {
                switch (tab.getPosition()) {
                    case 0:
                        startHomeFragment();
                        break;
                    case 1:
                        startMessageFragment();
                        break;
                    case 2:
                        startPhotoFragment();
                        break;
                    case 3:
                        startProfileFragment();
                        break;
                }
            }

            @Override
            public void onTabUnselected(TabLayout.Tab tab) {

            }

            @Override
            public void onTabReselected(TabLayout.Tab tab) {
                switch (tab.getPosition()) {
                    case 0:
                        startHomeFragment();
                        break;
                    case 1:
                        startMessageFragment();
                        break;
                    case 2:
                        startPhotoFragment();
                        break;
                    case 3:
                        startProfileFragment();
                        break;
                }
            }
        });

        HomeFragment homeFragment = new HomeFragment();
        changeToolbarTitle("Home");
        FragmentTransaction fragmentTransaction = getSupportFragmentManager().beginTransaction();
        fragmentTransaction.add(R.id.business_content_frame, homeFragment);
        fragmentTransaction.setTransition(FragmentTransaction.TRANSIT_FRAGMENT_FADE);
        fragmentTransaction.commit();

    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.business, menu);
        super.onCreateOptionsMenu(menu);
        return false;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case R.id.logout:
                CbSession session = new CbSession(this);
                session.clear();
                startActivity(new Intent(BusinessActivity.this, AgentLogin.class));
                finish();
                Qiscus.clearUser();
                break;
        }
        return true;
    }

    @Override
    public void onBackPressed() {
        if (doubleBackToExitPressedOnce) {
            super.onBackPressed();
            return;
        }

        this.doubleBackToExitPressedOnce = true;
        Toast.makeText(this, "Press again to exit", Toast.LENGTH_SHORT).show();

        new Handler().postDelayed(new Runnable() {

            @Override
            public void run() {
                doubleBackToExitPressedOnce=false;
            }
        }, 2000);
    }

    private void startHomeFragment() {
        changeToolbarTitle("Home");
        HomeFragment homeFragment = new HomeFragment();
        FragmentTransaction fragmentTransaction = getSupportFragmentManager().beginTransaction();
        fragmentTransaction.replace(R.id.business_content_frame, homeFragment);
        fragmentTransaction.setTransition(FragmentTransaction.TRANSIT_FRAGMENT_FADE);
        fragmentTransaction.commit();
    }

    private void startMessageFragment() {
        changeToolbarTitle("Messages");
//        startActivity(new Intent(BusinessActivity.this, ChatActivity.class));
        MessageFragment messageFragment = new MessageFragment();
        FragmentTransaction messageFrag = getSupportFragmentManager().beginTransaction();
        messageFrag.replace(R.id.business_content_frame, messageFragment);
        messageFrag.setTransition(FragmentTransaction.TRANSIT_FRAGMENT_FADE);
        messageFrag.commit();
    }

    private void startProfileFragment() {
        changeToolbarTitle("Profile");
        BusinessDetails businessDetails = new BusinessDetails();
        Bundle bundle = new Bundle();
        bundle.putString("business", session.getBusiness().getId());
        businessDetails.setArguments(bundle);
        FragmentTransaction profFrag = getSupportFragmentManager().beginTransaction();
        profFrag.replace(R.id.business_content_frame, businessDetails);
        profFrag.setTransition(FragmentTransaction.TRANSIT_FRAGMENT_FADE);
        profFrag.commit();
    }

    private void startPhotoFragment() {
        changeToolbarTitle("Photos");
        PhotoFragment photoFragment = new PhotoFragment();
        FragmentTransaction profFrag = getSupportFragmentManager().beginTransaction();
        profFrag.replace(R.id.business_content_frame, photoFragment);
        profFrag.setTransition(FragmentTransaction.TRANSIT_FRAGMENT_FADE);
        profFrag.commit();
    }

    @Override
    public void takePhoto(ProgressBar progressBar, TextView progressText, String business) {
        this.progressBar = progressBar;
        this.progressText = progressText;
        this.business = business;
        Intent getContentIntent = FileUtils.createGetContentIntent();
        Intent intent = Intent.createChooser(getContentIntent, "Select a file");
        startActivityForResult(intent, 25);
    }

    private File createImageFile() throws IOException {
        String timeStamp = new SimpleDateFormat("yyyyMMdd_HHmmss", Locale.getDefault()).format(new Date());
        String imageFileName = "JPEG_" + timeStamp + "_";

        File storageDir = new File(Environment.getExternalStoragePublicDirectory(
                Environment.DIRECTORY_DCIM), "Camera");
        if (!storageDir.exists()) {
            if (!storageDir.mkdirs()) {
                Log.e("err", "Failed to create directory");
            }
        }

        File image = File.createTempFile(
                imageFileName,  /* prefix */
                ".jpg",         /* suffix */
                storageDir      /* directory */
        );

        path = "file:" + image.getAbsolutePath();
        Log.e("generated_filename", path);

        return image;
    }

    @Override
    public void onRequestPermissionsResult(int requestCode,
                                           String permissions[], int[] grantResults) {
        switch (requestCode) {
            case MY_PERMISSIONS_REQUEST_WRITE_EXTERNAL_STORAGE: {
                if (grantResults.length > 0
                        && grantResults[0] == PackageManager.PERMISSION_GRANTED
                        && grantResults[1] == PackageManager.PERMISSION_GRANTED) {

                    Intent getContentIntent = FileUtils.createGetContentIntent();
                    Intent intent = Intent.createChooser(getContentIntent, "Select a file");
                    startActivityForResult(intent, 0);

                } else {
                    Toast toast = Toast.makeText(this, "Permission required", Toast.LENGTH_LONG);
                    toast.setGravity(Gravity.CENTER, 0, 0);
                    toast.show();
                }
                return;
            }

            // other 'case' lines to check for other
            // permissions this app might request
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, final Intent data) {
        if (resultCode == RESULT_OK) {
            final Uri uri = data.getData();

            final String path = FileUtils.getPath(this, uri);
            switch (requestCode) {
                case 0:
                    AlertDialog.Builder builder = new AlertDialog.Builder(this)
                            .setPositiveButton("Upload", new DialogInterface.OnClickListener() {
                                @Override
                                public void onClick(DialogInterface dialogInterface, int i) {

                                    if (path != null && FileUtils.isLocal(path)) {
                                        File file = new File(path);
                                        UploadFile uploadFile = new UploadFile(BusinessActivity.this, 0, progressText, progressBar, business, file);
                                        uploadFile.setRoundedImageView(logoImage);
                                        uploadFile.setFragment(getSupportFragmentManager());
                                        uploadFile.execute();
                                    }

                                }
                            })
                            .setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
                                @Override
                                public void onClick(DialogInterface dialogInterface, int i) {
                                    dialogInterface.dismiss();
                                }
                            });
                    builder.setCancelable(false);
                    View view = LayoutInflater.from(this).inflate(R.layout.photo_item, null, false);
                    ImageView imageView = view.findViewById(R.id.photo);
                    imageView.setScaleType(ImageView.ScaleType.FIT_CENTER);

                    Bitmap photo = BitmapFactory.decodeFile(path);
                    imageView.setImageBitmap(photo);

                    builder.setView(view);

                    builder.show();
                    break;
                case FILE:
                    if (path != null && FileUtils.isLocal(path)) {
                        File file = new File(path);
                        UploadFile uploadFile = new UploadFile(this, requestCode, progressText, progressBar, session.getBusiness().getId(), file);
                        uploadFile.execute();
                        session.getBusiness().setCertificateNo(file.getName());
                    }
                    break;
                case LOGO_MEDIA_FILE:
                    if (path != null && FileUtils.isLocal(path)) {
                        File file = new File(path);
                        UploadFile uploadFile = new UploadFile(this, requestCode, progressText, progressBar, session.getBusiness().getId(), file);
                        uploadFile.setImage(businessImage);
                        uploadFile.execute();
                    }
                    break;

            }

        } else if (resultCode == RESULT_CANCELED) {
            Toast.makeText(getApplicationContext(),
                    "Upload Cancelled", Toast.LENGTH_SHORT)
                    .show();

        } else {
            Toast.makeText(getApplicationContext(),
                    "Failed to upload", Toast.LENGTH_SHORT)
                    .show();
        }
    }

    @Override
    protected void onSaveInstanceState(Bundle outState) {
        super.onSaveInstanceState(outState);
        outState.putParcelable("file_uri", fileUri);
    }

    @Override
    protected void onRestoreInstanceState(Bundle savedInstanceState) {
        super.onRestoreInstanceState(savedInstanceState);
        fileUri = savedInstanceState.getParcelable("file_uri");
    }

    @Override
    public void logoClicked(ProgressBar progressBar, TextView progressText, RoundedImageView businessImage, String business) {
        this.progressBar = progressBar;
        this.progressText = progressText;
        this.business = business;
        this.logoImage = businessImage;
        if (ContextCompat.checkSelfPermission(this, // request permission when it is not granted.
                Manifest.permission.WRITE_EXTERNAL_STORAGE)
                != PackageManager.PERMISSION_GRANTED || ContextCompat.checkSelfPermission(this, // request permission when it is not granted.
                Manifest.permission.CAMERA)
                != PackageManager.PERMISSION_GRANTED) {

            ActivityCompat.requestPermissions(this,
                    new String[]{Manifest.permission.WRITE_EXTERNAL_STORAGE, Manifest.permission.CAMERA},
                    MY_PERMISSIONS_REQUEST_WRITE_EXTERNAL_STORAGE);

            return;
        }

        Intent getContentIntent = FileUtils.createGetContentIntent();
        Intent intent = Intent.createChooser(getContentIntent, "Select a file");
        startActivityForResult(intent, 0);
    }

    @Override
    public void uploadFile(ProgressBar progressBar, TextView progressText, String business) {
        this.progressText = progressText;
        this.progressBar = progressBar;

        Intent getContentIntent = FileUtils.createGetContentIntent();

        Intent intent = Intent.createChooser(getContentIntent, "Select a file");
        startActivityForResult(intent, FILE);
    }

    @Override
    public void clicked(Photo photo) {
        ImageFragment imageFragment = new ImageFragment();
        Bundle bundle = new Bundle();
        bundle.putString("url", photo.getUrl());
        bundle.putString("id", photo.getId());
        imageFragment.setArguments(bundle);
        changeToolbarTitle("Photos");
        FragmentTransaction fragmentTransaction = getSupportFragmentManager().beginTransaction();
        fragmentTransaction.replace(R.id.business_content_frame, imageFragment);
        fragmentTransaction.setTransition(FragmentTransaction.TRANSIT_ENTER_MASK);
        fragmentTransaction.commit();
    }

    @Override
    public void clicked(String id) {
        final ProgressDialog progressDialog = new ProgressDialog(this);
        progressDialog.setMessage("Deleting...");
        progressDialog.setIndeterminate(true);
        progressDialog.setCancelable(false);
        progressDialog.show();
        Call<ResponseBody> call = RetrofitSetup.retrofitInterface.deletePhoto(id);
        call.enqueue(new Callback<ResponseBody>() {
            @Override
            public void onResponse(Call<ResponseBody> call, Response<ResponseBody> response) {
                if (response.isSuccessful()) {
                    Toast.makeText(BusinessActivity.this, "Deleted photo", Toast.LENGTH_SHORT).show();
                    startPhotoFragment();
                } else {
                    Toast.makeText(BusinessActivity.this, "Unable to delete photo", Toast.LENGTH_SHORT).show();
                }
                progressDialog.dismiss();
            }

            @Override
            public void onFailure(Call<ResponseBody> call, Throwable t) {
                progressDialog.dismiss();
                Toast.makeText(BusinessActivity.this, "Unable to delete photo", Toast.LENGTH_SHORT).show();
            }
        });
    }

    public void changeToolbarTitle(String title) {
        this.title.setText(title);
    }

}
