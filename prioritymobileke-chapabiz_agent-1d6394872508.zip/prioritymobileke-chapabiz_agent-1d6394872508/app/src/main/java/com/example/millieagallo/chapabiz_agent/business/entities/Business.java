package com.example.millieagallo.chapabiz_agent.business.entities;

import com.google.gson.annotations.SerializedName;

import java.util.ArrayList;

import com.example.millieagallo.chapabiz_agent.entities.Response;

public class Business extends Response{

    @SerializedName("id")
    private String id;
    @SerializedName("business_name")
    private String name;
    @SerializedName("business_description")
    private String description;
    @SerializedName("business_email")
    private String email;
    @SerializedName("commissions")
    private String commissions;
    @SerializedName("business_phone")
    private String phone;
    @SerializedName("county_name")
    private String county;
    @SerializedName("town")
    private String town;
    @SerializedName("street_address")
    private String streetAddress;
    @SerializedName("operations_since")
    private String operationsSince;
    @SerializedName("certificate_no")
    private String certificateNo;
    @SerializedName("img")
    private String image;
    @SerializedName("category")
    private String category;

    @SerializedName("distance")
    private String distance;
   // @SerializedName("verified")
    //private String status;
    @SerializedName("photos")
    private ArrayList<String> photos;
//    @SerializedName("verified")
//    private int verified;
    @SerializedName("counter")
    private int counter;
    private String timestamps;
    private int verified, searches, converses;
    private double latitude, longitude;

    public String getTimestamps() {
        return timestamps;
    }

    public void setTimestamps(String timestamps) {
        this.timestamps = timestamps;
    }

    public String getDistance() {
        return distance;
    }

    public void setDistance(String distance) {
        this.distance = distance;
    }

    public ArrayList<String> getPhotos() {
        return photos;
    }

    public void setPhotos(ArrayList<String> photos) {
        this.photos = photos;
    }

    public int getVerified() {
        return verified;
    }

    public void setVerified(int verified) {
        this.verified = verified;
    }

    public double getLatitude() {
        return latitude;
    }

    public void setLatitude(double latitude) {
        this.latitude = latitude;
    }

    public double getLongitude() {
        return longitude;
    }

    public void setLongitude(double longitude) {
        this.longitude = longitude;
    }

    public int getCounter() {
        return counter;
    }

    public void setCounter(int counter) {
        this.counter = counter;
    }

//    public boolean isVerified() {
//        return verified;
//    }
//
//    public void setVerified(boolean verified) {
//        this.verified = verified;
//    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getCounty() {
        return county;
    }

    public void setCounty(String county) {
        this.county = county;
    }

    public String getTown() {
        return town;
    }

    public void setTown(String town) {
        this.town = town;
    }

    public String getStreetAddress() {
        return streetAddress;
    }

    public void setStreetAddress(String streetAddress) {
        this.streetAddress = streetAddress;
    }

    public String getOperationsSince() {
        return operationsSince;
    }

    public void setOperationsSince(String operationsSince) {
        this.operationsSince = operationsSince;
    }

    public String getCertificateNo() {
        return certificateNo;
    }

    public void setCertificateNo(String certificateNo) {
        this.certificateNo = certificateNo;
    }

    public String getImage() {
        return image;
    }

    public void setImage(String image) {
        this.image = image;
    }

    public String getCategory() {
        return category;
    }

    public void setCategory(String category) {
        this.category = category;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getCommissions(){
        return commissions;
    }

    public void setCommissions(String commissions)
    {
        this.commissions = commissions;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getPhone() {
        return phone;
    }

    public void setPhone(String phone) {
        this.phone = phone;
    }

}
