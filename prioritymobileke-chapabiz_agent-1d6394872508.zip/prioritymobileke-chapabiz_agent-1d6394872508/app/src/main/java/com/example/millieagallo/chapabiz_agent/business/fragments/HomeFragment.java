package com.example.millieagallo.chapabiz_agent.business.fragments;

import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.support.v4.content.ContextCompat;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.squareup.picasso.Picasso;

import com.example.millieagallo.chapabiz_agent.R;
import com.example.millieagallo.chapabiz_agent.business.entities.Business;
import com.example.millieagallo.chapabiz_agent.helpers.CbSession;

public class HomeFragment extends Fragment {

    private CbSession session;

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        session = new CbSession(getContext());
        setHasOptionsMenu(true);
    }

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.activity_analysis, container, false);

        TextView name, about, verified, converse, searches;
        ImageView logo;

        logo = view.findViewById(R.id.business_logo);

        name = view.findViewById(R.id.business_name);
        about = view.findViewById(R.id.about);
        verified = view.findViewById(R.id.verified);
        converse = view.findViewById(R.id.converse);
        searches = view.findViewById(R.id.searches);

        Business business = session.getBusiness();
        name.setText(business.getName());
        about.setText(business.getDescription());

        converse.setText("0");
        searches.setText("0");

        Picasso.with(getContext()).load(business.getImage()).placeholder(ContextCompat.getDrawable(getContext(), R.drawable.ic_chapabiz_logo_vert)).into(logo);

        if (business.getVerified() == 1) {
            verified.setText("Verified");
            verified.setTextColor(ContextCompat.getColor(getContext(), R.color.colorGreenAccent));
        } else {
            verified.setText("Not Verified");
            verified.setTextColor(ContextCompat.getColor(getContext(), R.color.colorRedAccent));
        }

        return view;
    }

}
