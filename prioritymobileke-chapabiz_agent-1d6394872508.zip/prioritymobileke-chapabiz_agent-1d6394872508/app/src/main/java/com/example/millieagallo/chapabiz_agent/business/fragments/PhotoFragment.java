package com.example.millieagallo.chapabiz_agent.business.fragments;

import android.content.Context;
import android.content.res.Resources;
import android.graphics.Point;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.design.widget.FloatingActionButton;
import android.support.v4.app.Fragment;
import android.support.v7.widget.GridLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.text.TextUtils;
import android.util.TypedValue;
import android.view.Display;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.widget.GridView;
import android.widget.ProgressBar;
import android.widget.TextView;

import java.util.ArrayList;

import com.example.millieagallo.chapabiz_agent.R;
import com.example.millieagallo.chapabiz_agent.business.adapters.PhotoAdapter;
import com.example.millieagallo.chapabiz_agent.entities.Photo;
import com.example.millieagallo.chapabiz_agent.helpers.CbSession;
import com.example.millieagallo.chapabiz_agent.retrofit.RetrofitSetup;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class PhotoFragment extends Fragment {

    public interface Clicked {
        void takePhoto(ProgressBar progressBar, TextView progressText, String business);
    }

    private Clicked clicked;
    private ProgressBar progressBar;
    private TextView progressText;
    private String bsId;
    private CbSession session;

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        session = new CbSession(getContext());
        setHasOptionsMenu(true);
    }

    @Override
    public void onCreateOptionsMenu(Menu menu, MenuInflater inflater) {
        if(session.getAgent() != null) {
            inflater.inflate(R.menu.photo_menu, menu);
        }
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case R.id.add_photo:
                clicked.takePhoto(progressBar, progressText, bsId);
                break;
        }

        return false;
    }

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.business_photo_fragment, container, false);

        final GridView gridView = view.findViewById(R.id.photos);

        progressBar = view.findViewById(R.id.progress_bar);
        progressText = view.findViewById(R.id.progress_text);

        Resources r = getResources();
        float padding = TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP,
                8, r.getDisplayMetrics());

        int columnWidth = (int) ((getScreenWidth() - ((3 + 1) * padding)) / 3);

        gridView.setNumColumns(3);
        gridView.setColumnWidth(columnWidth);
        gridView.setStretchMode(GridView.NO_STRETCH);
        gridView.setPadding((int) padding, (int) padding, (int) padding,
                (int) padding);
        gridView.setHorizontalSpacing((int) padding);
        gridView.setVerticalSpacing((int) padding);

        bsId = new CbSession(getContext()).getBusiness().getId();
        if(TextUtils.isEmpty(bsId)) {
            Bundle bundle = getArguments();
            if(bundle != null) {
                bsId = bundle.getString("business");
            }
        }

        Call<ArrayList<Photo>> call = RetrofitSetup.retrofitInterface.getPhotos(bsId);
        call.enqueue(new Callback<ArrayList<Photo>>() {
            @Override
            public void onResponse(Call<ArrayList<Photo>> call, Response<ArrayList<Photo>> response) {
                if (response.isSuccessful()) {
                    ArrayList<Photo> photos = response.body();
                    PhotoAdapter photoAdapter = new PhotoAdapter(getContext(), photos);
                    gridView.setAdapter(photoAdapter);
                }
            }

            @Override
            public void onFailure(Call<ArrayList<Photo>> call, Throwable t) {
                t.printStackTrace();
            }
        });

        FloatingActionButton fab = view.findViewById(R.id.fab);
        fab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                clicked.takePhoto(progressBar, progressText, bsId);
            }
        });

        return view;
    }

    public int getScreenWidth() {
        int columnWidth;
        WindowManager wm = (WindowManager) getContext()
                 .getSystemService(Context.WINDOW_SERVICE);
        Display display = wm.getDefaultDisplay();

        final Point point = new Point();
        try {
            display.getSize(point);
        } catch (java.lang.NoSuchMethodError ignore) { // Older device
            point.x = display.getWidth();
            point.y = display.getHeight();
        }
        columnWidth = point.x;
        return columnWidth;
    }

    @Override
    public void onAttach(Context context) {
        super.onAttach(context);
       clicked = (Clicked) context;
    }
}
