package com.example.millieagallo.chapabiz_agent.gcm;

import android.content.Intent;
import android.support.v4.content.LocalBroadcastManager;
import android.util.Log;
import android.widget.Toast;

import com.google.android.gms.iid.InstanceIDListenerService;
import com.google.firebase.iid.FirebaseInstanceId;
import com.google.firebase.iid.FirebaseInstanceIdService;

import com.example.millieagallo.chapabiz_agent.Constants;
import com.example.millieagallo.chapabiz_agent.helpers.CbSession;
import com.example.millieagallo.chapabiz_agent.retrofit.RetrofitSetup;
import okhttp3.ResponseBody;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class MyInstanceIDListenerService extends FirebaseInstanceIdService {

    private static final String TAG = MyInstanceIDListenerService.class.getSimpleName();

    /**
     * Called if InstanceID token is updated. This may occur if the security of
     * the previous token had been compromised. This call is initiated by the
     * InstanceID provider.
     */
    @Override
    public void onTokenRefresh() {
        Toast.makeText(this, "New token", Toast.LENGTH_SHORT).show();
        String refreshedToken = FirebaseInstanceId.getInstance().getToken();
        CbSession session = new CbSession(getApplicationContext());
        Log.e(TAG, refreshedToken);
        String user = session.getUser().getId();
        String email = session.getUser().getEmail();
        Call<ResponseBody> call = RetrofitSetup.retrofitInterface.sendToken(user, refreshedToken, email);
        call.enqueue(new Callback<ResponseBody>() {
            @Override
            public void onResponse(Call<ResponseBody> call, Response<ResponseBody> response) {
                if (response.isSuccessful()) {
                    Intent registrationComplete = new Intent(Constants.SENT_TOKEN_TO_SERVER);
                    LocalBroadcastManager.getInstance(getApplicationContext()).sendBroadcast(registrationComplete);
                }
            }

            @Override
            public void onFailure(Call<ResponseBody> call, Throwable t) {
                t.printStackTrace();
            }
        });

    }
}