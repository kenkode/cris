package com.example.millieagallo.chapabiz_agent.helpers;

import android.support.v4.content.FileProvider;

public class GenericFileProvider extends FileProvider {}