package com.example.millieagallo.chapabiz_agent.helpers;

import android.content.Context;
import android.graphics.drawable.Drawable;
import android.support.v4.content.ContextCompat;
import android.widget.Button;

import java.util.ArrayList;

import com.example.millieagallo.chapabiz_agent.R;

public class LoginUserSelect {

    private Context context;
    private int selected, deselected;

    public LoginUserSelect(Context context, int selected, int deselected, ArrayList<Button> buttons) {
        this.context = context;
        this.selected = selected;
        this.deselected = deselected;
        for (Button button :
                buttons) {
//            button.setBackground(int);
            button.setBackgroundColor(deselected);
        }
    }

    public void setSelected(Button button) {
        button.setBackgroundColor(selected);
        CbSession session = new CbSession(context);
        session.setLastSelected(button.getTag().toString());
    }

}
