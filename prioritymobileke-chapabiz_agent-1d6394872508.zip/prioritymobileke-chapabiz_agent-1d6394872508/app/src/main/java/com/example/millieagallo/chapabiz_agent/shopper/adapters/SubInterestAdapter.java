package com.example.millieagallo.chapabiz_agent.shopper.adapters;

import android.content.Context;
import android.net.Uri;
import android.support.design.widget.Snackbar;
import android.support.v4.content.ContextCompat;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import com.example.millieagallo.chapabiz_agent.R;
import com.example.millieagallo.chapabiz_agent.helpers.CbSession;
import com.example.millieagallo.chapabiz_agent.retrofit.RetrofitSetup;
import com.example.millieagallo.chapabiz_agent.shopper.entities.InterestDetail;
import com.makeramen.roundedimageview.RoundedImageView;
import com.squareup.picasso.Picasso;

import java.util.ArrayList;
import java.util.Random;

import okhttp3.ResponseBody;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class SubInterestAdapter extends RecyclerView.Adapter<SubInterestAdapter.ViewHolder> {

    private Context context;
    private ArrayList<InterestDetail> interests;
    private CbSession session;

    public SubInterestAdapter(Context context, ArrayList<InterestDetail> interests) {
        this.context = context;
        this.interests = interests;
        session = new CbSession(context);
    }

    @Override
    public SubInterestAdapter.ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(context).inflate(R.layout.shopper_interest_details_item, parent, false);
        return new SubInterestAdapter.ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(SubInterestAdapter.ViewHolder holder, int position) {
        InterestDetail interestDetail = interests.get(position);

        holder.name.setText(interestDetail.getName());
        //holder.imageView.set

        if (interestDetail.isSelected()) {
            holder.button.setText(" ");
            holder.button.setBackground(ContextCompat.getDrawable(context, R.drawable.interest_button_selected));
            holder.button.setTextColor(ContextCompat.getColor(context, android.R.color.black));
        }

        updateBackground(interestDetail.isSelected() ? 1 : 0, holder.button);

        String photoUrl = interestDetail.getPhoto();
        if(photoUrl == null) {
            photoUrl = "image";
        }

        Picasso.with(context).load(photoUrl)
                .placeholder(ContextCompat.getDrawable(context, R.drawable.ic_image_holder))
                .into(holder.imageView);
    }

    private void updateBackground(int state, Button button) {
        if (state == 1) {
            button.setText("**");
            button.setBackground(ContextCompat.getDrawable(context, R.drawable.interest_button_selected));
            button.setTextColor(ContextCompat.getColor(context, android.R.color.black));
        } else {
            button.setText("+");
            button.setBackground(ContextCompat.getDrawable(context, R.drawable.interest_button_deselected));
            button.setTextColor(ContextCompat.getColor(context, android.R.color.white));
        }
    }

    @Override
    public int getItemCount() {
        return interests.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder implements View.OnClickListener {

        public TextView name;
        public RoundedImageView imageView;
        public Button button;

        public ViewHolder(View view) {
            super(view);
            name = view.findViewById(R.id.name);
            imageView = view.findViewById(R.id.image);
            button = view.findViewById(R.id.select);
            button.setOnClickListener(this);
        }

        @Override
        public void onClick(View view) {
            InterestDetail interestDetail = interests.get(getAdapterPosition());
            interestDetail.setSelected(!interestDetail.isSelected());

            int state;

            if (interestDetail.isSelected()) {
                state = 1;
                Snackbar snackbar = Snackbar.make(name, String.format("%s added to homepage", interestDetail.getName()), Snackbar.LENGTH_LONG);
                snackbar.show();
            } else {
                state = 0;
            }

//            updateBackground(interestDetail, button);

         //   sendUpdate(Integer.parseInt(interestDetail.getId()), state, button);

        }
    }
//
//   // private void sendUpdate(int id, final int state, final Button button) {
//       // Call<ResponseBody> bodyCall = RetrofitSetup.retrofitInterface.updateInterest(session.getShopper().getId(), id, state);
//        bodyCall.enqueue(new Callback<ResponseBody>() {
//            @Override
//            public void onResponse(Call<ResponseBody> call, Response<ResponseBody> response) {
//                if (response.isSuccessful()) {
//                    updateBackground(state, button);
//                } else {
//                    Toast.makeText(context, "UnSuccessful", Toast.LENGTH_SHORT).show();
//                }
//            }
//
//            @Override
//            public void onFailure(Call<ResponseBody> call, Throwable t) {
//                Toast.makeText(context, "UnSuccessful", Toast.LENGTH_SHORT).show();
//            }
//        });
//    }

}
