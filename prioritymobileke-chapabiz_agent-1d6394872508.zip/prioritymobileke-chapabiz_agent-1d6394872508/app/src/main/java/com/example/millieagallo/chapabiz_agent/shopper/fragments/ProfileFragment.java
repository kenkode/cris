//package ke.co.prioritymobile.chapabiz.shopper.fragments;
//
//import android.os.Bundle;
//import android.support.annotation.NonNull;
//import android.support.annotation.Nullable;
//import android.support.v4.app.Fragment;
//import android.support.v4.content.ContextCompat;
//import android.view.LayoutInflater;
//import android.view.View;
//import android.view.ViewGroup;
//import android.widget.ImageView;
//import android.widget.TextView;
//
//import com.makeramen.roundedimageview.RoundedImageView;
//import com.squareup.picasso.Picasso;
//
//import ke.co.prioritymobile.chapabiz.R;
//import ke.co.prioritymobile.chapabiz.helpers.CbSession;
//
//public class ProfileFragment extends Fragment {
//
//    @Nullable
//    @Override
//    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
//        View view = inflater.inflate(R.layout.profile_layout, container, false);
//        CbSession session = new CbSession(getContext());
//        TextView name = view.findViewById(R.id.name);
//        name.setText(session.getShopper().getName());
//        RoundedImageView imageView = view.findViewById(R.id.picture);
//        Picasso.with(getContext()).load(session.getShopper().getPicture())
//                .placeholder(ContextCompat.getDrawable(getContext(), R.drawable.ic_chapabiz_logo_vert))
//                .into(imageView);
//
//        return view;
//    }
//}
