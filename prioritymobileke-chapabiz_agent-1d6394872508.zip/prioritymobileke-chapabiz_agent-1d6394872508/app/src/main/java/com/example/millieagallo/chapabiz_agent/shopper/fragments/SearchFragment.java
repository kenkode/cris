//package ke.co.prioritymobile.chapabiz.shopper.fragments;
//
//import android.Manifest;
//import android.app.SearchManager;
//import android.content.Context;
//import android.content.DialogInterface;
//import android.content.pm.PackageManager;
//import android.os.Bundle;
//import android.support.annotation.NonNull;
//import android.support.annotation.Nullable;
//import android.support.design.widget.BottomSheetBehavior;
//import android.support.v4.app.ActivityCompat;
//import android.support.v4.app.Fragment;
//import android.support.v4.content.ContextCompat;
//import android.support.v7.app.AlertDialog;
//import android.support.v7.widget.CardView;
//import android.support.v7.widget.GridLayoutManager;
//import android.support.v7.widget.RecyclerView;
//import android.support.v7.widget.SearchView;
//import android.view.LayoutInflater;
//import android.view.Menu;
//import android.view.MenuInflater;
//import android.view.MenuItem;
//import android.view.View;
//import android.view.ViewGroup;
//import android.widget.LinearLayout;
//import android.widget.TextView;
//
//import com.google.android.gms.maps.CameraUpdateFactory;
//import com.google.android.gms.maps.GoogleMap;
//import com.google.android.gms.maps.MapView;
//import com.google.android.gms.maps.MapsInitializer;
//import com.google.android.gms.maps.OnMapReadyCallback;
//import com.google.android.gms.maps.SupportMapFragment;
//import com.google.android.gms.maps.model.BitmapDescriptorFactory;
//import com.google.android.gms.maps.model.CameraPosition;
//import com.google.android.gms.maps.model.LatLng;
//import com.google.android.gms.maps.model.MarkerOptions;
//
//import java.util.ArrayList;
//import java.util.Arrays;
//import java.util.Random;
//
//import ke.co.prioritymobile.chapabiz.R;
//import ke.co.prioritymobile.chapabiz.shopper.adapters.QuickInterestAdapter;
//import ke.co.prioritymobile.chapabiz.shopper.entities.Interest;
//import ke.co.prioritymobile.chapabiz.shopper.entities.InterestMarker;
//import ke.co.prioritymobile.chapabiz.shopper.sheets.BottomSheetFragment;
//
//public class SearchFragment extends Fragment {
//
//    private BottomSheetBehavior mBottomSheetBehavior;
//    MapView mMapView;
//    private GoogleMap googleMap;
//    ArrayList<InterestMarker> markerPoints;
//    private CardView interestContainer;
//    private BottomSheetBehavior sheetBehavior;
//
//    @Override
//    public void onCreate(@Nullable Bundle savedInstanceState) {
//        super.onCreate(savedInstanceState);
//        markerPoints = new ArrayList<InterestMarker>();
//
//        setHasOptionsMenu(true);
//
//        double latitude = 1.2921;
//        double longitude = 36.8219;
//
//        String[] placeNames = {"Nairobi", "Milimani", "Zone", "Urban"};
//
////        for (int i = 0; i < 4; i++) {
////            int rand = new Random().nextInt(2);
////            InterestMarker interestMarker = new InterestMarker();
////            LatLng latLng = new LatLng(latitude += rand, longitude += rand);
////            interestMarker.setName(placeNames[i]);
////            interestMarker.setDescription(placeNames[i]);
////            interestMarker.setLatLng(latLng);
////            markerPoints.add(interestMarker);
////        }
//
//    }
//
//    @Nullable
//    @Override
//    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
//        View view = inflater.inflate(R.layout.search_results, container, false);
//
//        LinearLayout layoutBottomSheet = (LinearLayout) view.findViewById(R.id.bottom_sheet);
//        sheetBehavior = BottomSheetBehavior.from(layoutBottomSheet);
//
//        sheetBehavior.setBottomSheetCallback(new BottomSheetBehavior.BottomSheetCallback() {
//            @Override
//            public void onStateChanged(@NonNull View bottomSheet, int newState) {
//                switch (newState) {
//                    case BottomSheetBehavior.STATE_HIDDEN:
//                        break;
//                    case BottomSheetBehavior.STATE_EXPANDED: {
//
//                    }
//                    break;
//                    case BottomSheetBehavior.STATE_COLLAPSED: {
//
//                    }
//                    break;
//                    case BottomSheetBehavior.STATE_DRAGGING:
//                        break;
//                    case BottomSheetBehavior.STATE_SETTLING:
//                        break;
//                }
//            }
//
//            @Override
//            public void onSlide(@NonNull View bottomSheet, float slideOffset) {
//
//            }
//        });
//
////        toggleBottomSheet.setOnClickListener(new View.OnClickListener() {
////            @Override
////            public void onClick(View view) {
////                if (sheetBehavior.getState() != BottomSheetBehavior.STATE_EXPANDED) {
////                    sheetBehavior.setState(BottomSheetBehavior.STATE_EXPANDED);
////                } else {
////                    sheetBehavior.setState(BottomSheetBehavior.STATE_COLLAPSED);
////                }
////            }
////        });
//
//        interestContainer = view.findViewById(R.id.interest_container);
//
//        mMapView = view.findViewById(R.id.map_view);
//        mMapView.onCreate(savedInstanceState);
//        mMapView.onResume();
//
//        try {
//            MapsInitializer.initialize(getActivity().getApplicationContext());
//        } catch (Exception e) {
//            e.printStackTrace();
//        }
//
//        mMapView.getMapAsync(new OnMapReadyCallback() {
//            @Override
//            public void onMapReady(GoogleMap mMap) {
//                googleMap = mMap;
//
//
//                if (checkLocationPermission()) {
//                    if (ContextCompat.checkSelfPermission(getActivity(),
//                            Manifest.permission.ACCESS_FINE_LOCATION)
//                            == PackageManager.PERMISSION_GRANTED) {
//
//                        googleMap.setMyLocationEnabled(true);
//                    }
//                }
//
//                googleMap.getUiSettings().setCompassEnabled(true);
//                googleMap.getUiSettings().setMyLocationButtonEnabled(true);
//                googleMap.getUiSettings().setRotateGesturesEnabled(false);
//
//                placeMarkers();
//
//            }
//        });
//
//        RecyclerView recyclerView = view.findViewById(R.id.list);
//        GridLayoutManager gridLayoutManager = new GridLayoutManager(getContext(), 3);
//        recyclerView.setLayoutManager(gridLayoutManager);
//
//        ArrayList<Interest> interests = new ArrayList<>();
//
//        String[] stringsInterests = {"Banks", "Retails", "Groceries", "Forex", "Hardware", "Hotels"};
//
//        return view;
//    }
//
//    @Override
//    public void onResume() {
//        super.onResume();
//        mMapView.onResume();
//    }
//
//    @Override
//    public void onPause() {
//        super.onPause();
//        mMapView.onPause();
//    }
//
//    @Override
//    public void onDestroy() {
//        super.onDestroy();
//        mMapView.onDestroy();
//    }
//
//    @Override
//    public void onLowMemory() {
//        super.onLowMemory();
//        mMapView.onLowMemory();
//    }
//
//    public boolean checkLocationPermission() {
//        if (ContextCompat.checkSelfPermission(getActivity(),
//                Manifest.permission.ACCESS_FINE_LOCATION)
//                != PackageManager.PERMISSION_GRANTED) {
//
//            if (ActivityCompat.shouldShowRequestPermissionRationale(getActivity(),
//                    Manifest.permission.ACCESS_FINE_LOCATION)) {
//
//                new AlertDialog.Builder(getActivity())
//                        .setTitle("")
//                        .setMessage("")
//                        .setPositiveButton("Ok", new DialogInterface.OnClickListener() {
//                            @Override
//                            public void onClick(DialogInterface dialogInterface, int i) {
//                                ActivityCompat.requestPermissions(getActivity(), new String[]
//                                        {Manifest.permission.ACCESS_FINE_LOCATION}, 1);
//                            }
//                        })
//                        .create()
//                        .show();
//
//            } else {
//                ActivityCompat.requestPermissions(getActivity(),
//                        new String[]{Manifest.permission.ACCESS_FINE_LOCATION},
//                        1);
//            }
//            return false;
//        } else {
//            return true;
//        }
//    }
//
//    @Override
//    public void onRequestPermissionsResult(int requestCode,
//                                           String permissions[], int[] grantResults) {
//        switch (requestCode) {
//            case 1: {
//                // If request is cancelled, the result arrays are empty.
//                if (grantResults.length > 0
//                        && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
//
//                    // permission was granted, yay! Do the
//                    // location-related task you need to do.
//                    if (ContextCompat.checkSelfPermission(getActivity(),
//                            Manifest.permission.ACCESS_FINE_LOCATION)
//                            == PackageManager.PERMISSION_GRANTED) {
//
//                        googleMap.setMyLocationEnabled(true);
//                    }
//
//                } else {
//
//                }
//                return;
//            }
//
//        }
//    }
//
//    private void placeMarkers() {
//        for (InterestMarker interestMarker :
//                markerPoints) {
//            googleMap.addMarker(new MarkerOptions().position(interestMarker.getLatLng()).
//                    title(interestMarker.getName()).snippet(interestMarker.getDescription())
//                    .icon(BitmapDescriptorFactory.fromResource(R.drawable.ic_chapabiz_logo_vert)));
//
//            CameraPosition cameraPosition = new CameraPosition.Builder().target(interestMarker.getLatLng()).zoom(12).build();
//            googleMap.animateCamera(CameraUpdateFactory.newCameraPosition
//                    (cameraPosition));
//        }
//    }
//
//}
