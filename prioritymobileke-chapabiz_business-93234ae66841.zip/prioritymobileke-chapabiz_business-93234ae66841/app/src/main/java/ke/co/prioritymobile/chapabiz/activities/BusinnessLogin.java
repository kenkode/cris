package ke.co.prioritymobile.chapabiz.activities;

import android.app.ProgressDialog;
import android.content.Intent;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.content.pm.Signature;
import android.os.Bundle;
import android.support.v4.content.ContextCompat;
import android.support.v7.app.AppCompatActivity;
import android.text.InputType;
import android.text.TextUtils;
import android.util.Base64;
import android.util.Log;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.Toast;

import com.facebook.AccessToken;
import com.facebook.AccessTokenTracker;
import com.facebook.CallbackManager;
import com.facebook.FacebookCallback;
import com.facebook.FacebookException;
import com.facebook.GraphRequest;
import com.facebook.GraphResponse;
import com.facebook.login.LoginManager;
import com.facebook.login.LoginResult;
import com.facebook.login.widget.LoginButton;
import com.google.android.gms.auth.api.signin.GoogleSignIn;
import com.google.android.gms.auth.api.signin.GoogleSignInAccount;
import com.google.android.gms.auth.api.signin.GoogleSignInClient;
import com.google.android.gms.auth.api.signin.GoogleSignInOptions;
import com.google.android.gms.common.SignInButton;
import com.google.android.gms.common.api.ApiException;
import com.google.android.gms.tasks.Task;
import com.google.gson.Gson;

import org.json.JSONObject;

import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.ArrayList;
import java.util.Arrays;

import ke.co.prioritymobile.chapabiz.R;
//import ke.co.prioritymobile.chapabiz.agent.Agent;
//import ke.co.prioritymobile.chapabiz.agent.activities.AgentActivity;
import ke.co.prioritymobile.chapabiz.business.activities.BusinessActivity;
import ke.co.prioritymobile.chapabiz.business.activities.SignUpActivity;
import ke.co.prioritymobile.chapabiz.entities.Response;
import ke.co.prioritymobile.chapabiz.helpers.CbSession;
import ke.co.prioritymobile.chapabiz.helpers.LoginUserSelect;
import ke.co.prioritymobile.chapabiz.retrofit.RetrofitSetup;
//import ke.co.prioritymobile.chapabiz.shopper.activities.UserHome;
//import ke.co.prioritymobile.chapabiz.shopper.entities.Shopper;
import retrofit2.Call;
import retrofit2.Callback;

import static ke.co.prioritymobile.chapabiz.helpers.CbSession.FACEBOOK;
import static ke.co.prioritymobile.chapabiz.helpers.CbSession.GOOGLE;

/**
 * Created by Millie Agallo on 4/16/2018.
 */

public class BusinnessLogin extends AppCompatActivity implements View.OnClickListener {

    private CallbackManager callbackManager;
    private static final String EMAIL = "email";
    private static final String BUSINESS_TAG = "business_tag";
    private static final String AGENT_TAG = "agent_tag";
    private static final String SHOPPER_TAG = "shopper_tag";
    private static final int RC_SIGN_IN = 1001;
    private LoginButton loginButton;
    private SignInButton signInButton;
    private GoogleSignInClient googleSignInClient;
    private Button businessButton, agentButton, shopperButton, createAccount;
    private EditText username, password;
    ArrayList<Button> buttons;
    private LinearLayout orContainer, socialContainer;
    private LoginUserSelect loginUserSelect;
    private AccessTokenTracker accessTokenTracker;
    private Button signUpBusiness;

    CbSession session;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_business_login);

        session = new CbSession(this);

        signUpBusiness = (Button) findViewById(R.id.sign_up_business);

        username = (EditText) findViewById(R.id.username);
        password = (EditText) findViewById(R.id.password);

        businessButton = (Button) findViewById(R.id.business);
//<<<<<<< HEAD
//=======
////        agentButton = (Button) findViewById(R.id.agent);
////        shopperButton = (Button) findViewById(R.id.shopper);
//
//        ImageView imageView = (ImageView) findViewById(R.id.back);
//
//        imageView.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View view) {
//       //         startActivity(new Intent(BusinnessLogin.this, MainLogin.class));
//            }
//        });
//>>>>>>> f28fa26a3e8d6eb545e2f95d5a7e9a5db8ce1829

        signUpBusiness.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(BusinnessLogin.this, SignUpActivity.class));
            }
        });

        businessButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String m = username.getText().toString();
                String p = password.getText().toString();

                if (TextUtils.isEmpty(m) || TextUtils.isEmpty(p)) {
                    Toast.makeText(BusinnessLogin.this, "Provide credentials", Toast.LENGTH_SHORT).show();
                    return;
                }
                        final ProgressDialog progressDialog = new ProgressDialog(BusinnessLogin.this);
                        progressDialog.setMessage("Logging you in...");
                        progressDialog.setIndeterminate(true);
                        progressDialog.setCancelable(false);
                        progressDialog.show();
                        String phone = username.getText().toString();
                        String pin = password.getText().toString();
                        Call<Response> responseCall = RetrofitSetup.retrofitInterface.signInBusiness(phone, pin);
                        responseCall.enqueue(new Callback<Response>() {
                            @Override
                            public void onResponse(Call<Response> call, retrofit2.Response<Response> response) {
                                Toast toast = Toast.makeText(BusinnessLogin.this, "", Toast.LENGTH_LONG);
                                toast.setGravity(Gravity.CENTER, 0, 0);
                                if (response.isSuccessful()) {
                                    Response business = response.body();
                                    switch (business.getStatus()) {
                                        case 200:
                                            session.setBusiness(business.getBusiness());
                                            startActivity(new Intent(BusinnessLogin.this, BusinessActivity.class));
                                            finish();
                                            break;
                                        case 302:
                                            break;
                                        case 404:
                                            break;
                                    }
                                    toast.setText(business.getMessage());
                                } else {
                                    toast.setText("Could not sign you in at the moment!");
                                }
                                toast.show();
                                progressDialog.dismiss();
                            }

                            @Override
                            public void onFailure(Call<Response> call, Throwable t) {
                                progressDialog.dismiss();
                                t.printStackTrace();
                            }
                        });
                  //      break;
//                finish();
            }
        });

        updateInput();
    }

    @Override
    protected void onStart() {
        super.onStart();
              if (session.getBusiness() != null) {
                    startActivity(new Intent(BusinnessLogin.this, BusinessActivity.class));
                    finish();
                }

    }

    @Override
    public void onClick(View view) {

        updateInput();

    }

    public void updateInput() {
        //signUpBusiness.setVisibility(View.GONE);
      //  switch (session.getLastSelected()) {
       //     case BUSINESS_TAG:
                password.setHint("Business Pin");
                username.setHint("Business Phone");
 //               username.setInputType(InputType.TYPE_CLASS_PHONE);
//                signUpBusiness.setVisibility(View.VISIBLE);
  //              orContainer.setVisibility(View.GONE);
    //            socialContainer.setVisibility(View.GONE);

    }

}
