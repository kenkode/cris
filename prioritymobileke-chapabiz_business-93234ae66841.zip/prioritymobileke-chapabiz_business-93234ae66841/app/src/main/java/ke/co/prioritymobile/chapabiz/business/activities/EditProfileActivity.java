package ke.co.prioritymobile.chapabiz.business.activities;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

import ke.co.prioritymobile.chapabiz.R;

public class EditProfileActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.business_profile_fragment);
    }
}
