package ke.co.prioritymobile.chapabiz.business.activities;

import android.app.DatePickerDialog;
import android.app.ProgressDialog;
import android.content.Intent;
import android.support.design.widget.TextInputLayout;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.CardView;
import android.text.TextUtils;
import android.util.Log;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.common.GooglePlayServicesNotAvailableException;
import com.google.android.gms.common.GooglePlayServicesRepairableException;
import com.google.android.gms.location.places.Place;
import com.google.android.gms.location.places.ui.PlacePicker;
import com.google.gson.Gson;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.Locale;

import ke.co.prioritymobile.chapabiz.R;
import ke.co.prioritymobile.chapabiz.business.entities.Business;
import ke.co.prioritymobile.chapabiz.business.entities.InterestDetail;
import ke.co.prioritymobile.chapabiz.entities.County;
import ke.co.prioritymobile.chapabiz.entities.Response;
import ke.co.prioritymobile.chapabiz.helpers.CbSession;
import ke.co.prioritymobile.chapabiz.retrofit.RetrofitSetup;
//import ke.co.prioritymobile.chapabiz.shopper.entities.InterestDetail;
import retrofit2.Call;
import retrofit2.Callback;

public class SignUpActivity extends AppCompatActivity {

    private TextInputLayout name, email, phone, years, description;
    //    private TextView certNo;
    private Button button;
    private Spinner category, county;
    private ArrayList<InterestDetail> interestDetails;
    private ArrayList<County> counties;
    private CardView cardView;
    private TextView yearStarted;
    private Calendar calendar;
    private CbSession session;
    TextView location;
    double longitude,latitude;
    int PLACE_PICKER_REQUEST = 1;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sign_up);

        session = new CbSession(this);

        calendar = Calendar.getInstance();

        location = (TextView)findViewById(R.id.location);

        location.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                PlacePicker.IntentBuilder builder = new PlacePicker.IntentBuilder();

                Intent intent;

                try {
                    intent = builder.build(SignUpActivity.this);
                    startActivityForResult(intent,PLACE_PICKER_REQUEST);
                } catch (GooglePlayServicesRepairableException e) {
                    e.printStackTrace();
                } catch (GooglePlayServicesNotAvailableException e) {
                    e.printStackTrace();
                }
            }
        });

        yearStarted = (TextView) findViewById(R.id.year_started_text);
        cardView = (CardView) findViewById(R.id.years);
        name = (TextInputLayout) findViewById(R.id.name);
        description = (TextInputLayout) findViewById(R.id.description);
        email = (TextInputLayout) findViewById(R.id.email);
        phone = (TextInputLayout) findViewById(R.id.phone);
//        certNo = (TextView) findViewById(R.id.certificate_name);
        button = (Button) findViewById(R.id.submit);
        category = (Spinner) findViewById(R.id.category);
        county = (Spinner) findViewById(R.id.country);

        cardView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                DatePickerDialog datePickerDialog = new DatePickerDialog(SignUpActivity.this, new DatePickerDialog.OnDateSetListener() {
                    @Override
                    public void onDateSet(DatePicker datePicker, int i, int i1, int i2) {
                        SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd", Locale.getDefault());
                        Date date = null;
                        try {
                            date = dateFormat.parse(String.format("%s-%s-%s", i, i1 + 1, i2));
                            calendar.setTime(date);
                            yearStarted.setText(dateFormat.format(date));
                        } catch (ParseException e) {
                            e.printStackTrace();
                        }
                    }
                }, calendar.get(Calendar.YEAR), calendar.get(Calendar.MONTH), calendar.get(Calendar.DAY_OF_MONTH));
                datePickerDialog.show();
            }
        });

        final Call<ArrayList<InterestDetail>> call = RetrofitSetup.retrofitInterface.getSubCategories();
        call.enqueue(new Callback<ArrayList<InterestDetail>>() {
            @Override
            public void onResponse(Call<ArrayList<InterestDetail>> call, retrofit2.Response<ArrayList<InterestDetail>> response) {
                if (response.isSuccessful()) {

                    interestDetails = response.body();

                    List<String> items = new ArrayList<>();

                    for (int i = 0; i < interestDetails.size(); i++) {
                        items.add(interestDetails.get(i).getName());
                    }

                    category.setAdapter(new ArrayAdapter<>(SignUpActivity.this, android.R.layout.simple_spinner_dropdown_item, items));
                }
            }

            @Override
            public void onFailure(Call<ArrayList<InterestDetail>> call, Throwable t) {

            }
        });

        Call<ArrayList<County>> countyCall = RetrofitSetup.retrofitInterface.getCounties();
        countyCall.enqueue(new Callback<ArrayList<County>>() {
            @Override
            public void onResponse(Call<ArrayList<County>> call, retrofit2.Response<ArrayList<County>> response) {
                if (response.isSuccessful()) {

                    counties = response.body();

                    List<String> items = new ArrayList<>();

                    for (int i = 0; i < counties.size(); i++) {
                        items.add(counties.get(i).getCountyName());
                    }

                    county.setAdapter(new ArrayAdapter<>(SignUpActivity.this, android.R.layout.simple_spinner_dropdown_item, items));
                }
            }

            @Override
            public void onFailure(Call<ArrayList<County>> call, Throwable t) {

            }
        });

        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String strName = name.getEditText().getText().toString();
                String strEmail = email.getEditText().getText().toString();
                String strPhone = phone.getEditText().getText().toString();
                String strDesc = description.getEditText().getText().toString();
                int cat = category.getSelectedItemPosition();

                int countySelected = county.getSelectedItemPosition();

                if (isEmpty(new String[]{strEmail, strName, strPhone, strDesc})) {
                    Toast.makeText(SignUpActivity.this, "Include all fields", Toast.LENGTH_SHORT).show();
                    return;
                }

                if (calendar.getTime() == null) {
                    Toast.makeText(SignUpActivity.this, "Specify year started", Toast.LENGTH_SHORT).show();
                    return;
                }

                if(cat == -1) {
                    Toast.makeText(SignUpActivity.this, "Select category", Toast.LENGTH_SHORT).show();
                    return;
                }

                if(countySelected == -1) {
                    Toast.makeText(SignUpActivity.this, "Select category", Toast.LENGTH_SHORT).show();
                    return;
                }

                String countyId = counties.get(countySelected).getId();

                InterestDetail interestDetail = interestDetails.get(cat);

                final ProgressDialog progressDialog = new ProgressDialog(SignUpActivity.this);
                progressDialog.setCancelable(false);
                progressDialog.setMessage("Signing up Business...");
                progressDialog.setIndeterminate(true);
                progressDialog.show();

               // Toast.makeText(SignUpActivity.this, latitude + "\n" + longitude, Toast.LENGTH_LONG).show();

                final Business business = new Business();
                business.setName(strName);
                business.setEmail(strEmail);
                business.setPhone(strPhone);
                business.setDescription(strDesc);
                business.setCounty(countyId);
                business.setLongitude(longitude);
                business.setLatitude(latitude);
                business.setCategory(String.valueOf(interestDetail.getId()));
                business.setOperationsSince(String.valueOf(new SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()).format(calendar.getTime())));
                String bsJson = new Gson().toJson(business);

                Log.e("Business Data",bsJson);

                Call<Response> call1 = RetrofitSetup.retrofitInterface.signUpBusiness(bsJson,longitude,latitude);
                call1.enqueue(new Callback<Response>() {
                    @Override
                    public void onResponse(Call<Response> call, retrofit2.Response<Response> response) {
                        if (response.isSuccessful()) {
                            Response response1 = response.body();

                            switch (response1.getStatus()) {
                                case 200:
                                    session.setBusiness(response1.getBusiness());
                                    startActivity(new Intent(SignUpActivity.this, BusinessActivity.class));
                                    finish();
                                    break;
                                case 301:
                                    break;
                                case 302:
                                    break;
                            }
                            Toast.makeText(SignUpActivity.this, response1.getMessage(), Toast.LENGTH_SHORT).show();
                        }
                        progressDialog.dismiss();
                    }

                    @Override
                    public void onFailure(Call<Response> call, Throwable t) {
                        t.printStackTrace();
                        progressDialog.dismiss();
                    }
                });

//                String strName;
            }
        });

    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (requestCode == PLACE_PICKER_REQUEST) {
            if (resultCode == RESULT_OK) {
                //Toast.makeText(SignUpActivity.this,"this", Toast.LENGTH_LONG).show();
                Place place = PlacePicker.getPlace(data, SignUpActivity.this);
                String address = String.format("Place: %s", place.getAddress());
                String lat = String.format("Latitude: %s", place.getLatLng().latitude);
                String lon = String.format("Longitude: %s", place.getLatLng().longitude);
                latitude = place.getLatLng().latitude;
                longitude = place.getLatLng().longitude;
                location.setText(address + "\n" + lat + "\n" + lon);

            }
        }
    }

    private boolean isEmpty(String[] fields) {
        for (String field :
                fields) {
            if (TextUtils.isEmpty(field)) {
                return true;
            }
        }
        return false;
    }

}
