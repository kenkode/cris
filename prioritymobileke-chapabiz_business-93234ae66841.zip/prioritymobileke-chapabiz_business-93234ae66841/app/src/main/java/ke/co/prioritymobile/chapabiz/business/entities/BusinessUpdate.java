package ke.co.prioritymobile.chapabiz.business.entities;

public class BusinessUpdate {
    private String strName, strEmail, strPhone, strCountry, strYears;

    public BusinessUpdate(String strName, String strEmail, String strPhone, String strCountry, String strYears) {
        this.strName = strName;
        this.strEmail = strEmail;
        this.strPhone = strPhone;
        this.strCountry = strCountry;
        this.strYears = strYears;
    }

    public String getStrName() {
        return strName;
    }

    public void setStrName(String strName) {
        this.strName = strName;
    }

    public String getStrEmail() {
        return strEmail;
    }

    public void setStrEmail(String strEmail) {
        this.strEmail = strEmail;
    }

    public String getStrPhone() {
        return strPhone;
    }

    public void setStrPhone(String strPhone) {
        this.strPhone = strPhone;
    }

    public String getStrCountry() {
        return strCountry;
    }

    public void setStrCountry(String strCountry) {
        this.strCountry = strCountry;
    }

    public String getStrYears() {
        return strYears;
    }

    public void setStrYears(String strYears) {
        this.strYears = strYears;
    }
}
