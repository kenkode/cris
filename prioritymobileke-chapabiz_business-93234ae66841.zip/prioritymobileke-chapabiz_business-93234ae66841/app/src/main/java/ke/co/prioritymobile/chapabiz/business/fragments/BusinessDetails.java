package ke.co.prioritymobile.chapabiz.business.fragments;

import android.app.ProgressDialog;
import android.content.Context;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.design.widget.TextInputLayout;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentTransaction;
import android.support.v4.content.ContextCompat;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.GridLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import com.google.gson.Gson;
import com.makeramen.roundedimageview.RoundedImageView;
import com.squareup.picasso.Picasso;

import java.util.ArrayList;

import de.hdodenhof.circleimageview.CircleImageView;
import ke.co.prioritymobile.chapabiz.R;
//import ke.co.prioritymobile.chapabiz.agent.adapters.PhotoAdapter;
import ke.co.prioritymobile.chapabiz.business.entities.Business;
import ke.co.prioritymobile.chapabiz.business.fragments.*;
import ke.co.prioritymobile.chapabiz.business.fragments.ProfileFragment;
import ke.co.prioritymobile.chapabiz.helpers.CbSession;
import ke.co.prioritymobile.chapabiz.retrofit.RetrofitSetup;
import okhttp3.ResponseBody;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

import static android.view.View.GONE;

public class BusinessDetails extends Fragment {

    private CbSession session;
    private TextInputLayout name, email, phone, description;
    public FragmentManager fragmentManager;

    public interface Clicked {
        void logoClicked(ProgressBar progressBar, TextView progressText, RoundedImageView businessImage, String business);

        void uploadFile(ProgressBar progressBar, TextView progressText, String business);
    }

    private Clicked clicked;
    private static String businessId;

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setHasOptionsMenu(true);

        session = new CbSession(getContext());
        Bundle bundle = getArguments();
        if (bundle != null) {
            businessId = bundle.getString("business");
        } else {
            businessId = session.getBusiness().getId();
        }
    }

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.business_profile_fragment, container, false);

        final ProgressBar progressBar = view.findViewById(R.id.progress_bar);

//        final RoundedImageView businessImage = view.findViewById(R.id.business_image);
//        String url = session.getBusiness().getImage();
//        if (url == null) {
//            url = "image";
//        }
//        Picasso.with(getContext()).load(url).placeholder(ContextCompat.getDrawable(getContext(), R.drawable.ic_chapabiz_logo_vert)).into(businessImage);
//
//        businessImage.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View view) {
//                clicked.logoClicked(progressBar, null, businessImage, businessId);
//            }
//        });

        final TextView certificate;

        Button updatePhoto = view.findViewById(R.id.update_pic);
        updatePhoto.setOnClickListener(new View.OnClickListener(){
            @Override
            public void onClick(View view){
                PhotoFragment photoFragment = new PhotoFragment();
                // session = new CbSession(getContext());
                //CbSession session = new CbSession(context);
                Bundle bundle = new Bundle();
                bundle.putString("business", session.getBusiness().getId());
                photoFragment.setArguments(bundle);
                FragmentTransaction profFrag = getChildFragmentManager().beginTransaction();
                // FragmentTransaction profFrag = getActivity().getSupportFragmentManager().beginTransaction();
                profFrag.replace(R.id.ttbb2, photoFragment);
                profFrag.setTransition(FragmentTransaction.TRANSIT_FRAGMENT_FADE);
                profFrag.commit();
            }
        });

        Button updateBusiness = view.findViewById(R.id.update_business);
        updateBusiness.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                final ProgressDialog progressDialog = new ProgressDialog(getContext());
                progressDialog.setMessage("Updating...");
                progressDialog.setIndeterminate(true);
                progressDialog.setCancelable(false);
                progressDialog.show();
                final String strName, strEmail, strPhone, strCountry, desc;
                strName = name.getEditText().getText().toString();
                strEmail = email.getEditText().getText().toString();
                strPhone = phone.getEditText().getText().toString();
                desc = description.getEditText().getText().toString();
//                strYears = years.getEditText().getText().toString();

                Business update = new Business();
                update.setName(strName);
                update.setEmail(strEmail);
                update.setPhone(strPhone);
                update.setDescription(desc);
//                update.setOperationsSince(strYears);

                Call<ResponseBody> call = RetrofitSetup.retrofitInterface.updateBusiness(businessId,
                        new Gson().toJson(update));
                call.enqueue(new Callback<ResponseBody>() {
                    @Override
                    public void onResponse(Call<ResponseBody> call, Response<ResponseBody> response) {
                        Toast toast = Toast.makeText(getContext(), "", Toast.LENGTH_LONG);
                        if (response.isSuccessful()) {
                            toast.setText("Updated!");
                            Business business = session.getBusiness();
                            business.setDescription(desc);
                            business.setPhone(strPhone);
                            business.setEmail(strEmail);
                            business.setName(strName);
                            session.setBusiness(business);
                        } else {
                            toast.setText("Failed to update!");
                        }
                        toast.setGravity(Gravity.CENTER, 0, 0);
                        toast.show();
                        progressDialog.dismiss();
                    }

                    @Override
                    public void onFailure(Call<ResponseBody> call, Throwable t) {
                        progressDialog.dismiss();
                    }
                });
            }
        });

        name = view.findViewById(R.id.name);
        certificate = view.findViewById(R.id.certificate);
        email = view.findViewById(R.id.email);
        phone = view.findViewById(R.id.phone);
        description = view.findViewById(R.id.description);

        certificate.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                clicked.uploadFile(progressBar, certificate, businessId);
            }
        });

        Business business = session.getBusiness();
        certificate.setText(business.getCertificateNo() == null ? "Certificate: Upload" : business.getCertificateNo());
        name.getEditText().setText(business.getName());
        email.getEditText().setText(business.getEmail());
        phone.getEditText().setText(business.getPhone());
        description.getEditText().setText(business.getDescription());

        return view;
    }

    @Override
    public void onAttach(Context context) {
        super.onAttach(context);
        clicked = (Clicked) context;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case R.id.photos:
                PhotoFragment photoFragment = new PhotoFragment();
                Bundle bundle = new Bundle();
                bundle.putString("business", session.getBusiness().getId());
                photoFragment.setArguments(bundle);
                FragmentTransaction profFrag = getActivity().getSupportFragmentManager().beginTransaction();
                // FragmentTransaction profFrag = getChildFragmentManager().beginTransaction();
                profFrag.replace(R.id.ttbb2, photoFragment);
                profFrag.setTransition(FragmentTransaction.TRANSIT_FRAGMENT_FADE);
                profFrag.commit();
                return true;
        }
        return false;
    }

    // public void button(View view){
    // public boolean Bizpic(){
//                PhotoFragment photoFragment = new PhotoFragment();
//               // session = new CbSession(getContext());
//                //CbSession session = new CbSession(context);
//                Bundle bundle = new Bundle();
//                bundle.putString("business", session.getBusiness().getId());
//                photoFragment.setArguments(bundle);
//                FragmentTransaction profFrag = getChildFragmentManager().beginTransaction();
//               // FragmentTransaction profFrag = getActivity().getSupportFragmentManager().beginTransaction();
//                profFrag.replace(R.id.ttbb1, photoFragment);
//                profFrag.setTransition(FragmentTransaction.TRANSIT_FRAGMENT_FADE);
//                profFrag.commit();
    // return true;
    // }
    // return false;
    //  }
}