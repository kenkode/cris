package ke.co.prioritymobile.chapabiz.business.fragments;

import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.support.v4.content.ContextCompat;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.CompoundButton;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.Toast;

import com.google.gson.Gson;
import com.squareup.picasso.Picasso;

import ke.co.prioritymobile.chapabiz.R;
import ke.co.prioritymobile.chapabiz.business.entities.Business;
import ke.co.prioritymobile.chapabiz.helpers.CbSession;
import ke.co.prioritymobile.chapabiz.retrofit.RetrofitSetup;
import okhttp3.ResponseBody;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class HomeFragment extends Fragment {

    private CbSession session;

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        session = new CbSession(getContext());
        setHasOptionsMenu(true);
    }

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.activity_analysis, container, false);

        TextView name, about, verified, converse, searches;
        ImageView logo;
        Switch state;

        logo = view.findViewById(R.id.business_logo);
        name = view.findViewById(R.id.business_name);
        about = view.findViewById(R.id.about);
        verified = view.findViewById(R.id.verified);
        converse = view.findViewById(R.id.converse);
        searches = view.findViewById(R.id.searches);

        Business business = session.getBusiness();
        name.setText(business.getName());
        about.setText(business.getDescription());

        converse.setText("0");
        searches.setText("0");

        state = view.findViewById(R.id.state);

        if(business.getState() == 1) {
            state.setChecked(true);
        }else{
            state.setChecked(false);
        }

        state.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                int state = 0;
                if (isChecked) {
                   state = 1;
                    Toast.makeText(getContext(), "You are now online", Toast.LENGTH_LONG).show();
                } else {
                    state = 0;
                    Toast.makeText(getContext(), "You are now offline", Toast.LENGTH_LONG).show();
                }

                Call<ResponseBody> call = RetrofitSetup.retrofitInterface.updateStatus(session.getBusiness().getId(),state
                        );

                call.enqueue(new Callback<ResponseBody>() {
                    @Override
                    public void onResponse(Call<ResponseBody> call, Response<ResponseBody> response) {

                    }

                    @Override
                    public void onFailure(Call<ResponseBody> call, Throwable t) {

                    }
                });

            }
        });



        Picasso.with(getContext()).load(business.getImage()).placeholder(ContextCompat.getDrawable(getContext(), R.drawable.ic_chapabiz_logo_vert)).into(logo);

        if (business.getVerified() == 1) {
            verified.setText("Verified");
            verified.setTextColor(ContextCompat.getColor(getContext(), R.color.colorGreenAccent));
        } else {
            verified.setText("Not Verified");
            verified.setTextColor(ContextCompat.getColor(getContext(), R.color.colorRedAccent));
        }

        return view;
    }

}
