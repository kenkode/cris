package ke.co.prioritymobile.chapabiz.business.fragments;

import android.content.Context;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.support.v7.widget.Toolbar;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.Toast;

import com.squareup.picasso.Picasso;

import ke.co.prioritymobile.chapabiz.R;
import ke.co.prioritymobile.chapabiz.helpers.CbSession;
import ke.co.prioritymobile.chapabiz.retrofit.RetrofitSetup;
import okhttp3.ResponseBody;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class ImageFragment extends Fragment {

    public interface Clicked {
        void clicked(String id);
    }

    private Clicked clicked;

    private String url, id;

    private CbSession session;

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setHasOptionsMenu(true);

        session = new CbSession(getContext());

        Bundle bundle = getArguments();
        if(bundle != null) {
            url = bundle.getString("url");
            id = bundle.getString("id");
        }
    }

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.image_fragment, container, false);

        Toolbar toolbar = view.findViewById(R.id.toolbar);
//        getActivity().setActionBar(toolbar);

        ImageView imageView = view.findViewById(R.id.image);
        ImageView delete = view.findViewById(R.id.delete);
        Picasso.with(getContext()).load(url).placeholder(R.color.colorGreyAccent).into(imageView);
        delete.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                clicked.clicked(id);
            }
        });
        return view;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case R.id.delete:
                clicked.clicked(id);
                break;
        }

        return false;
    }

    @Override
    public void onAttach(Context context) {
        super.onAttach(context);
        clicked = (Clicked) context;
    }
}
