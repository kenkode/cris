package ke.co.prioritymobile.chapabiz.business.fragments;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.support.v4.content.LocalBroadcastManager;
import android.support.v7.widget.DefaultItemAnimator;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.common.ConnectionResult;
import com.google.android.gms.common.GoogleApiAvailability;
import com.qiscus.sdk.Qiscus;

import java.util.ArrayList;

import ke.co.prioritymobile.chapabiz.Constants;
import ke.co.prioritymobile.chapabiz.R;
import ke.co.prioritymobile.chapabiz.adapters.ChatRoomsAdapter;
import ke.co.prioritymobile.chapabiz.chat.ChatRoomActivity;
import ke.co.prioritymobile.chapabiz.entities.ChatRoom;
import ke.co.prioritymobile.chapabiz.entities.Message;
import ke.co.prioritymobile.chapabiz.entities.User;
import ke.co.prioritymobile.chapabiz.gcm.GcmIntentService;
import ke.co.prioritymobile.chapabiz.helpers.CbSession;
import ke.co.prioritymobile.chapabiz.helpers.SimpleDividerItemDecoration;
import ke.co.prioritymobile.chapabiz.retrofit.RetrofitSetup;
import okhttp3.ResponseBody;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class MessageFragment extends Fragment {

    private static final int PLAY_SERVICES_RESOLUTION_REQUEST = 9000;
    private BroadcastReceiver mRegistrationBroadcastReceiver;
    private ArrayList<ChatRoom> chatRoomArrayList;
    private ChatRoomsAdapter mAdapter;
    private RecyclerView recyclerView;
    private CbSession session;
    private TextView textView;

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        session = new CbSession(getContext());


        if (session.getUser() == null) {
            String id = session.getBusiness().getId();
            String name = session.getBusiness().getName();
            String email = session.getBusiness().getEmail();
            User user = new User(id, name, email);
            session.storeUser(user);
        }

       // String User = session.getUser().getId();


//        mRegistrationBroadcastReceiver = new BroadcastReceiver() {
//            @Override
//            public void onReceive(Context context, Intent intent) {
//
//                // checking for type intent filter
//                if (intent.getAction().equals(Constants.REGISTRATION_COMPLETE)) {
//                    // gcm successfully registered
//                    // now subscribe to `global` topic to receive app wide notifications
//                    String token = intent.getStringExtra("token");
//
//                } else if (intent.getAction().equals(Constants.SENT_TOKEN_TO_SERVER)) {
//                    // gcm registration id is stored in our server's MySQL
//
//                } else if (intent.getAction().equals(Constants.PUSH_NOTIFICATION)) {
//
//                    Toast.makeText(getContext(), "Push notification is received!", Toast.LENGTH_LONG).show();
//                }
//            }
//        };


        fetchChatRooms();
    }

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.activity_chat, container, false);

        recyclerView = (RecyclerView) view.findViewById(R.id.recycler_view);

        textView = view.findViewById(R.id.messages);

        chatRoomArrayList = new ArrayList<>();
        mAdapter = new ChatRoomsAdapter(getContext(), chatRoomArrayList);
        LinearLayoutManager layoutManager = new LinearLayoutManager(getContext());
        recyclerView.setLayoutManager(layoutManager);
        recyclerView.addItemDecoration(new SimpleDividerItemDecoration(
                getContext()
        ));

        recyclerView.setItemAnimator(new DefaultItemAnimator());
        recyclerView.setAdapter(mAdapter);

        recyclerView.addOnItemTouchListener(new ChatRoomsAdapter.RecyclerTouchListener(getContext(), recyclerView, new ChatRoomsAdapter.ClickListener() {
            @Override
            public void onClick(View view, int position) {
                final ChatRoom chatRoom = chatRoomArrayList.get(position);
                Qiscus.buildChatWith(chatRoom.getId())
                        .build(getContext(), new Qiscus.ChatActivityBuilderListener() {
                            @Override
                            public void onSuccess(Intent intent) {
                                String user = session.getBusiness().getId();
                                Log.e("user", user);
                                Log.e("user", chatRoom.getId());
                                Call<ResponseBody> call = RetrofitSetup.retrofitInterface.addChat(user, chatRoom.getId());
                                call.enqueue(new Callback<ResponseBody>() {
                                    @Override
                                    public void onResponse(Call<ResponseBody> call, Response<ResponseBody> response) {

                                    }

                                    @Override
                                    public void onFailure(Call<ResponseBody> call, Throwable t) {

                                    }
                                });
                                intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                                startActivity(intent);
                            }

                            @Override
                            public void onError(Throwable throwable) {
                                throwable.printStackTrace();
                                //do anything if error occurs
                            }
                        });
               Intent intent = new Intent(getContext(), ChatRoomActivity.class);
               intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
               intent.putExtra("chat_room_id", chatRoom.getId());
               startActivity(intent);
            }

            @Override
            public void onLongClick(View view, int position) {

            }
        }));

        return view;
    }

    private void fetchChatRooms() {
        Call<ArrayList<ChatRoom>> call = RetrofitSetup.retrofitInterface.getChatRooms(session.getUser().getId());
        call.enqueue(new Callback<ArrayList<ChatRoom>>() {
            @Override
            public void onResponse(Call<ArrayList<ChatRoom>> call, Response<ArrayList<ChatRoom>> response) {
                if (response.isSuccessful()) {
                    chatRoomArrayList.addAll(response.body());
                    if (chatRoomArrayList.isEmpty()) {
                        textView.setText("No Messages");
                    }
                    mAdapter.notifyDataSetChanged();
                }
            }

            @Override
            public void onFailure(Call<ArrayList<ChatRoom>> call, Throwable t) {

            }
        });
    }

//    private void handlePushNotification(Intent intent) {
//        int type = intent.getIntExtra("type", -1);
//
//        // if the push is of chat room message
//        // simply update the UI unread messages count
//        if (type == Constants.PUSH_TYPE_CHATROOM) {
//            Message message = (Message) intent.getSerializableExtra("message");
//            String chatRoomId = intent.getStringExtra("chat_room_id");
//
//            if (message != null && chatRoomId != null) {
//                updateRow(chatRoomId, message);
//            }
//        } else if (type == Constants.PUSH_TYPE_USER) {
//            // push belongs to user alone
//            // just showing the message in a toast
//            Message message = (Message) intent.getSerializableExtra("message");
//            Toast.makeText(getContext(), "New push: " + message.getMessage(), Toast.LENGTH_LONG).show();
//        }
//
//    }
//
////    private void updateRow(String chatRoomId, Message message) {
////        for (ChatRoom cr : chatRoomArrayList) {
////            if (cr.getId().equals(chatRoomId)) {
////                int index = chatRoomArrayList.indexOf(cr);
////                cr.setLastMessage(message.getMessage());
////                cr.setUnreadCount(cr.getUnreadCount() + 1);
////                chatRoomArrayList.remove(index);
////                chatRoomArrayList.add(index, cr);
////                break;
////            }
////        }
////        mAdapter.notifyDataSetChanged();
////    }
//
//
//
//    private void subscribeToAllTopics() {
//        for (ChatRoom cr : chatRoomArrayList) {
//            Intent intent = new Intent(getContext(), GcmIntentService.class);
//            intent.putExtra(GcmIntentService.KEY, GcmIntentService.SUBSCRIBE);
//            intent.putExtra(GcmIntentService.TOPIC, "topic_" + cr.getId());
//            getContext().startService(intent);
//        }
//    }
//
//    private void subscribeToGlobalTopic() {
//        Intent intent = new Intent(getContext(), GcmIntentService.class);
//        intent.putExtra(GcmIntentService.KEY, GcmIntentService.SUBSCRIBE);
//        intent.putExtra(GcmIntentService.TOPIC, Constants.TOPIC_GLOBAL);
//        getContext().startService(intent);
//    }
//
//    // starting the service to register with GCM
//    private void registerGCM() {
//        Intent intent = new Intent(getContext(), GcmIntentService.class);
//        intent.putExtra("key", "register");
//        getContext().startService(intent);
//    }
//
//    private boolean checkPlayServices() {
//        GoogleApiAvailability apiAvailability = GoogleApiAvailability.getInstance();
//        int resultCode = apiAvailability.isGooglePlayServicesAvailable(getContext());
//        if (resultCode != ConnectionResult.SUCCESS) {
//            if (apiAvailability.isUserResolvableError(resultCode)) {
//                apiAvailability.getErrorDialog(getActivity(), resultCode, PLAY_SERVICES_RESOLUTION_REQUEST)
//                        .show();
//            } else {
//                Log.i(TAG, "This device is not supported. Google Play Services not installed!");
//                Toast.makeText(getContext(), "This device is not supported. Google Play Services not installed!", Toast.LENGTH_LONG).show();
//            }
//            return false;
//        }
//        return true;
//    }
//
//    @Override
//    public void onResume() {
//        super.onResume();
//        LocalBroadcastManager.getInstance(getContext()).registerReceiver(mRegistrationBroadcastReceiver,
//                new IntentFilter(Constants.REGISTRATION_COMPLETE));
//
//        // register new push message receiver
//        // by doing this, the activity will be notified each time a new message arrives
//        LocalBroadcastManager.getInstance(getContext()).registerReceiver(mRegistrationBroadcastReceiver,
//                new IntentFilter(Constants.PUSH_NOTIFICATION));
//    }
//
//    @Override
//    public void onPause() {
//        LocalBroadcastManager.getInstance(getContext()).unregisterReceiver(mRegistrationBroadcastReceiver);
//        super.onPause();
//    }

}
