package ke.co.prioritymobile.chapabiz.business.fragments;

import android.app.ProgressDialog;
import android.content.Context;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.design.widget.TextInputLayout;
import android.support.v4.app.Fragment;
import android.support.v4.content.ContextCompat;
import android.util.Log;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import com.google.gson.Gson;
import com.squareup.picasso.Picasso;

import de.hdodenhof.circleimageview.CircleImageView;
import ke.co.prioritymobile.chapabiz.R;
import ke.co.prioritymobile.chapabiz.business.entities.Business;
import ke.co.prioritymobile.chapabiz.helpers.CbSession;
import ke.co.prioritymobile.chapabiz.retrofit.RetrofitSetup;
import okhttp3.ResponseBody;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class ProfileFragment extends Fragment {

    CbSession session;

    public interface Clicked {
        void logoutClicked();

        void logoClicked(ProgressBar progressBar, TextView progressText, ImageView businessImage);

        void uploadFile(ProgressBar progressBar, TextView progressText);
    }

    private Clicked clicked;

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setHasOptionsMenu(true);
        session = new CbSession(getContext());
    }

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.business_profile_fragment, container, false);

        final TextInputLayout name, email, phone, description;
        final ProgressBar progressBar = view.findViewById(R.id.progress_bar);

//        final CircleImageView businessImage = view.findViewById(R.id.business_image);
//        String url = session.getBusiness().getImage();
//        if (url == null) {
//            url = "image";
//        }
//        Picasso.with(getContext()).load(url).placeholder(ContextCompat.getDrawable(getContext(), R.drawable.ic_chapabiz_logo_vert)).into(businessImage);
//
//        businessImage.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View view) {
//                clicked.logoClicked(progressBar, null, businessImage);
//            }
//        });


        final TextView certificate, save, logout;

        final Button updatepic;

        logout = view.findViewById(R.id.logout);
        save = view.findViewById(R.id.save);
        name = view.findViewById(R.id.name);
        certificate = view.findViewById(R.id.certificate);
        email = view.findViewById(R.id.email);
        phone = view.findViewById(R.id.phone);
        description = view.findViewById(R.id.description);

//        update_pic = view.findViewById(R.id.update_pic);
//
//        certificate.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View view) {
//                clicked.uploadFile(progressBar, certificate);
//            }
//        });
//
//        update_pic.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View view) {
//                clicked.uploadFile(progressBar, certificate);
//            }
//        });



        Business business = session.getBusiness();
        certificate.setText(business.getCertificateNo() == null ? "Certificate: Upload" : business.getCertificateNo());
        name.getEditText().setText(business.getName());
        email.getEditText().setText(business.getEmail());
        phone.getEditText().setText(business.getPhone());
        description.getEditText().setText(business.getDescription());

        save.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                final ProgressDialog progressDialog = new ProgressDialog(getContext());
                progressDialog.setMessage("Updating...");
                progressDialog.setIndeterminate(true);
                progressDialog.setCancelable(false);
                progressDialog.show();
                final String strName, strEmail, strPhone, strCountry, desc;
                strName = name.getEditText().getText().toString();
                strEmail = email.getEditText().getText().toString();
                strPhone = phone.getEditText().getText().toString();
                desc = description.getEditText().getText().toString();
//                strYears = years.getEditText().getText().toString();

                Business update = new Business();
                update.setName(strName);
                update.setEmail(strEmail);
                update.setPhone(strPhone);
                update.setDescription(desc);
//                update.setOperationsSince(strYears);

                Call<ResponseBody> call = RetrofitSetup.retrofitInterface.updateBusiness(session.getBusiness().getId(),
                        new Gson().toJson(update));

                call.enqueue(new Callback<ResponseBody>() {
                    @Override
                    public void onResponse(Call<ResponseBody> call, Response<ResponseBody> response) {
                        Toast toast = Toast.makeText(getContext(), "", Toast.LENGTH_LONG);
                        if (response.isSuccessful()) {
                            toast.setText("Updated!");
                            session.getBusiness().setDescription(desc);
                            session.getBusiness().setPhone(strPhone);
                            session.getBusiness().setEmail(strEmail);
                            session.getBusiness().setName(strName);
                        } else {
                            toast.setText("Failed to update!");
                        }
                        toast.setGravity(Gravity.CENTER, 0, 0);
                        toast.show();
                        progressDialog.dismiss();
                    }

                    @Override
                    public void onFailure(Call<ResponseBody> call, Throwable t) {
                        progressDialog.dismiss();
                    }
                });

            }
        });

        return view;
    }

    @Override
    public void onAttach(Context context) {
        super.onAttach(context);
        clicked = (Clicked) context;
    }

    @Override
    public void onCreateOptionsMenu(Menu menu, MenuInflater inflater) {
        inflater.inflate(R.menu.save, menu);
    }
}
