//package ke.co.prioritymobile.chapabiz.chat;
//
//import android.content.BroadcastReceiver;
//import android.content.Context;
//import android.content.Intent;
//import android.content.IntentFilter;
//import android.support.v4.content.LocalBroadcastManager;
//import android.support.v7.app.AppCompatActivity;
//import android.os.Bundle;
//import android.support.v7.widget.DefaultItemAnimator;
//import android.support.v7.widget.LinearLayoutManager;
//import android.support.v7.widget.RecyclerView;
//import android.util.Log;
//import android.view.View;
//import android.widget.Toast;
//
//import com.google.android.gms.common.ConnectionResult;
//import com.google.android.gms.common.GoogleApiAvailability;
//
//import java.util.ArrayList;
//
//import ke.co.prioritymobile.chapabiz.Constants;
//import ke.co.prioritymobile.chapabiz.R;
//import ke.co.prioritymobile.chapabiz.adapters.ChatRoomsAdapter;
//import ke.co.prioritymobile.chapabiz.entities.ChatRoom;
//import ke.co.prioritymobile.chapabiz.entities.Message;
//import ke.co.prioritymobile.chapabiz.gcm.GcmIntentService;
//import ke.co.prioritymobile.chapabiz.helpers.CbSession;
//import ke.co.prioritymobile.chapabiz.helpers.SimpleDividerItemDecoration;
//import ke.co.prioritymobile.chapabiz.retrofit.RetrofitSetup;
//import retrofit2.Call;
//import retrofit2.Callback;
//import retrofit2.Response;
//
//public class ChatActivity extends AppCompatActivity {
//
//    private String TAG = ChatActivity.class.getSimpleName();
//    private static final int PLAY_SERVICES_RESOLUTION_REQUEST = 9000;
//    private BroadcastReceiver mRegistrationBroadcastReceiver;
//    private ArrayList<ChatRoom> chatRoomArrayList;
//    private ChatRoomsAdapter mAdapter;
//    private RecyclerView recyclerView;
//    private CbSession session;
//
//    @Override
//    protected void onCreate(Bundle savedInstanceState) {
//        super.onCreate(savedInstanceState);
//        setContentView(R.layout.activity_chat);
//
//        session = new CbSession(this);
//
//        recyclerView = (RecyclerView) findViewById(R.id.recycler_view);
//
//        mRegistrationBroadcastReceiver = new BroadcastReceiver() {
//            @Override
//            public void onReceive(Context context, Intent intent) {
//
//                // checking for type intent filter
//                if (intent.getAction().equals(Constants.REGISTRATION_COMPLETE)) {
//                    // gcm successfully registered
//                    // now subscribe to `global` topic to receive app wide notifications
//                    String token = intent.getStringExtra("token");
//
//                } else if (intent.getAction().equals(Constants.SENT_TOKEN_TO_SERVER)) {
//                    // gcm registration id is stored in our server's MySQL
//
//                } else if (intent.getAction().equals(Constants.PUSH_NOTIFICATION)) {
//
//                    Toast.makeText(getApplicationContext(), "Push notification is received!", Toast.LENGTH_LONG).show();
//                }
//            }
//        };
//
//        chatRoomArrayList = new ArrayList<>();
//        mAdapter = new ChatRoomsAdapter(this, chatRoomArrayList);
//        LinearLayoutManager layoutManager = new LinearLayoutManager(this);
//        recyclerView.setLayoutManager(layoutManager);
//        recyclerView.addItemDecoration(new SimpleDividerItemDecoration(
//                getApplicationContext()
//        ));
//
//        recyclerView.setItemAnimator(new DefaultItemAnimator());
//        recyclerView.setAdapter(mAdapter);
//
//        recyclerView.addOnItemTouchListener(new ChatRoomsAdapter.RecyclerTouchListener(getApplicationContext(), recyclerView, new ChatRoomsAdapter.ClickListener() {
//            @Override
//            public void onClick(View view, int position) {
//                ChatRoom chatRoom = chatRoomArrayList.get(position);
//                Intent intent = new Intent(ChatActivity.this, ChatRoomActivity.class);
//                intent.putExtra("chat_room_id", chatRoom.getId());
//                startActivity(intent);
//            }
//
//            @Override
//            public void onLongClick(View view, int position) {
//
//            }
//        }));
//
//        if (checkPlayServices()) {
//            registerGCM();
//            fetchChatRooms();
//        }
//    }
//
//    private void handlePushNotification(Intent intent) {
//        int type = intent.getIntExtra("type", -1);
//
//        // if the push is of chat room message
//        // simply update the UI unread messages count
//        if (type == Constants.PUSH_TYPE_CHATROOM) {
//            Message message = (Message) intent.getSerializableExtra("message");
//            String chatRoomId = intent.getStringExtra("chat_room_id");
//
//            if (message != null && chatRoomId != null) {
//                updateRow(chatRoomId, message);
//            }
//        } else if (type == Constants.PUSH_TYPE_USER) {
//            // push belongs to user alone
//            // just showing the message in a toast
//            Message message = (Message) intent.getSerializableExtra("message");
//            Toast.makeText(getApplicationContext(), "New push: " + message.getMessage(), Toast.LENGTH_LONG).show();
//        }
//
//    }
//
//    private void updateRow(String chatRoomId, Message message) {
//        for (ChatRoom cr : chatRoomArrayList) {
//            if (cr.getId().equals(chatRoomId)) {
//                int index = chatRoomArrayList.indexOf(cr);
//                cr.setLastMessage(message.getMessage());
//                cr.setUnreadCount(cr.getUnreadCount() + 1);
//                chatRoomArrayList.remove(index);
//                chatRoomArrayList.add(index, cr);
//                break;
//            }
//        }
//        mAdapter.notifyDataSetChanged();
//    }
//
//    private void fetchChatRooms() {
//        Call<ArrayList<ChatRoom>> call = RetrofitSetup.retrofitInterface.getChatRooms(session.getUser().getId());
//        call.enqueue(new Callback<ArrayList<ChatRoom>>() {
//            @Override
//            public void onResponse(Call<ArrayList<ChatRoom>> call, Response<ArrayList<ChatRoom>> response) {
//                if (response.isSuccessful()) {
//                    chatRoomArrayList.addAll(response.body());
//                    mAdapter.notifyDataSetChanged();
//                    subscribeToAllTopics();
//                }else {
//                    Toast.makeText(ChatActivity.this, "Bad", Toast.LENGTH_SHORT).show();
//
//                }
//            }
//
//            @Override
//            public void onFailure(Call<ArrayList<ChatRoom>> call, Throwable t) {
//
//            }
//        });
//    }
//
//    private void subscribeToAllTopics() {
//        for (ChatRoom cr : chatRoomArrayList) {
//
//            Intent intent = new Intent(this, GcmIntentService.class);
//            intent.putExtra(GcmIntentService.KEY, GcmIntentService.SUBSCRIBE);
//            intent.putExtra(GcmIntentService.TOPIC, "topic_" + cr.getId());
//            startService(intent);
//        }
//    }
//
//    private void subscribeToGlobalTopic() {
//        Intent intent = new Intent(this, GcmIntentService.class);
//        intent.putExtra(GcmIntentService.KEY, GcmIntentService.SUBSCRIBE);
//        intent.putExtra(GcmIntentService.TOPIC, Constants.TOPIC_GLOBAL);
//        startService(intent);
//    }
//
//    // starting the service to register with GCM
//    private void registerGCM() {
//        Intent intent = new Intent(this, GcmIntentService.class);
//        intent.putExtra("key", "register");
//        startService(intent);
//    }
//
//    private boolean checkPlayServices() {
//        GoogleApiAvailability apiAvailability = GoogleApiAvailability.getInstance();
//        int resultCode = apiAvailability.isGooglePlayServicesAvailable(this);
//        if (resultCode != ConnectionResult.SUCCESS) {
//            if (apiAvailability.isUserResolvableError(resultCode)) {
//                apiAvailability.getErrorDialog(this, resultCode, PLAY_SERVICES_RESOLUTION_REQUEST)
//                        .show();
//            } else {
//                Log.i(TAG, "This device is not supported. Google Play Services not installed!");
//                Toast.makeText(getApplicationContext(), "This device is not supported. Google Play Services not installed!", Toast.LENGTH_LONG).show();
//                finish();
//            }
//            return false;
//        }
//        return true;
//    }
//
//    @Override
//    protected void onResume() {
//        super.onResume();
//
//        // register GCM registration complete receiver
//        LocalBroadcastManager.getInstance(this).registerReceiver(mRegistrationBroadcastReceiver,
//                new IntentFilter(Constants.REGISTRATION_COMPLETE));
//
//        // register new push message receiver
//        // by doing this, the activity will be notified each time a new message arrives
//        LocalBroadcastManager.getInstance(this).registerReceiver(mRegistrationBroadcastReceiver,
//                new IntentFilter(Constants.PUSH_NOTIFICATION));
//    }
//
//    @Override
//    protected void onPause() {
//        LocalBroadcastManager.getInstance(this).unregisterReceiver(mRegistrationBroadcastReceiver);
//        super.onPause();
//    }
//
//
//}