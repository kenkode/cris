package ke.co.prioritymobile.chapabiz.entities;

import com.google.gson.annotations.SerializedName;

public class ChatRoom {

    String id;
    String name;
    String user;
    @SerializedName("time_stamp")
    String timestamp;
    int unreadCount;

    public ChatRoom() {
    }

    public ChatRoom(String id, String name, String lastMessage, String timestamp, int unreadCount, String user) {
        this.id = id;
        this.name = name;
        this.timestamp = timestamp;
        this.unreadCount = unreadCount;
        this.user = user;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getUnreadCount() {
        return unreadCount;
    }

    public void setUnreadCount(int unreadCount) {
        this.unreadCount = unreadCount;
    }

    public String getTimestamp() {
        return timestamp;
    }

    public void setTimestamp(String timestamp) {
        this.timestamp = timestamp;
    }

    public String getUser(){
        return user;
    }

    public void setUser(){
        this.user = user;
    }
}