package ke.co.prioritymobile.chapabiz.entities;

import ke.co.prioritymobile.chapabiz.business.entities.Business;

public class Response {

    private int status;
    private String message;
    private Business business;

    public Business getBusiness() {
        return business;
    }

    public void setBusiness(Business business) {
        this.business = business;
    }

    public int getStatus() {
        return status;
    }

    public void setStatus(int status) {
        this.status = status;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }
}
