package ke.co.prioritymobile.chapabiz.retrofit;

public class EndPoint {

   // public static final String BASE_URL = "http://167.99.254.2/chapabiz/";
    public static final String BASE_URL = "http://167.99.254.2:8000/";

    public static final String SIGN_IN_BUSINESS = BASE_URL + "business/sign_in_business";

    public static final String SIGN_UP_BUSINESS = BASE_URL + "business/sign_up_business";

    public static final String GET_COUNTIES = BASE_URL + "business/get_counties";

    public static final String UPDATE_BUSINESS = BASE_URL + "business/update_business";

    public static final String UPDATE_BUSINESS_STATUS = BASE_URL + "business/update_business_status";

    public static final String AGENT_SUMMARY = BASE_URL + "agent/summary";

    public static final String CATEGORIES = BASE_URL + "shopper/categories";

    public static final String SUB_CATEGORIES = BASE_URL + "shopper/sub_categories";

    //new sub categories
    public static final String SUB_CATEGORIES1 = BASE_URL + "shopper/subcategories1";

 public static final String SUB_CATEGORIES2 = BASE_URL + "shopper/subcategories2";

 public static final String SUB_CATEGORIES3 = BASE_URL + "shopper/subcategories3";

 public static final String SUB_CATEGORIES4 = BASE_URL + "shopper/subcategories4";
 //subcategories1
 public static final String SUB_CATEGORIES5 = BASE_URL + "shopper/subcategories5";


    public static final String UPDATE_INTEREST = BASE_URL + "shopper/update_interest";

    public static final String INTERESTS = BASE_URL + "shopper/interests";

    public static final String GET_BUSINESSES = BASE_URL + "shopper/locate_businesses";

    public static final String SIGN_IN_SHOPPER = BASE_URL + "shopper/sign_in_shopper";

    public static final String GET_PHOTOS = BASE_URL + "business/get_photos";

    public static final String UPLOAD_FILE = BASE_URL + "business/upload_file";

    public static final String DELETE_PHOTO = BASE_URL + "business/delete_file";

//    Chat

    public static final String CHAT_ROOMS = BASE_URL + "chat/chat_rooms";

    public static final String ADD_CHAT = BASE_URL + "chat/add";

    public static final String SEND_TOKEN = BASE_URL + "chat/send_token";

    public static final String UPDATE_TOKEN = BASE_URL + "chat/update_token";

    public static final String SEND_MESSAGE = BASE_URL + "chat/post_message";

    public static final String GET_MESSAGES = BASE_URL + "chat/get_chat_room";


    public static final String UPDATE_AGENT = "agent/update_agent";
    public static final String AGENT_BUSINESSES = "agent/businesses";
    public static final String SIGN_IN_AGENT = "agent/sign_in_agent";

    public static final String ACTUAL_AGENT_BUSINESSES ="agent/my_businesses";
    public static final String AGENT_COMMISSIONS_ALL = "agent/view_commissions";

    public static final String AGENT_COMMISSIONS_YEAR ="agent/my_businesses_year";

    public static final String AGENT_COMMISSIONS_MONTH ="agent/my_businesses_month";

    public static final String AGENT_COMMISSIONS_DAY="agent/my_businesses_day";

    public static final String AGENT_COMMISSIONS_WEEK="agent/my_businesses_week";

}
