package ke.co.prioritymobile.chapabiz.retrofit;

import java.util.ArrayList;

//ke.co.prioritymobile.chapabiz.business.entities.Business;
import ke.co.prioritymobile.chapabiz.business.entities.Business;
import ke.co.prioritymobile.chapabiz.business.entities.InterestDetail;
import ke.co.prioritymobile.chapabiz.entities.ChatRoom;
import ke.co.prioritymobile.chapabiz.entities.County;
import ke.co.prioritymobile.chapabiz.entities.Message;
import ke.co.prioritymobile.chapabiz.entities.Photo;
import ke.co.prioritymobile.chapabiz.entities.Response;
import okhttp3.MultipartBody;
import okhttp3.RequestBody;
import okhttp3.ResponseBody;
import retrofit2.Call;
import retrofit2.http.Field;
import retrofit2.http.FormUrlEncoded;
import retrofit2.http.Multipart;
import retrofit2.http.POST;
import retrofit2.http.Part;

public interface RetrofitInterface {
//Shared

    @FormUrlEncoded
    @POST(EndPoint.CHAT_ROOMS)
    Call<ArrayList<ChatRoom>> getChatRooms(@Field("user") String user);

    @FormUrlEncoded
    @POST(EndPoint.ADD_CHAT)
    Call<ResponseBody> addChat(@Field("user") String user, @Field("rec") String rec);

    @FormUrlEncoded
    @POST(EndPoint.SEND_TOKEN)
    Call<ResponseBody> sendToken(@Field("user") String user, @Field("gcm") String gcm, @Field("email") String email);

    @FormUrlEncoded
    @POST(EndPoint.UPDATE_TOKEN)
    Call<ResponseBody> updateToken(@Field("user") String user, @Field("gcm") String gcm);

    @FormUrlEncoded
    @POST(EndPoint.SEND_MESSAGE)
    Call<ResponseBody> sendMessage(@Field("user") String user, @Field("room") String room, @Field("message") String message);

    @FormUrlEncoded
    @POST(EndPoint.GET_MESSAGES)
    Call<ArrayList<Message>> getMessages(@Field("room") String room, @Field("user") String user);

//    Business

    @FormUrlEncoded
    @POST(EndPoint.SIGN_IN_BUSINESS)
    Call<Response> signInBusiness(@Field("phone") String phone, @Field("pin") String pin);

    @FormUrlEncoded
    @POST(EndPoint.SIGN_UP_BUSINESS)
    Call<Response> signUpBusiness(@Field("business") String business, @Field("longitude") double longitude, @Field("latitude") double latitude);

    @POST(EndPoint.GET_COUNTIES)
    Call<ArrayList<County>> getCounties();

    @FormUrlEncoded
    @POST(EndPoint.UPDATE_BUSINESS)
    Call<ResponseBody> updateBusiness(@Field("id") String id, @Field("business") String business);

    @FormUrlEncoded
    @POST(EndPoint.UPDATE_BUSINESS_STATUS)
    Call<ResponseBody> updateStatus(@Field("id") String id, @Field("state") int state);

    @FormUrlEncoded
    @POST(EndPoint.GET_PHOTOS)
    Call<ArrayList<Photo>> getPhotos(@Field("id") String id);

    @FormUrlEncoded
    @POST(EndPoint.DELETE_PHOTO)
    Call<ResponseBody> deletePhoto(@Field("id") String id);

    @POST(EndPoint.SUB_CATEGORIES)
    Call<ArrayList<InterestDetail>> getSubCategories();

    @FormUrlEncoded
    @POST(EndPoint.UPDATE_INTEREST)
    Call<ResponseBody> updateInterest(@Field("id") String id, @Field("interest") int interest, @Field("state") int state);

    @FormUrlEncoded
    @POST(EndPoint.GET_BUSINESSES)
    Call<ArrayList<Business>> getBusinesses(@Field("interest") int interest);
}
