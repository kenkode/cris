package ke.co.prioritymobile.chapabiz.activities;

import android.app.ProgressDialog;
import android.content.Intent;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.content.pm.Signature;
import android.os.Bundle;
import android.support.v4.content.ContextCompat;
import android.support.v7.app.AppCompatActivity;
import android.text.InputType;
import android.text.TextUtils;
import android.util.Base64;
import android.util.Log;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;
import android.support.v7.widget.Toolbar;

import com.facebook.AccessToken;
import com.facebook.AccessTokenTracker;
import com.facebook.CallbackManager;
import com.facebook.FacebookCallback;
import com.facebook.FacebookException;
import com.facebook.FacebookSdk;
import com.facebook.GraphRequest;
import com.facebook.GraphResponse;
import com.facebook.login.LoginManager;
import com.facebook.login.LoginResult;
import com.facebook.login.widget.LoginButton;
import com.google.android.gms.auth.api.signin.GoogleSignIn;
import com.google.android.gms.auth.api.signin.GoogleSignInAccount;
import com.google.android.gms.auth.api.signin.GoogleSignInClient;
import com.google.android.gms.auth.api.signin.GoogleSignInOptions;
import com.google.android.gms.common.SignInButton;
import com.google.android.gms.common.api.ApiException;
import com.google.android.gms.tasks.Task;
import com.google.gson.Gson;

import org.json.JSONObject;

import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.ArrayList;
import java.util.Arrays;

import ke.co.prioritymobile.chapabiz.R;
import ke.co.prioritymobile.chapabiz.helpers.CbSession;
import ke.co.prioritymobile.chapabiz.helpers.LoginUserSelect;
import ke.co.prioritymobile.chapabiz.retrofit.RetrofitSetup;
import ke.co.prioritymobile.chapabiz.shopper.activities.CreateShopper;
import ke.co.prioritymobile.chapabiz.shopper.activities.UserHome;
import ke.co.prioritymobile.chapabiz.shopper.entities.Shopper;
import retrofit2.Call;
import retrofit2.Callback;

import static ke.co.prioritymobile.chapabiz.helpers.CbSession.FACEBOOK;
import static ke.co.prioritymobile.chapabiz.helpers.CbSession.GOOGLE;

/**
 * Created by Millie Agallo on 4/16/2018.
 */

public class Email_Login extends AppCompatActivity{//} implements View.OnClickListener {

    private CallbackManager callbackManager;
    private static final String EMAIL = "email";
    private static final String BUSINESS_TAG = "business_tag";
    private static final String AGENT_TAG = "agent_tag";
    private static final String SHOPPER_TAG = "shopper_tag";
    private static final int RC_SIGN_IN = 1001;
  //  private LoginButton fb;// loginButton;
    private SignInButton signInButton;
    private GoogleSignInClient googleSignInClient;
    private Button businessButton, agentButton, shopperButton;//, createAccount;
    private EditText username, password;
    ArrayList<Button> buttons;
    private LinearLayout orContainer, socialContainer;
    private LoginUserSelect loginUserSelect;
    private AccessTokenTracker accessTokenTracker;
    private Button signUpBusiness, googleLogin, facebookButton;

    CbSession session;

    TextView createAccount;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_email__login);

        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
       getSupportActionBar().setDisplayHomeAsUpEnabled(true);

        session = new CbSession(this);

        TextView imageView = (TextView) findViewById(R.id.forgot_password);

        createAccount = (TextView) findViewById(R.id.have_account);

//        createAccount.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View view) {
//                startActivity(new Intent(Email_Login.this, CreateShopper.class));
//            }
//        });


        imageView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(Email_Login.this, RequestPwdReset.class));
            }
        });

        FacebookSdk.sdkInitialize(this.getApplicationContext());

      //  fb = (LoginButton) findViewById(R.id.login_button);
        signInButton = (SignInButton) findViewById(R.id.sign_in_button);

     //   googleLogin = (Button)findViewById(R.id.google_login);

     //   googleLogin.setOnClickListener(this);
        signUpBusiness = (Button) findViewById(R.id.sign_up_business);

        username = (EditText) findViewById(R.id.username);
        password = (EditText) findViewById(R.id.password);

        signInButton = (SignInButton) findViewById(R.id.sign_in_button);
        createAccount = (Button) findViewById(R.id.create_account);

        orContainer = (LinearLayout) findViewById(R.id.or_container);
        socialContainer = (LinearLayout) findViewById(R.id.social_container);

        businessButton = (Button) findViewById(R.id.business);
        agentButton = (Button) findViewById(R.id.agent);
        shopperButton = (Button) findViewById(R.id.shopper);
        facebookButton = (Button) findViewById(R.id.fb);


        buttons = new ArrayList<>();
//        buttons.add(businessButton);
//        buttons.add(agentButton);
        // buttons.add(shopperButton);

        //       businessButton.setTag(BUSINESS_TAG);
//        agentButton.setTag(AGENT_TAG);
        // shopperButton.setTag(SHOPPER_TAG);

//        loginUserSelect = new LoginUserSelect(this, ContextCompat.getColor(this, R.color.colorPrimary),
//                ContextCompat.getColor(this, R.color.colorLightGreyAccent), buttons);

//        switch (session.getLastSelected()) {
//            case BUSINESS_TAG:
//                loginUserSelect.setSelected(businessButton);
//                break;
//            case AGENT_TAG:
//                loginUserSelect.setSelected(agentButton);
//                break;
//            case SHOPPER_TAG:
//                loginUserSelect.setSelected(shopperButton);
//                break;
//            default:
//                loginUserSelect.setSelected(businessButton);
//        }

//        businessButton.setOnClickListener(this);
        //   agentButton.setOnClickListener(this);
//        shopperButton.setOnClickListener(this);

        createAccount.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String m = username.getText().toString();
                String p = password.getText().toString();

                if (TextUtils.isEmpty(m) || TextUtils.isEmpty(p)) {
                    Toast.makeText(Email_Login.this, "Provide credentials", Toast.LENGTH_SHORT).show();
                    return;
                }

//                switch (session.getLastSelected()) {
//                    case BUSINESS_TAG:
//                        final ProgressDialog progressDialog = new ProgressDialog(LoginActivity.this);
//                        progressDialog.setMessage("Logging you in...");
//                        progressDialog.setIndeterminate(true);
//                        progressDialog.setCancelable(false);
//                        progressDialog.show();
//                        String phone = username.getText().toString();
//                        String pin = password.getText().toString();
//                        Call<Response> responseCall = RetrofitSetup.retrofitInterface.signInBusiness(phone, pin);
//                        responseCall.enqueue(new Callback<Response>() {
//                            @Override
//                            public void onResponse(Call<Response> call, retrofit2.Response<Response> response) {
//                                Toast toast = Toast.makeText(LoginActivity.this, "", Toast.LENGTH_LONG);
//                                toast.setGravity(Gravity.CENTER, 0, 0);
//                                if (response.isSuccessful()) {
//                                    Response business = response.body();
//                                    switch (business.getStatus()) {
//                                        case 200:
//                                            session.setBusiness(business.getBusiness());
//                                            session.setShopper(null);
//                                            session.setAgent(null);
//                                            session.setSignInMethod(EMAIL);
//                                            startActivity(new Intent(LoginActivity.this, BusinessActivity.class));
//                                            finish();
//                                            break;
//                                        case 302:
//                                            break;
//                                        case 404:
//                                            break;
//                                    }
//                                    toast.setText(business.getMessage());
//                                } else {
//                                    toast.setText("Could not sign you in at the moment!");
//                                }
//                                toast.show();
//                                progressDialog.dismiss();
//                            }
//
//                            @Override
//                            public void onFailure(Call<Response> call, Throwable t) {
//                                progressDialog.dismiss();
//                                t.printStackTrace();
//                            }
//                        });
//
//                        break;
//                    case AGENT_TAG:
//                        String agentPhone = username.getText().toString().trim();
//                        String agentPin = password.getText().toString().trim();
//                        final ProgressDialog progressDialog1 = new ProgressDialog(LoginActivity.this);
//                        progressDialog1.setIndeterminate(true);
//                        progressDialog1.setMessage("Authenticating..");
//                        progressDialog1.show();
//                        Call<Agent> agentCall = RetrofitSetup.retrofitInterface.signInAgent(agentPhone, agentPin);
//                        agentCall.enqueue(new Callback<Agent>() {
//                            @Override
//                            public void onResponse(Call<Agent> call, retrofit2.Response<Agent> response) {
//                                if (response.isSuccessful()) {
//                                    Agent agent = response.body();
//                                    if (agent.getStatus() == 200) {
//                                        session.setAgent(agent);
//                                        session.setSignInMethod(EMAIL);
//                                        startActivity(new Intent(LoginActivity.this, AgentActivity.class));
//                                    }
//                                    Toast.makeText(LoginActivity.this, agent.getMessage(), Toast.LENGTH_SHORT).show();
//                                } else {
//                                    Toast.makeText(LoginActivity.this, "Could not sign you at the moment", Toast.LENGTH_SHORT).show();
//                                }
//                                progressDialog1.dismiss();
//                            }
//
//                            @Override
//                            public void onFailure(Call<Agent> call, Throwable t) {
//                                t.printStackTrace();
//                                progressDialog1.dismiss();
//                                Toast.makeText(LoginActivity.this, "Could not sign you at the moment", Toast.LENGTH_SHORT).show();
//                            }
//                        });
//                        break;
                //       case SHOPPER_TAG:
                Shopper shopper = new Shopper();
                String user = username.getText().toString().trim();
                String pass = password.getText().toString().trim();

                if (TextUtils.isEmpty(user) || TextUtils.isEmpty(pass)) {
                    Toast toast = Toast.makeText(Email_Login.this, "Provide credentials", Toast.LENGTH_SHORT);
                    toast.setGravity(Gravity.CENTER, 0, 0);
                    toast.show();
                    return;
                }

                shopper.setPassword(pass);
                shopper.setEmail(user);

                Log.e("error", new Gson().toJson(shopper));

                attemptSignIn(new Gson().toJson(shopper), EMAIL);
                //   break;
                setupEmailLogin();
            }
//                finish();
            // }
        });

//        updateInput();

        //

    }

    @Override
    protected void onStart() {
        super.onStart();
//        switch (session.getLastSelected()) {
//            case BUSINESS_TAG:
//                if (session.getBusiness() != null) {
//                    startActivity(new Intent(LoginActivity.this, BusinessActivity.class));
//                    finish();
//                }
//                break;
//            case AGENT_TAG:
//                if (session.getAgent() != null) {
//                    startActivity(new Intent(LoginActivity.this, AgentActivity.class));
//                    finish();
//                }
//                break;
//            case SHOPPER_TAG:
        if (session.getShopper() != null) {
            startActivity(new Intent(Email_Login.this, Main3Activity.class));
            finish();
        }
//                break;
//        }
    }
//
//    @Override
//    public void onClick(View view) {
//        updateInput();
//
//    }

//    public void updateInput() {
//
//        password.setHint("Password");
//        username.setHint("Email");
//        username.setInputType(InputType.TYPE_CLASS_TEXT);
//      //  orContainer.setVisibility(View.VISIBLE);
////        socialContainer.setVisibility(View.VISIBLE);
//    }

    private void setupEmailLogin() {
        session.setSignInMethod(EMAIL);
        startActivity(new Intent(Email_Login.this, Main3Activity.class));
        finish();
    }

    private void getUserDetails(LoginResult loginResult) {
        GraphRequest request = GraphRequest.newMeRequest(loginResult.getAccessToken(),
                new GraphRequest.GraphJSONObjectCallback() {
                    @Override
                    public void onCompleted(JSONObject object, GraphResponse response) {
                        Log.e("LoginActivity", response.toString());
                        try {
                            String id = object.get("id").toString();
                            String email = object.get("email").toString();
                            String name = object.get("name").toString();
                            String gender = object.get("gender").toString();
                            //String birthday = object.get("birthday").toString();
                            String picUrl = String.format("https://graph.facebook.com/%s/picture?type=large", id);
                            Shopper shopper = new Shopper();
                            //shopper.setBirthdate(birthday);
                            shopper.setEmail(email);
                            shopper.setGender(gender);
                            shopper.setName(name);
                            shopper.setPicture(picUrl);

                            String shopperString = new Gson().toJson(shopper);
                            attemptSignIn(shopperString, GOOGLE);

                        } catch (Exception ignored) {
                        }
                    }
                });

        Bundle parameters = new Bundle();
        parameters.putString("fields", "id,name,email,gender");
        request.setParameters(parameters);
        request.executeAsync();
    }

    private void attemptSignIn(String userJson, final String method) {

        Call<Shopper> call = RetrofitSetup.retrofitInterface.login(userJson, method);
        final ProgressDialog progressDialog = new ProgressDialog(this);
        progressDialog.setIndeterminate(true);
        progressDialog.setMessage("Authenticating...");
        progressDialog.show();
        call.enqueue(new Callback<Shopper>() {
            @Override
            public void onResponse(Call<Shopper> call, retrofit2.Response<Shopper> response) {
                progressDialog.dismiss();
                if (response.isSuccessful()) {
                    Shopper shopper = response.body();
                    CbSession session = new CbSession(Email_Login.this);
                    session.setSignInMethod(method);

                    if (shopper.getStatus() != 200) {
                        Toast toast = Toast.makeText(Email_Login.this, "Authentication failed!", Toast.LENGTH_SHORT);
                        toast.setGravity(Gravity.CENTER, 0, 0);
                        toast.show();
                        return;
                    }

                    session.setShopper(shopper);

//                    switch (method) {
//                        case GOOGLE:
//                            session.setBusiness(null);
//                            session.setAgent(null);
//                            break;
//                        case FACEBOOK:
//                            session.setBusiness(null);
//                            session.setAgent(null);
//                            break;
//                        case EMAIL:
//                            session.setBusiness(null);
//                            session.setAgent(null);
//                            session.setSignInMethod(EMAIL);
//                            break;
//                    }

                    startActivity(new Intent(Email_Login.this, Main3Activity.class));
                    finish();
                } else {
                    Toast toast = Toast.makeText(Email_Login.this, "Try again later!", Toast.LENGTH_SHORT);
                    toast.setGravity(Gravity.CENTER, 0, 0);
                    toast.show();
                }
            }

            @Override
            public void onFailure(Call<Shopper> call, Throwable t) {
                t.printStackTrace();
            }
        });
    }
}

