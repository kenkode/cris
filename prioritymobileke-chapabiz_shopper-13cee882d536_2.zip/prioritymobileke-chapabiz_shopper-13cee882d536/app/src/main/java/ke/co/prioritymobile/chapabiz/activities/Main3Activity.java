package ke.co.prioritymobile.chapabiz.activities;

import android.Manifest;
import android.app.SearchManager;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.database.MatrixCursor;
import android.os.Bundle;
import android.provider.BaseColumns;
import android.support.annotation.NonNull;
import android.support.design.widget.BottomNavigationView;
import android.support.design.widget.BottomSheetBehavior;
import android.support.design.widget.FloatingActionButton;
import android.support.design.widget.Snackbar;
import android.support.v4.content.ContextCompat;
import android.support.v4.view.MenuItemCompat;
import android.support.v4.widget.CursorAdapter;
import android.support.v4.widget.SimpleCursorAdapter;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.GridLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.support.v7.widget.SearchView;
import android.support.v7.widget.Toolbar;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.GridView;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.auth.api.signin.GoogleSignInClient;
import com.google.android.gms.games.GamesMetadata;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.Marker;
import com.makeramen.roundedimageview.RoundedImageView;
import com.squareup.picasso.Picasso;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

import ke.co.prioritymobile.chapabiz.R;
import ke.co.prioritymobile.chapabiz.adapters.FavGridAdapter;
import ke.co.prioritymobile.chapabiz.shopper.activities.CartegoryEight;
import ke.co.prioritymobile.chapabiz.shopper.activities.CartegoryFive;
import ke.co.prioritymobile.chapabiz.shopper.activities.CartegoryFour;
import ke.co.prioritymobile.chapabiz.shopper.activities.CartegoryNine;
import ke.co.prioritymobile.chapabiz.shopper.activities.CartegoryOne;
import ke.co.prioritymobile.chapabiz.shopper.activities.CartegorySeven;
import ke.co.prioritymobile.chapabiz.shopper.activities.CartegorySix;
import ke.co.prioritymobile.chapabiz.shopper.activities.CartegoryThree;
import ke.co.prioritymobile.chapabiz.shopper.activities.CartegoryTwo;
import ke.co.prioritymobile.chapabiz.shopper.activities.FavoritesActivity;
import ke.co.prioritymobile.chapabiz.shopper.entities.Business;
import ke.co.prioritymobile.chapabiz.entities.Photo;
import ke.co.prioritymobile.chapabiz.helpers.BottomNavigationViewHelper;
import ke.co.prioritymobile.chapabiz.helpers.CbSession;
import ke.co.prioritymobile.chapabiz.retrofit.RetrofitSetup;
import ke.co.prioritymobile.chapabiz.shopper.activities.ChapaBiz;
import ke.co.prioritymobile.chapabiz.shopper.activities.InterestActivity;
import ke.co.prioritymobile.chapabiz.shopper.activities.ProfileActivity;
//import ke.co.prioritymobile.chapabiz.shopper.activities.ShopperHome;
import ke.co.prioritymobile.chapabiz.shopper.adapters.QuickInterestAdapter2;
import ke.co.prioritymobile.chapabiz.shopper.adapters.SearchResultAdapter;
import ke.co.prioritymobile.chapabiz.shopper.entities.InterestDetail;
import ke.co.prioritymobile.chapabiz.shopper.entities.SearchResult;
import ke.co.prioritymobile.chapabiz.shopper.entities.ShopperFav;
import ke.co.prioritymobile.chapabiz.shopper.entities.SubCategoryDetail;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class Main3Activity extends AppCompatActivity implements QuickInterestAdapter2.Clicked {

    private TextView mTextMessage;
   // private SearchView searchView;
    private boolean isInFront;
    private GoogleSignInClient googleSignInClient;
    BottomSheetBehavior companyInfoSheet;
    private CbSession session;
    private List<String> suggestionList;
    private Map<String, Business> markers;
    private Toolbar toolbar;
    private ArrayList<SearchResult> searchResults;
    private GoogleMap googleMap;
    private SearchView searchView;
    private SearchResultAdapter searchResultAdapter;
    private ArrayList<InterestDetail> suggestionInterest, updatedSuggestionList;
    private Business currentBusiness;
    private TextView companyName, subCompanyName, companyLocation, distance, availability, verified, description;
      private TextView  phone, direction, message;

      TextView more, more2, more3, more4, more5, more6, more7, more8, more9;

    private BottomNavigationView.OnNavigationItemSelectedListener mOnNavigationItemSelectedListener
            = new BottomNavigationView.OnNavigationItemSelectedListener() {

        @Override
        public boolean onNavigationItemSelected(@NonNull MenuItem item) {
            switch (item.getItemId()) {
                case R.id.navigation_home:
                    mTextMessage.setText(R.string.title_home);
                    return true;
                case R.id.navigation_search:
                    //  mTextMessage.setText(R.string.title_dashboard);
                    Intent job1 = new Intent(Main3Activity.this, ChapaBiz.class);
                    startActivity(job1);
                    return true;
                case R.id.navigation_favorites:
                    //  mTextMessage.setText(R.string.title_notifications);
                  //  Intent joboneIntent = new Intent(Main3Activity.this, InterestActivity.class);
                    Intent joboneIntent = new Intent(Main3Activity.this, FavoritesActivity.class);

                    startActivity(joboneIntent);
                    return true;
                case R.id.navigation_profile:
                    // mTextMessage.setText(R.string.title_notifications);
                    Intent jobz = new Intent(Main3Activity.this, ProfileActivity.class);
                    startActivity(jobz);
                    return true;
            }
            return true;
        }
    };

    private RecyclerView searchList;
    private BottomSheetBehavior bottomSheetBehavior;

    @Override
    protected void onStart() {
        super.onStart();
        Call<ArrayList<InterestDetail>> subCatCall = RetrofitSetup.retrofitInterface.getSubCategories();
        subCatCall.enqueue(new Callback<ArrayList<InterestDetail>>() {
            @Override
            public void onResponse(Call<ArrayList<InterestDetail>> call, Response<ArrayList<InterestDetail>> response) {
                if (response.isSuccessful()) {
                    suggestionInterest = response.body();

                    for (InterestDetail interestDetail :
                            suggestionInterest) {
                        suggestionList.add(interestDetail.getName());
                    }
                } else {

                }
            }

            @Override
            public void onFailure(Call<ArrayList<InterestDetail>> call, Throwable t) {

            }
        });
    }

    @Override
    protected void onCreate(final Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main3);

        toolbar = findViewById(R.id.toolbar);

        setSupportActionBar(toolbar);

        toolbar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

            }
        });

        companyLocation = findViewById(R.id.company_info_location);
        availability = findViewById(R.id.availability);
        verified = findViewById(R.id.verified);
        distance = findViewById(R.id.distance);
        companyName = findViewById(R.id.company_info_name);
        description = findViewById(R.id.company_description);
        searchView = findViewById(R.id.search_view);

        more = findViewById(R.id.more);
        more2 = findViewById(R.id.more2);
        more3 = findViewById(R.id.more3);
        more4 = findViewById(R.id.more4);
        more5 = findViewById(R.id.more5);
        more6 = findViewById(R.id.more6);
        more7 = findViewById(R.id.more7);
        more8 = findViewById(R.id.more8);
        more9 = findViewById(R.id.more9);

        session = new CbSession(this);


        more.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                Intent more = new Intent(Main3Activity.this, CartegoryOne.class);
                startActivity(more);
            }
        });

        more2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                Intent more2 = new Intent(Main3Activity.this, CartegoryTwo.class);
                startActivity(more2);
            }
        });

        more3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                Intent more2 = new Intent(Main3Activity.this, CartegoryThree.class);
                startActivity(more2);
            }
        });

        more4.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                Intent more2 = new Intent(Main3Activity.this, CartegoryFour.class);
                startActivity(more2);
            }
        });

        more5.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                Intent more2 = new Intent(Main3Activity.this, CartegoryFive.class);
                startActivity(more2);
            }
        });

        more6.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                Intent more2 = new Intent(Main3Activity.this, CartegorySix.class);
                startActivity(more2);
            }
        });

        more7.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                Intent more2 = new Intent(Main3Activity.this, CartegorySeven.class);
                startActivity(more2);
            }
        });

        more8.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                Intent more2 = new Intent(Main3Activity.this, CartegoryEight.class);
                startActivity(more2);
            }
        });

        more9.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                Intent more2 = new Intent(Main3Activity.this, CartegoryNine.class);
                startActivity(more2);
            }
        });

        mTextMessage = (TextView) findViewById(R.id.message);
        BottomNavigationView navigation = (BottomNavigationView) findViewById(R.id.navigation);
        navigation.setOnNavigationItemSelectedListener(mOnNavigationItemSelectedListener);

        BottomNavigationView bottomNavigationView = (BottomNavigationView) findViewById(R.id.navigation);
        BottomNavigationViewHelper.disableShiftMode(bottomNavigationView);


        CbSession session = new CbSession(this);
        try {
            TextView name = findViewById(R.id.name);

            name.setText(session.getShopper().getName());

            // ImageView imageView = findViewById(R.id.im1);
            RoundedImageView imageView = findViewById(R.id.im1);
            Picasso.with(this).load(session.getShopper().getPicture())
                    .placeholder(ContextCompat.getDrawable(this, R.drawable.user))
                    .into(imageView);
        } catch (Exception e) {
            if (session.getSignInMethod() == CbSession.FACEBOOK) {

            }
        }


        //sub category 1
        final RecyclerView recyclerView = findViewById(R.id.subcategorylist1);
          GridLayoutManager gridLayoutManager = new GridLayoutManager(this,11 );
          recyclerView.setLayoutManager(gridLayoutManager);

        Call<ArrayList<Business>> arrayListCall = RetrofitSetup.retrofitInterface.getSubCategories1();
        arrayListCall.enqueue(new Callback<ArrayList<Business>>() {
            @Override
            public void onResponse(Call<ArrayList<Business>> call, Response<ArrayList<Business>> response) {
                if (response.isSuccessful()) {
                    ArrayList<Business> interests1 = response.body();

                    QuickInterestAdapter2 quickInterestAdapter2 = new QuickInterestAdapter2(Main3Activity.this, interests1);
                    recyclerView.setAdapter(quickInterestAdapter2);
                }
            }
            @Override
            public void onFailure(Call<ArrayList<Business>> call, Throwable t) {

            }
        });

        //  //sub category 2
        final RecyclerView recyclerView2 = findViewById(R.id.subcategorylist2);
        GridLayoutManager gridLayoutManager2 = new GridLayoutManager(this, 10);
        recyclerView2.setLayoutManager(gridLayoutManager2);

        Call<ArrayList<Business>> arrayListCall2 = RetrofitSetup.retrofitInterface.getSubCategories2();
        arrayListCall2.enqueue(new Callback<ArrayList<Business>>() {
            @Override
            public void onResponse(Call<ArrayList<Business>> call2, Response<ArrayList<Business>> response) {
                if (response.isSuccessful()) {
                    ArrayList<Business> interests2 = response.body();

                    QuickInterestAdapter2 quickInterestAdapter2 = new QuickInterestAdapter2(Main3Activity.this, interests2);
                    recyclerView2.setAdapter(quickInterestAdapter2);
                }
            }
            @Override
            public void onFailure(Call<ArrayList<Business>> call2, Throwable t) {

            }
        });

        //sub category 3

        final RecyclerView recyclerView3 = findViewById(R.id.subcategorylist3);
        GridLayoutManager gridLayoutManager3 = new GridLayoutManager(this, 10);
        recyclerView3.setLayoutManager(gridLayoutManager3);

        Call<ArrayList<Business>> arrayListCall3 = RetrofitSetup.retrofitInterface.getSubCategories3();
        arrayListCall3.enqueue(new Callback<ArrayList<Business>>() {
            @Override
            public void onResponse(Call<ArrayList<Business>> call3, Response<ArrayList<Business>> response) {
                if (response.isSuccessful()) {
                    ArrayList<Business> interests3 = response.body();

                    QuickInterestAdapter2 quickInterestAdapter3 = new QuickInterestAdapter2(Main3Activity.this, interests3);
                    recyclerView3.setAdapter(quickInterestAdapter3);
                }
            }
            @Override
            public void onFailure(Call<ArrayList<Business>> call3, Throwable t) {

            }
        });

        //sub cat 4

        final RecyclerView recyclerView4 = findViewById(R.id.subcategorylist4);
        GridLayoutManager gridLayoutManager4 = new GridLayoutManager(this, 9);
        recyclerView4.setLayoutManager(gridLayoutManager4);

        Call<ArrayList<Business>> arrayListCall4 = RetrofitSetup.retrofitInterface.getSubCategories4();
        arrayListCall4.enqueue(new Callback<ArrayList<Business>>() {
            @Override
            public void onResponse(Call<ArrayList<Business>> call4, Response<ArrayList<Business>> response) {
                if (response.isSuccessful()) {
                    ArrayList<Business> interests4 = response.body();

                    QuickInterestAdapter2 quickInterestAdapter4 = new QuickInterestAdapter2(Main3Activity.this, interests4);
                    recyclerView4.setAdapter(quickInterestAdapter4);
                }
            }
            @Override
            public void onFailure(Call<ArrayList<Business>> call4, Throwable t) {

            }
        });

        // sub cat 5

        final RecyclerView recyclerView5 = findViewById(R.id.subcategorylist5);
        GridLayoutManager gridLayoutManager5 = new GridLayoutManager(this, 10);
       // recyclerView.setLayoutManager(gridLayoutManager5);

        Call<ArrayList<Business>> arrayListCall5 = RetrofitSetup.retrofitInterface.getSubCategories5();
        arrayListCall5.enqueue(new Callback<ArrayList<Business>>() {
            @Override
            public void onResponse(Call<ArrayList<Business>> call5, Response<ArrayList<Business>> response) {
                if (response.isSuccessful()) {
                    ArrayList<Business> interests5 = response.body();

                    QuickInterestAdapter2 quickInterestAdapter5 = new QuickInterestAdapter2(Main3Activity.this, interests5);
                    recyclerView5.setAdapter(quickInterestAdapter5);
                }
            }
            @Override
            public void onFailure(Call<ArrayList<Business>> call5, Throwable t) {

            }
        });

        // sub cat 6

        final RecyclerView recyclerView6 = findViewById(R.id.subcategorylist6);
        GridLayoutManager gridLayoutManager6 = new GridLayoutManager(this, 10);
        recyclerView6.setLayoutManager(gridLayoutManager6);

        Call<ArrayList<Business>> arrayListCall6 = RetrofitSetup.retrofitInterface.getSubCategories6();
        arrayListCall6.enqueue(new Callback<ArrayList<Business>>() {
            @Override
            public void onResponse(Call<ArrayList<Business>> call6, Response<ArrayList<Business>> response) {
                if (response.isSuccessful()) {
                    ArrayList<Business> interests6 = response.body();

                    QuickInterestAdapter2 quickInterestAdapter6 = new QuickInterestAdapter2(Main3Activity.this, interests6);
                    recyclerView6.setAdapter(quickInterestAdapter6);
                }
            }
            @Override
            public void onFailure(Call<ArrayList<Business>> call6, Throwable t) {

            }
        });

        //sub cat 7

        final RecyclerView recyclerView7 = findViewById(R.id.subcategorylist7);
        GridLayoutManager gridLayoutManager7 = new GridLayoutManager(this, 10);
        recyclerView7.setLayoutManager(gridLayoutManager7);

        Call<ArrayList<Business>> arrayListCall7 = RetrofitSetup.retrofitInterface.getSubCategories7();
        arrayListCall7.enqueue(new Callback<ArrayList<Business>>() {
            @Override
            public void onResponse(Call<ArrayList<Business>> call7, Response<ArrayList<Business>> response) {
                if (response.isSuccessful()) {
                    ArrayList<Business> interests7 = response.body();

                    QuickInterestAdapter2 quickInterestAdapter7 = new QuickInterestAdapter2(Main3Activity.this, interests7);
                    recyclerView7.setAdapter(quickInterestAdapter7);



                }
            }
            @Override
            public void onFailure(Call<ArrayList<Business>> call7, Throwable t) {

            }
        });

        //sub cat 8

        final RecyclerView recyclerView8 = findViewById(R.id.subcategorylist8);
        GridLayoutManager gridLayoutManager8 = new GridLayoutManager(this, 10);
        recyclerView8.setLayoutManager(gridLayoutManager8);

        Call<ArrayList<Business>> arrayListCall8 = RetrofitSetup.retrofitInterface.getSubCategories8();
        arrayListCall8.enqueue(new Callback<ArrayList<Business>>() {
            @Override
            public void onResponse(Call<ArrayList<Business>> call8, Response<ArrayList<Business>> response) {
                if (response.isSuccessful()) {
                    ArrayList<Business> interests8 = response.body();

                    QuickInterestAdapter2 quickInterestAdapter8 = new QuickInterestAdapter2(Main3Activity.this, interests8);
                    recyclerView8.setAdapter(quickInterestAdapter8);
                }
            }
            @Override
            public void onFailure(Call<ArrayList<Business>> call8, Throwable t) {

            }
        });

        //sub cat 9

        final RecyclerView recyclerView9 = findViewById(R.id.subcategorylist9);
        GridLayoutManager gridLayoutManager9 = new GridLayoutManager(this, 10);
        recyclerView9.setLayoutManager(gridLayoutManager9);

        Call<ArrayList<Business>> arrayListCall9 = RetrofitSetup.retrofitInterface.getSubCategories9();
        arrayListCall9.enqueue(new Callback<ArrayList<Business>>() {
            @Override
            public void onResponse(Call<ArrayList<Business>> call9, Response<ArrayList<Business>> response) {
                if (response.isSuccessful()) {
                    ArrayList<Business> interests9 = response.body();

                    QuickInterestAdapter2 quickInterestAdapter9 = new QuickInterestAdapter2(Main3Activity.this, interests9);
                    recyclerView9.setAdapter(quickInterestAdapter9);
                }
            }
            @Override
            public void onFailure(Call<ArrayList<Business>> call9, Throwable t) {

            }
        });

        suggestionList = new ArrayList<>();
        updatedSuggestionList = new ArrayList<>();

        searchResults = new ArrayList<>();

        markers = new HashMap();

        searchResultAdapter = new SearchResultAdapter(this, getSupportFragmentManager(), searchResults);
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.chapa_biz, menu);

        SearchManager searchManager = (SearchManager) getSystemService(Context.SEARCH_SERVICE);
        searchView = (SearchView) menu.findItem(R.id.menu_search).getActionView();

        searchView.setSearchableInfo(searchManager.getSearchableInfo(getComponentName()));
        searchView.setIconifiedByDefault(false);

        final CursorAdapter cursorAdapter = new SimpleCursorAdapter(this,
                R.layout.search_view,
                null,
                new String[]{SearchManager.SUGGEST_COLUMN_TEXT_1},
                new int[]{R.id.text1}, 0);

        searchView.setSuggestionsAdapter(cursorAdapter);

        searchView.setOnSuggestionListener(new SearchView.OnSuggestionListener() {
            @Override
            public boolean onSuggestionSelect(int position) {
                return false;
            }

            @Override
            public boolean onSuggestionClick(int position) {
                searchView.clearFocus();
                searchView.setQuery(updatedSuggestionList.get(position).getName(), false);
                Intent job1 = new Intent(Main3Activity.this, ChapaBiz.class);
                job1.putExtra("query", updatedSuggestionList.get(position).getId());
                job1.putExtra("string", updatedSuggestionList.get(position).getName());
                startActivity(job1);
//                interestClicked(Integer.parseInt(updatedSuggestionList.get(position).getId()));
                return true;
            }
        });

        searchView.setOnCloseListener(new SearchView.OnCloseListener() {
            @Override
            public boolean onClose() {
                searchView.clearFocus();
                searchList.setAdapter(null);
                searchResultAdapter.notifyDataSetChanged();
                return true;
            }
        });

        searchView.setOnQueryTextListener(new SearchView.OnQueryTextListener() {
            @Override
            public boolean onQueryTextSubmit(String query) {
                for (int i = 0; i < updatedSuggestionList.size(); i++) {
                    if (updatedSuggestionList.get(i).getName().equals(query)) {
                        Toast.makeText(Main3Activity.this, query, Toast.LENGTH_SHORT).show();
//                        placeMarkers(Integer.parseInt(updatedSuggestionList.get(i).getId()));
                        break;
                    }
                }

                return true;
            }

            @Override
            public boolean onQueryTextChange(String newText) {
                String columns[] = {BaseColumns._ID,
                        SearchManager.SUGGEST_COLUMN_TEXT_1,
                        SearchManager.SUGGEST_COLUMN_INTENT_ACTION};

                MatrixCursor matrixCursor = new MatrixCursor(columns);
                updatedSuggestionList.clear();
                for (int i = 0; i < suggestionList.size(); i++) {
                    if (newText.regionMatches(true, 0, suggestionList.get(i), 0, newText.length())) {
                        String temp[] = {Integer.toString(i), suggestionList.get(i), suggestionList.get(i)};
                        matrixCursor.addRow(temp);
                        updatedSuggestionList.add(suggestionInterest.get(i));
                    }
                }
                cursorAdapter.swapCursor(matrixCursor);
                return true;
            }
        });

        return true;
    }


    @Override
    public void interestClicked(int interest) {

    }

    @Override
    public void onMapReady(GoogleMap googleMap) {
        this.googleMap = googleMap;
//        if (checkLocationPermission()) {
//            if (ContextCompat.checkSelfPermission(this,
//                    Manifest.permission.ACCESS_FINE_LOCATION)
//                    == PackageManager.PERMISSION_GRANTED) {
//
//                googleMap.setMyLocationEnabled(true);
//
//
//            }
//        }

        googleMap.setOnMapClickListener(new GoogleMap.OnMapClickListener() {
            @Override
            public void onMapClick(LatLng latLng) {
//                if (companySubSheet.getState() == BottomSheetBehavior.STATE_EXPANDED) {
//                    companySubSheet.setHideable(true);
//                    companySubSheet.setState(BottomSheetBehavior.STATE_HIDDEN);
//                    companyInfoSheet.setState(BottomSheetBehavior.STATE_EXPANDED);
//                } else if (companyInfoSheet.getState() == BottomSheetBehavior.STATE_EXPANDED
//                        || companyInfoSheet.getState() == BottomSheetBehavior.STATE_COLLAPSED) {
//                    companyInfoSheet.setState(BottomSheetBehavior.STATE_HIDDEN);
//                    companySubSheet.setHideable(false);
//                    companySubSheet.setState(BottomSheetBehavior.STATE_EXPANDED);
//                } else if (searchResultsSheet.getState() == BottomSheetBehavior.STATE_EXPANDED) {
//                    searchResultsSheet.setHideable(true);
//                    searchResultsSheet.setState(BottomSheetBehavior.STATE_HIDDEN);
//                    showListSheet.setHideable(false);
//                    showListSheet.setState(BottomSheetBehavior.STATE_EXPANDED);
//                } else if (showListSheet.getState() == BottomSheetBehavior.STATE_EXPANDED) {
//                    showListSheet.setHideable(true);
//                    showListSheet.setState(BottomSheetBehavior.STATE_HIDDEN);
//                    searchResultsSheet.setHideable(false);
//                    searchResultsSheet.setState(BottomSheetBehavior.STATE_EXPANDED);
//                } else
                    if (bottomSheetBehavior.getState() == BottomSheetBehavior.STATE_EXPANDED) {
                    bottomSheetBehavior.setHideable(true);
                    bottomSheetBehavior.setState(BottomSheetBehavior.STATE_HIDDEN);
                } else {
                    bottomSheetBehavior.setHideable(false);
                    bottomSheetBehavior.setState(BottomSheetBehavior.STATE_EXPANDED);
                }
            }
        });

        googleMap.setOnMarkerClickListener(new GoogleMap.OnMarkerClickListener() {
            @Override
            public boolean onMarkerClick(Marker marker) {
                String businessName = marker.getTitle();
                companyName.setText(businessName);
                subCompanyName.setText(businessName);

                Business business = markers.get(marker.getId());
                setUpBusinessProfile(business);
                currentBusiness = business;


                companyInfoSheet.setState(BottomSheetBehavior.STATE_EXPANDED);

                return false;
            }
        });

        googleMap.setOnMarkerClickListener(new GoogleMap.OnMarkerClickListener() {
            @Override
            public boolean onMarkerClick(Marker marker) {
                String businessName = marker.getTitle();
                companyName.setText(businessName);
                subCompanyName.setText(businessName);

                Business business = markers.get(marker.getId());
                setUpBusinessProfile(business);
                currentBusiness = business;


                companyInfoSheet.setState(BottomSheetBehavior.STATE_EXPANDED);

                return false;
            }
        });

        googleMap.getUiSettings().setCompassEnabled(true);
        googleMap.getUiSettings().setMyLocationButtonEnabled(true);
        googleMap.getUiSettings().setRotateGesturesEnabled(false);
    }


    private void setUpBusinessProfile(final Business business) {
        companyLocation.setText(business.getTown());
        distance.setText(business.getDistance() != null ? String.format("%s Km(s) Away", Integer.parseInt(business.getDistance()) / 1000) : "__Km(s)");
        availability.setText(business.getTimestamps());
        verified.setText(business.getVerified() == 1 ? "Verified" : "Not Verified");
        verified.setTextColor(business.getVerified() == 1 ? ContextCompat.getColor(this, R.color.colorGreenAccent) : ContextCompat.getColor(this, R.color.colorRedAccent));
        description.setText(business.getDescription());
        companyName.setText(business.getName());
        subCompanyName.setText(business.getName());

    }
  // Log.e("");

}
