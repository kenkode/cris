package ke.co.prioritymobile.chapabiz.activities;

import android.app.ProgressDialog;
import android.content.Intent;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.content.pm.Signature;
import android.os.Bundle;
import android.support.v4.content.ContextCompat;
import android.support.v7.app.AppCompatActivity;
import android.text.InputType;
import android.text.TextUtils;
import android.util.Base64;
import android.util.Log;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;
import android.support.v7.widget.Toolbar;

import com.facebook.AccessToken;
import com.facebook.AccessTokenTracker;
import com.facebook.CallbackManager;
import com.facebook.FacebookCallback;
import com.facebook.FacebookException;
import com.facebook.FacebookSdk;
import com.facebook.GraphRequest;
import com.facebook.GraphResponse;
import com.facebook.login.LoginManager;
import com.facebook.login.LoginResult;
import com.facebook.login.widget.LoginButton;
import com.google.android.gms.auth.api.signin.GoogleSignIn;
import com.google.android.gms.auth.api.signin.GoogleSignInAccount;
import com.google.android.gms.auth.api.signin.GoogleSignInClient;
import com.google.android.gms.auth.api.signin.GoogleSignInOptions;
import com.google.android.gms.common.SignInButton;
import com.google.android.gms.common.api.ApiException;
import com.google.android.gms.tasks.Task;
import com.google.gson.Gson;

import org.json.JSONObject;

import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.ArrayList;
import java.util.Arrays;

import ke.co.prioritymobile.chapabiz.R;
import ke.co.prioritymobile.chapabiz.entities.Response;
import ke.co.prioritymobile.chapabiz.helpers.CbSession;
import ke.co.prioritymobile.chapabiz.helpers.LoginUserSelect;
import ke.co.prioritymobile.chapabiz.retrofit.RetrofitSetup;
import ke.co.prioritymobile.chapabiz.shopper.activities.CreateShopper;
import ke.co.prioritymobile.chapabiz.shopper.activities.NewUser;
import ke.co.prioritymobile.chapabiz.shopper.activities.PrivacyPolicy;
//import ke.co.prioritymobile.chapabiz.shopper.activities.ShopperHome;
import ke.co.prioritymobile.chapabiz.shopper.activities.Terms;
import ke.co.prioritymobile.chapabiz.shopper.activities.UserHome;
import ke.co.prioritymobile.chapabiz.shopper.entities.Shopper;
import retrofit2.Call;
import retrofit2.Callback;

import static ke.co.prioritymobile.chapabiz.helpers.CbSession.FACEBOOK;
import static ke.co.prioritymobile.chapabiz.helpers.CbSession.GOOGLE;

/**
 * Created by Millie Agallo on 4/16/2018.
 */

public class ShopperLogin extends AppCompatActivity implements View.OnClickListener {

    private CallbackManager callbackManager;
    private static final String EMAIL = "email";
    private static final String BUSINESS_TAG = "business_tag";
    private static final String AGENT_TAG = "agent_tag";
    private static final String SHOPPER_TAG = "shopper_tag";
    private static final int RC_SIGN_IN = 1001;
    private LoginButton fb;// loginButton;
    private SignInButton signInButton;
    private GoogleSignInClient googleSignInClient;
    private Button businessButton, agentButton, shopperButton;
    private EditText username, password;
    ArrayList<Button> buttons;
    private LinearLayout orContainer, socialContainer;
    private LoginUserSelect loginUserSelect;
    private AccessTokenTracker accessTokenTracker;
    private Button signUpBusiness, googleLogin, facebookButton;

    TextView tc, pp;
    Button newaccount;

    TextView createAccount;

    CbSession session;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_shopper_login);
        try {
            PackageInfo info = getPackageManager().getPackageInfo(
                    "ke.co.prioritymobile.chapabiz",
                    PackageManager.GET_SIGNATURES);
            for (Signature signature : info.signatures) {
                MessageDigest md = MessageDigest.getInstance("SHA");
                md.update(signature.toByteArray());
                Log.e("KeyHash:", Base64.encodeToString(md.digest(), Base64.DEFAULT));
                //05-16 10:19:54.853 31017-31017/? E/KeyHash:: eQo20rxdLGjUhc7Q6I2/3ajhCBo=

            }
        } catch (PackageManager.NameNotFoundException e) {


        } catch (NoSuchAlgorithmException e) {

        }

        session = new CbSession(this);

        ImageView imageView = (ImageView) findViewById(R.id.back);

//        imageView.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View view) {
//                startActivity(new Intent(ShopperLogin.this, MainLogin.class));
//            }
//        });

        FacebookSdk.sdkInitialize(this.getApplicationContext());

        fb = (LoginButton) findViewById(R.id.login_button);
        signInButton = (SignInButton) findViewById(R.id.sign_in_button);

        googleLogin = (Button) findViewById(R.id.google_login);

        googleLogin.setOnClickListener(this);
        signUpBusiness = (Button) findViewById(R.id.sign_up_business);

        username = (EditText) findViewById(R.id.username);
        password = (EditText) findViewById(R.id.password);

        signInButton = (SignInButton) findViewById(R.id.sign_in_button);
        newaccount = (Button) findViewById(R.id.create_account_original);

        tc = (TextView) findViewById(R.id.tc);

        pp = (TextView) findViewById(R.id.pp);

        //  newaccount = (Button) findViewById(R.id.create_account_original);


//        createAccount.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View view) {
//                startActivity(new Intent(ShopperLogin.this, Email_Login.class));
//            }
//        });

        newaccount.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(ShopperLogin.this, CreateShopper.class));
                //   startActivity(new Intent(ShopperLogin.this, NewUser.class));

            }
        });

        tc.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(ShopperLogin.this, Terms.class));
            }
        });

        pp.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(ShopperLogin.this, PrivacyPolicy.class));

                //   startActivity(new Intent(ShopperLogin.this, PrivacyPolicy.class));
            }
        });

        orContainer = (LinearLayout) findViewById(R.id.or_container);
        socialContainer = (LinearLayout) findViewById(R.id.social_container);

        businessButton = (Button) findViewById(R.id.business);
        agentButton = (Button) findViewById(R.id.agent);
        shopperButton = (Button) findViewById(R.id.shopper);
        facebookButton = (Button) findViewById(R.id.fb);


        buttons = new ArrayList<>();

        facebookButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                fb.performClick();
            }
        });

//        createAccount.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View view) {
//                String m = username.getText().toString();
//                String p = password.getText().toString();
//
//                if (TextUtils.isEmpty(m) || TextUtils.isEmpty(p)) {
//                    Toast.makeText(ShopperLogin.this, "Provide credentials", Toast.LENGTH_SHORT).show();
//                    return;
//                }
//
//                        Shopper shopper = new Shopper();
//                        String user = username.getText().toString().trim();
//                        String pass = password.getText().toString().trim();
//
//                        if (TextUtils.isEmpty(user) || TextUtils.isEmpty(pass)) {
//                            Toast toast = Toast.makeText(ShopperLogin.this, "Provide credentials", Toast.LENGTH_SHORT);
//                            toast.setGravity(Gravity.CENTER, 0, 0);
//                            toast.show();
//                            return;
//                        }
//
//                        shopper.setPassword(pass);
//                        shopper.setEmail(user);
//
//                        Log.e("error", new Gson().toJson(shopper));
//
//                        attemptSignIn(new Gson().toJson(shopper), EMAIL);
//                     //   break;
//                setupEmailLogin();
//                }
////                finish();
//           // }
//        });
//
////        updateInput();
//
        setupFacebookLogin();
        setupGoogleLogin();
//        //
//
//    }

    }

    @Override
    protected void onStart() {
        super.onStart();
//        switch (session.getLastSelected()) {
//            case BUSINESS_TAG:
//                if (session.getBusiness() != null) {
//                    startActivity(new Intent(LoginActivity.this, BusinessActivity.class));
//                    finish();
//                }
//                break;
//            case AGENT_TAG:
//                if (session.getAgent() != null) {
//                    startActivity(new Intent(LoginActivity.this, AgentActivity.class));
//                    finish();
//                }
//                break;
//            case SHOPPER_TAG:
        if (session.getShopper() != null) {
            startActivity(new Intent(ShopperLogin.this, Main3Activity.class));
            finish();
        }
//                break;
//        }
    }

    @Override
    public void onClick(View view) {
//
        updateInput();

    }

    public void updateInput() {

        password.setHint("Password");
        username.setHint("Email");
        username.setInputType(InputType.TYPE_CLASS_TEXT);
        orContainer.setVisibility(View.VISIBLE);
        socialContainer.setVisibility(View.VISIBLE);
    }

    private void setupGoogleLogin() {
        GoogleSignInOptions gso = new GoogleSignInOptions.Builder(GoogleSignInOptions.DEFAULT_SIGN_IN)
                .requestEmail()
                .build();

        googleSignInClient = GoogleSignIn.getClient(this, gso);

        //Log.d("error",gso);

        GoogleSignInAccount account = GoogleSignIn.getLastSignedInAccount(this);
        if (account != null) {
            session.setSignInMethod(GOOGLE);
            startActivity(new Intent(ShopperLogin.this, Main3Activity.class));
            finish();
        }
//test changed
        googleLogin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent signInIntent = googleSignInClient.getSignInIntent();
                startActivityForResult(signInIntent, RC_SIGN_IN);
            }
        });

    }

    private void setupEmailLogin() {
        session.setSignInMethod(EMAIL);
        startActivity(new Intent(ShopperLogin.this, Main3Activity.class));
        finish();
    }


    private void setupFacebookLogin() {
        callbackManager = CallbackManager.Factory.create();

        boolean loggedIn = AccessToken.getCurrentAccessToken() != null;

        accessTokenTracker = new AccessTokenTracker() {
            @Override
            protected void onCurrentAccessTokenChanged(AccessToken oldAccessToken, AccessToken newAccessToken) {
//                session.setFacebookToken(newAccessToken.getToken());
            }
        };

        if (loggedIn) {
            session.setSignInMethod(FACEBOOK);

//            FacebookSdk.get
            LoginManager.getInstance().logInWithReadPermissions(this, Arrays.asList("public_profile", "email"));
            startActivity(new Intent(ShopperLogin.this, Main3Activity.class));
            finish();
            return;
        }

        fb.setReadPermissions(Arrays.asList(
                "public_profile", "email"));

        fb.registerCallback(callbackManager, new FacebookCallback<LoginResult>() {
            @Override
            public void onSuccess(LoginResult loginResult) {
                getUserDetails(loginResult);
            }

            @Override
            public void onCancel() {

            }

            @Override
            public void onError(FacebookException exception) {
                Toast.makeText(ShopperLogin.this, exception.getMessage(), Toast.LENGTH_SHORT).show();
            }
        });
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        callbackManager.onActivityResult(requestCode, resultCode, data);
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == RC_SIGN_IN) {
            Task<GoogleSignInAccount> task = GoogleSignIn.getSignedInAccountFromIntent(data);
            handleSignInResult(task);
        }
//        else {
//
//        }
    }

    private void handleSignInResult(Task<GoogleSignInAccount> completedTask) {
        try {
            GoogleSignInAccount account = completedTask.getResult(ApiException.class);
            if (account == null) {
                return;
            }
            Shopper shopper = new Shopper();
            //shopper.setBirthdate("NOT SET");
            shopper.setEmail(account.getEmail());
            shopper.setGender("NOT SET");
            shopper.setName(account.getDisplayName());
            shopper.setPicture(account.getPhotoUrl() == null ? "image" : account.getPhotoUrl().toString());

            String shopperString = new Gson().toJson(shopper);

            Log.e("error", new Gson().toJson(shopper));

            attemptSignIn(shopperString, GOOGLE);

        } catch (ApiException | NullPointerException e) {
            e.printStackTrace();
        }
    }

    private void getUserDetails(LoginResult loginResult) {
        GraphRequest request = GraphRequest.newMeRequest(loginResult.getAccessToken(),
                new GraphRequest.GraphJSONObjectCallback() {
                    @Override
                    public void onCompleted(JSONObject object, GraphResponse response) {
                        Log.e("LoginActivity", response.toString());
                        try {
                            String id = object.get("id").toString();
                            String email = object.get("email").toString();
                            String name = object.get("name").toString();
                            String gender = object.get("gender").toString();
                            //String birthday = object.get("birthday").toString();
                            String picUrl = String.format("https://graph.facebook.com/%s/picture?type=large", id);
                            Shopper shopper = new Shopper();
                            //shopper.setBirthdate(birthday);
                            shopper.setEmail(email);
                            shopper.setGender(gender);
                            shopper.setName(name);
                            shopper.setPicture(picUrl);

                            String shopperString = new Gson().toJson(shopper);
                            attemptSignIn(shopperString, GOOGLE);

                        } catch (Exception ignored) {
                        }
                    }
                });

        Bundle parameters = new Bundle();
        parameters.putString("fields", "id,name,email,gender");
        request.setParameters(parameters);
        request.executeAsync();
    }

    private void attemptSignIn(String userJson, final String method) {

        Call<Shopper> call = RetrofitSetup.retrofitInterface.login(userJson, method);
        final ProgressDialog progressDialog = new ProgressDialog(this);
        progressDialog.setIndeterminate(true);
        progressDialog.setMessage("Authenticating...");
        progressDialog.show();
        call.enqueue(new Callback<Shopper>() {
            @Override
            public void onResponse(Call<Shopper> call, retrofit2.Response<Shopper> response) {
                progressDialog.dismiss();
                if (response.isSuccessful()) {
                    Shopper shopper = response.body();
                    CbSession session = new CbSession(ShopperLogin.this);
                    session.setSignInMethod(method);

                    if (shopper.getStatus() != 200) {
                        Toast toast = Toast.makeText(ShopperLogin.this, "Authentication failed!", Toast.LENGTH_SHORT);
                        toast.setGravity(Gravity.CENTER, 0, 0);
                        toast.show();
                        return;
                    }

                    session.setShopper(shopper);

//                    switch (method) {
//                        case GOOGLE:
//                            session.setBusiness(null);
//                            session.setAgent(null);
//                            break;
//                        case FACEBOOK:
//                            session.setBusiness(null);
//                            session.setAgent(null);
//                            break;
//                        case EMAIL:
//                            session.setBusiness(null);
//                            session.setAgent(null);
//                            session.setSignInMethod(EMAIL);
//                            break;
//                    }

                    startActivity(new Intent(ShopperLogin.this, Main3Activity.class));
                    finish();
                } else {
                    Toast toast = Toast.makeText(ShopperLogin.this, "Try again later!", Toast.LENGTH_SHORT);
                    toast.setGravity(Gravity.CENTER, 0, 0);
                    toast.show();
                }
            }

            @Override
            public void onFailure(Call<Shopper> call, Throwable t) {
                t.printStackTrace();
            }
        });
    }
}

