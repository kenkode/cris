package ke.co.prioritymobile.chapabiz.activities;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;

import com.github.paolorotolo.appintro.AppIntro;

import ke.co.prioritymobile.chapabiz.helpers.CbSession;

public class SplashScreen extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        CbSession session = new CbSession(this);
        if(session.isFirstTimeIntro()) {

            startActivity(new Intent(SplashScreen.this, WelcomeActivity.class));
        }else {
            startActivity(new Intent(SplashScreen.this, ShopperLogin.class));
       }

        finish();
    }
}
