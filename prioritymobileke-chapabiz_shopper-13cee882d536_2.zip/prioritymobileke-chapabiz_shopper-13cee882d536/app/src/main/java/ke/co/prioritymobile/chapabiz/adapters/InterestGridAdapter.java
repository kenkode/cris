package ke.co.prioritymobile.chapabiz.adapters;

import android.content.Context;
import android.support.design.widget.Snackbar;
import android.support.v4.content.ContextCompat;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import com.makeramen.roundedimageview.RoundedImageView;
import com.squareup.picasso.Picasso;

import java.util.ArrayList;

import ke.co.prioritymobile.chapabiz.R;
import ke.co.prioritymobile.chapabiz.helpers.CbSession;
import ke.co.prioritymobile.chapabiz.retrofit.RetrofitSetup;
import ke.co.prioritymobile.chapabiz.shopper.entities.InterestDetail;
import ke.co.prioritymobile.chapabiz.shopper.entities.ShopperFav;
import okhttp3.ResponseBody;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class InterestGridAdapter extends BaseAdapter {

    private Context context;
    private ArrayList<InterestDetail> interests;
    private CbSession session;

    public InterestGridAdapter(Context context, ArrayList<InterestDetail> interests) {
        this.context = context;
        this.interests = interests;
        session = new CbSession(context);
    }

    private void updateBackground(int state, Button button) {
        if (state == 1) {
            button.setText("x");
            button.setBackground(ContextCompat.getDrawable(context, R.drawable.interest_button_selected));
            button.setTextColor(ContextCompat.getColor(context, android.R.color.white));
        } else {
            button.setText("+");
            button.setBackground(ContextCompat.getDrawable(context, R.drawable.interest_button_deselected));
            button.setTextColor(ContextCompat.getColor(context, android.R.color.white));
        }
    }

    @Override
    public int getCount() {
        return interests.size();
    }

    @Override
    public Object getItem(int i) {
        return null;
    }

    @Override
    public long getItemId(int i) {
        return 0;
    }

    @Override
    public View getView(int i, View convertView, ViewGroup viewGroup) {
        final InterestDetail interestDetail = interests.get(i);


        if (convertView == null) {
            final LayoutInflater layoutInflater = LayoutInflater.from(context);
            convertView = layoutInflater.inflate(R.layout.shopper_fav_detail, null);

        }

        final TextView name = convertView.findViewById(R.id.name);
        final RoundedImageView imageView = convertView.findViewById(R.id.image);
        final Button button = convertView.findViewById(R.id.select);

//        name.setText(interestDetail.getName());
        //holder.imageView.set

        if (interestDetail.isSelected()) {
            button.setText("X");
            button.setBackground(ContextCompat.getDrawable(context, R.drawable.interest_button_selected));
            button.setTextColor(ContextCompat.getColor(context, android.R.color.white));
        }

        updateBackground(interestDetail.isSelected() ? 1 : 0, button);

        String photoUrl = interestDetail.getPhoto();
        if(photoUrl == null) {
            photoUrl = "image";
        }

        Picasso.with(context).load(photoUrl)
                .placeholder(ContextCompat.getDrawable(context, R.drawable.ic_image_holder))
                .into(imageView);

        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                interestDetail.setSelected(!interestDetail.isSelected());

                int state;

                if (interestDetail.isSelected()) {
                    state = 1;
                    Snackbar snackbar = Snackbar.make(name, String.format("%s added to favorites", interestDetail.getName()), Snackbar.LENGTH_LONG);
                    snackbar.show();
                } else {
                    state = 0;
                }

                sendUpdate(Integer.parseInt(interestDetail.getId()), state, button);
            }
        });

        return convertView;
    }


    private void sendUpdate(int id, final int state, final Button button) {
        Call<ResponseBody> bodyCall = RetrofitSetup.retrofitInterface.updateInterest(session.getShopper().getId(), id, state);
        bodyCall.enqueue(new Callback<ResponseBody>() {
            @Override
            public void onResponse(Call<ResponseBody> call, Response<ResponseBody> response) {
                if (response.isSuccessful()) {
                    updateBackground(state, button);
                } else {
                    Toast.makeText(context, "UnSuccessful", Toast.LENGTH_SHORT).show();
                }
            }

            @Override
            public void onFailure(Call<ResponseBody> call, Throwable t) {
                Toast.makeText(context, "UnSuccessful", Toast.LENGTH_SHORT).show();
            }
        });
    }

}
