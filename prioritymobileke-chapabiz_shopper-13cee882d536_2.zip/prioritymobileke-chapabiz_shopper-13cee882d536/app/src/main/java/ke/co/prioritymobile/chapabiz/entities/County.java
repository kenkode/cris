package ke.co.prioritymobile.chapabiz.entities;

import com.google.gson.annotations.SerializedName;

public class County {

    private String id;
    @SerializedName("name")
    private String countyName;

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getCountyName() {
        return countyName;
    }

    public void setCountyName(String countyName) {
        this.countyName = countyName;
    }
}
