package ke.co.prioritymobile.chapabiz.entities;

import ke.co.prioritymobile.chapabiz.shopper.entities.Business;
import ke.co.prioritymobile.chapabiz.shopper.entities.Shopper;

public class Response {

    private int status;
    private String message;
    private Business business;
    private Shopper shopper;

    public Business getBusiness() {
        return business;
    }

    public Shopper getShopper() {
        return shopper;
    }

    public void setBusiness(Business business) {
        this.business = business;
    }

    public int getStatus() {
        return status;
    }

    public void setStatus(int status) {
        this.status = status;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }
}
