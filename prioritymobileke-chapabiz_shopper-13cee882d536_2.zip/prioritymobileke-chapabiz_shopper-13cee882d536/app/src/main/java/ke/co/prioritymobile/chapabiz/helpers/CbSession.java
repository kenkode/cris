package ke.co.prioritymobile.chapabiz.helpers;

import android.content.Context;
import android.content.SharedPreferences;

import com.google.gson.Gson;

//import ke.co.prioritymobile.chapabiz.agent.Agent;
import ke.co.prioritymobile.chapabiz.shopper.entities.Business;
import ke.co.prioritymobile.chapabiz.entities.User;
import ke.co.prioritymobile.chapabiz.shopper.entities.Shopper;

public class CbSession {

    private final String SHARED_PREFS = "shared_prefs";
    private final String SHOPPER = "shopper";
    private final String BUSINESS = "business";
    private final String AGENT = "agent";
    private final String LAST_SELECTED = "last_selected";
    private final String SIGN_IN_METHOD = "sign_in_method";

    public static final String FACEBOOK = "facebook";
    public static final String FACEBOOK_TOKEN = "facebook_token";
    public static final String EMAIL = "email";
    public static final String GOOGLE = "google";

    private static final String KEY_USER_ID = "user_id";
    private static final String KEY_USER_NAME = "user_name";
    private static final String KEY_USER_EMAIL = "user_email";

    private static final String KEY_NOTIFICATIONS = "notifications";
    private static final String APP_INTRO = "app_intro";

    private SharedPreferences sharedPreferences;
    private Context context;

    public CbSession(Context context) {
        this.context = context;
        sharedPreferences = context.getSharedPreferences(SHARED_PREFS, Context.MODE_PRIVATE);
    }

    public void addNotification(String notification) {
        SharedPreferences.Editor editor = sharedPreferences.edit();
        // get old notifications
        String oldNotifications = getNotifications();

        if (oldNotifications != null) {
            oldNotifications += "|" + notification;
        } else {
            oldNotifications = notification;
        }

        editor.putString(KEY_NOTIFICATIONS, oldNotifications);
        editor.apply();
    }

    public String getNotifications() {
        return sharedPreferences.getString(KEY_NOTIFICATIONS, null);
    }

    public void storeUser(User user) {
        SharedPreferences.Editor editor = sharedPreferences.edit();
        editor.putString(KEY_USER_ID, user.getId());
        editor.putString(KEY_USER_NAME, user.getName());
        editor.putString(KEY_USER_EMAIL, user.getEmail());
        editor.apply();
    }

    public User getUser() {
        if (sharedPreferences.getString(KEY_USER_ID, null) != null) {
            String id, name, email;
            id = sharedPreferences.getString(KEY_USER_ID, null);
            name = sharedPreferences.getString(KEY_USER_NAME, null);
            email = sharedPreferences.getString(KEY_USER_EMAIL, null);

            return new User(id, name, email);
        }
        return null;
    }

    public void clear() {
        SharedPreferences.Editor editor = sharedPreferences.edit();
        editor.clear();
        editor.apply();
        setFirstTimeIntro(false);
    }

    public void setSignInMethod(String signInMethod) {
        SharedPreferences.Editor editor = sharedPreferences.edit();
        editor.putString(SIGN_IN_METHOD, signInMethod);
        editor.apply();
    }

    public String getSignInMethod() {
        return sharedPreferences.getString(SIGN_IN_METHOD, "");
    }

    public void setFirstTimeIntro(boolean firstTimeIntro) {
        SharedPreferences.Editor editor = sharedPreferences.edit();
        editor.putBoolean(APP_INTRO, firstTimeIntro);
        editor.apply();
    }

    public boolean isFirstTimeIntro() {
        return sharedPreferences.getBoolean(APP_INTRO, true);
    }

    public void setFacebookToken(String facebookToken) {
        SharedPreferences.Editor editor = sharedPreferences.edit();
        editor.putString(FACEBOOK_TOKEN, facebookToken);
        editor.apply();
    }

    public String getFacebookToken() {
        return sharedPreferences.getString(FACEBOOK_TOKEN, "");
    }

    public void setBusiness(Business business) {
        SharedPreferences.Editor editor = sharedPreferences.edit();
        editor.putString(BUSINESS, new Gson().toJson(business));
        editor.apply();
    }

    public Business getBusiness() {
        String businessString = sharedPreferences.getString(BUSINESS, "");
        return new Gson().fromJson(businessString, Business.class);
    }

    public void setShopper(Shopper shopper) {
        SharedPreferences.Editor editor = sharedPreferences.edit();
        editor.putString(SHOPPER, new Gson().toJson(shopper));
        editor.apply();
    }

    public Shopper getShopper() {
        String shopperString = sharedPreferences.getString(SHOPPER, "");
        return new Gson().fromJson(shopperString, Shopper.class);
    }

//    public void setAgent(Agent agent) {
//        SharedPreferences.Editor editor = sharedPreferences.edit();
//        editor.putString(AGENT, new Gson().toJson(agent));
//        editor.apply();
//    }
//
//    public Agent getAgent() {
//        String shopperString = sharedPreferences.getString(AGENT, "");
//        return new Gson().fromJson(shopperString, Agent.class);
//    }

    public void setLastSelected(String selected) {
        SharedPreferences.Editor editor = sharedPreferences.edit();
        editor.putString(LAST_SELECTED, selected);
        editor.apply();
    }

    public String getLastSelected() {
        return sharedPreferences.getString(LAST_SELECTED, "");
    }


}
