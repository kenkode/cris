package ke.co.prioritymobile.chapabiz.helpers;

/**
 * Created by Millie Agallo on 5/24/2018.
 */


import android.content.Context;
import android.content.SharedPreferences;
import android.util.Log;

import java.util.HashMap;
import java.util.Map;

public class GEPreference {

    public static final String USER_EMAIL = "user_email";
    private final SharedPreferences sharedPreferences;
    private final SharedPreferences.Editor editor;
    private static final String PREFERENCES = "ge_prefs";
    private static final String SPLASH_SHOWN = "splash_shown";
    public static final String USER_ID = "user_id";
    public static final String USER_PHONE= "user_phone";
    public static final String USER_IDNO= "user_idno";
    public static final String USER_GENDER= "user_gender";
    private static final String USER_LOGGED = "user_logged";
    public static final String USER_NAME = "user_name";
    public static final String USER_SALARY = "user_salary";
    public static final String USER_AGE = "user_age";
    public static final String USER_POSITION = "user_position";
    public static final String USER_ADDRESS = "user_address";
    public static final String USER_COUNTY = "user_county";
    public static final String USER_COMPANY = "user_company";
    public static final String USER_BRANCH = "user_branch";
    public static final String USER_PHOTO = "user_photo";
    public static final String USER_BALANCE = "user_balance";
    public static final String CURRENT_LOAN = "current_loan";
    public static final String USER_DOB = "user_dob";
    public static final String USER_EDATE = "user_edate";
    public static final String USER_PNO = "user_pno";
    public static final String USER_RESIDENCE = "user_residence";
    public static final String USER_KRA = "user_kra";
    public static final String USER_KIN = "user_kin";
    public static final String USER_KIN_PHONE = "user_kin_phone";
    public static final String DUE_DATE = "due_date";

    private static final String PAYMENT_OPTION = "payment_option";
    private static final String TOKEN = "token";

    public GEPreference(Context context) {
        sharedPreferences = context.getSharedPreferences(PREFERENCES, Context.MODE_PRIVATE);

        editor = sharedPreferences.edit();
    }

    public void setPaymentOption(String paymentOption) {
        editor.putString(PAYMENT_OPTION, paymentOption);
        editor.apply();
    }

    public String getPaymentOption() {
        return sharedPreferences.getString(PAYMENT_OPTION, "");
    }

    public void setToken(String token) {
        editor.putString(TOKEN, token);
        editor.apply();
    }

    public String getToken() {
        return sharedPreferences.getString(TOKEN, "");
    }

    // User preference
    public void setUser(String id, String full_name, String phone_number, String email, String id_number, String gender, String salary,
                        String age, String position, String address, String county, String company, String branch, String selfie, String balance,
                        String due_date, String current_loan, String dob, String edate, String pno, String residence, String kra,
                        String kin, String kinphone) {
        editor.putString(USER_ID, id);
        editor.putString(USER_NAME, full_name);
        editor.putString(USER_PHONE, phone_number);
        editor.putString(USER_EMAIL, email);
        editor.putString(USER_IDNO, id_number);
        editor.putString(USER_GENDER, gender);
        editor.putString(USER_SALARY, salary);
        editor.putString(USER_AGE, age);
        editor.putString(USER_POSITION, position);
        editor.putString(USER_ADDRESS, address);
        editor.putString(USER_COUNTY, county);
        editor.putString(USER_COMPANY, company);
        editor.putString(USER_BRANCH, branch);
        editor.putString(USER_PHOTO, selfie);
        editor.putString(USER_BALANCE, balance);
        editor.putString(DUE_DATE, due_date);
        editor.putString(CURRENT_LOAN, current_loan);
        editor.putString(USER_DOB, dob);
        editor.putString(USER_EDATE, edate);
        editor.putString(USER_PNO, pno);
        editor.putString(USER_RESIDENCE, residence);
        editor.putString(USER_KRA, kra);
        editor.putString(USER_KIN, kin);
        editor.putString(USER_KIN_PHONE, kinphone);
        editor.putBoolean(USER_LOGGED, true);
        Log.d(USER_ID, id);
        Log.d("ASS", "ASS");
        editor.apply();
    }

    public void unsetUser() {
        editor.clear();
        editor.apply();
    }

    public Map<String, String> getUser() {
        Map<String, String> user = new HashMap<>();
        user.put(USER_ID, sharedPreferences.getString(USER_ID, ""));
        user.put(USER_NAME, sharedPreferences.getString(USER_NAME, ""));
        user.put(USER_PHONE, sharedPreferences.getString(USER_PHONE, ""));
        user.put(USER_EMAIL, sharedPreferences.getString(USER_EMAIL, ""));
        user.put(USER_IDNO, sharedPreferences.getString(USER_IDNO, ""));
        user.put(USER_GENDER, sharedPreferences.getString(USER_GENDER, ""));
        user.put(USER_SALARY, sharedPreferences.getString(USER_SALARY, ""));
        user.put(USER_AGE, sharedPreferences.getString(USER_AGE, ""));
        user.put(USER_POSITION, sharedPreferences.getString(USER_POSITION, ""));
        user.put(USER_ADDRESS, sharedPreferences.getString(USER_ADDRESS, ""));
        user.put(USER_COUNTY, sharedPreferences.getString(USER_COUNTY, ""));
        user.put(USER_COMPANY, sharedPreferences.getString(USER_COMPANY, ""));
        user.put(USER_BRANCH, sharedPreferences.getString(USER_BRANCH, ""));
        user.put(USER_PHOTO, sharedPreferences.getString(USER_PHOTO, ""));
        user.put(USER_BALANCE, sharedPreferences.getString(USER_BALANCE, ""));
        user.put(DUE_DATE, sharedPreferences.getString(DUE_DATE, ""));
        user.put(CURRENT_LOAN, sharedPreferences.getString(CURRENT_LOAN, ""));
        user.put(USER_DOB, sharedPreferences.getString(USER_DOB, ""));
        user.put(USER_EDATE, sharedPreferences.getString(USER_EDATE, ""));
        user.put(USER_PNO, sharedPreferences.getString(USER_PNO, ""));
        user.put(USER_RESIDENCE, sharedPreferences.getString(USER_RESIDENCE, ""));
        user.put(USER_KRA, sharedPreferences.getString(USER_KRA, ""));
        user.put(USER_KIN, sharedPreferences.getString(USER_KIN, ""));
        user.put(USER_KIN_PHONE, sharedPreferences.getString(USER_KIN_PHONE, ""));
        return user;
    }



    public boolean isUserLogged() {
        return sharedPreferences.getBoolean(USER_LOGGED, false);
    }
}
