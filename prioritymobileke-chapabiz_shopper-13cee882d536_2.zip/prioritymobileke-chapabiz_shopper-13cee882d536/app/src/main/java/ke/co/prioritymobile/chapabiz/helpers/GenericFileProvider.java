package ke.co.prioritymobile.chapabiz.helpers;

import android.support.v4.content.FileProvider;

public class GenericFileProvider extends FileProvider {}