//package ke.co.prioritymobile.chapabiz.helpers;
//
//import android.content.Context;
//import android.os.AsyncTask;
//import android.os.Bundle;
//import android.support.v4.app.FragmentManager;
//import android.support.v4.app.FragmentTransaction;
//import android.util.Log;
//import android.view.View;
//import android.widget.ImageView;
//import android.widget.ProgressBar;
//import android.widget.TextView;
//import android.widget.Toast;
//
//import com.makeramen.roundedimageview.RoundedImageView;
//import com.squareup.picasso.Picasso;
//
//import org.apache.http.HttpEntity;
//import org.apache.http.HttpResponse;
//import org.apache.http.client.ClientProtocolException;
//import org.apache.http.client.HttpClient;
//import org.apache.http.client.methods.HttpPost;
//import org.apache.http.entity.mime.content.FileBody;
//import org.apache.http.entity.mime.content.StringBody;
//import org.apache.http.impl.client.DefaultHttpClient;
//import org.apache.http.util.EntityUtils;
//import org.apache.http.util.TextUtils;
//
//import java.io.File;
//import java.io.IOException;
//
//import ke.co.prioritymobile.chapabiz.R;
////import ke.co.prioritymobile.chapabiz.agent.activities.AgentActivity;
//import ke.co.prioritymobile.chapabiz.shopper.entities.Business;
//import ke.co.prioritymobile.chapabiz.shopper.fragments.PhotoFragment;
//
//import static ke.co.prioritymobile.chapabiz.retrofit.EndPoint.UPLOAD_FILE;
//
//public class UploadFile extends AsyncTask<Void, Integer, String> {
//
//    private ProgressBar progressBar;
//    private TextView progressText;
//    private String businessId;
//    private static float totalSize = 0;
//    private File file;
//    private int type;
//    private ImageView imageView;
//    private RoundedImageView roundedImageView;
//    private Context context;
//    private FragmentManager fragmentManager;
//
//
//    public UploadFile(Context context, int type, TextView progressText, ProgressBar progressBar, String businessId, File file) {
//        this.progressBar = progressBar;
//        this.progressText = progressText;
//
//        if (progressText != null) {
//            this.progressText.setVisibility(View.VISIBLE);
//        }
//        this.progressBar.setVisibility(View.VISIBLE);
//        this.businessId = businessId;
//        this.file = file;
//        this.type = type;
//        this.context = context;
//    }
//
//    public void setImage(ImageView imageView) {
//        this.imageView = imageView;
//    }
//
//    public void setRoundedImageView(RoundedImageView roundedImageView) {
//        this.roundedImageView = roundedImageView;
//    }
//
//    public void setFragment(FragmentManager fragmentManager) {
//        this.fragmentManager = fragmentManager;
//    }
//
//    @Override
//    protected void onPreExecute() {
//        // setting progress bar to zero
//        progressBar.setProgress(0);
//        super.onPreExecute();
//    }
//
//    @Override
//    protected void onProgressUpdate(Integer... progress) {
//        // Making progress bar visible
//        progressBar.setVisibility(View.VISIBLE);
//
//        // updating progress bar value
//        progressBar.setProgress(progress[0]);
//
//        // updating percentage value
//        if (progressText != null && imageView == null) {
//            progressText.setText(String.format("%s%s", progress[0], "%"));
//            if (progress[0] == 100) {
//                progressText.setText("Finalizing...");
//            }
//        }
//    }
//
//    @Override
//    protected String doInBackground(Void... params) {
//        return uploadFile(file);
//    }
//
//    @SuppressWarnings("deprecation")
//    private String uploadFile(File file) {
//        String responseString = null;
//
//        HttpClient httpclient = new DefaultHttpClient();
//        HttpPost httppost = new HttpPost(UPLOAD_FILE);
//
//        try {
//            AndroidMultiPartEntity entity = new AndroidMultiPartEntity(
//                    new AndroidMultiPartEntity.ProgressListener() {
//
//                        @Override
//                        public void transferred(long num) {
//                            publishProgress((int) ((num / (float) totalSize) * 100));
//                        }
//                    });
//
//            // Adding file data to http body
//            entity.addPart("file", new FileBody(file));
//
//            // Extra parameters if you want to pass to server
//            entity.addPart("business",
//                    new StringBody(businessId));
//            entity.addPart("name",
//                    new StringBody(file.getName()));
//            entity.addPart("type",
//                    new StringBody(String.valueOf(type)));
//            Log.e("values",file.getName()+file+type);
//            totalSize = entity.getContentLength();
//            httppost.setEntity(entity);
//
//            // Making server call
//            HttpResponse response = httpclient.execute(httppost);
//            HttpEntity r_entity = response.getEntity();
//
//            int statusCode = response.getStatusLine().getStatusCode();
//            if (statusCode == 200) {
//                responseString = EntityUtils.toString(r_entity);
//
//            } else {
//                responseString = "Error occurred";
//            }
//
//        } catch (ClientProtocolException e) {
//            responseString = e.toString();
//        } catch (IOException e) {
//            responseString = e.toString();
//        }
//
//        return responseString;
//
//    }
//
//    @Override
//    protected void onPostExecute(String result) {
//        progressBar.setVisibility(View.GONE);
//        CbSession session = new CbSession(context);
//        Business business = session.getBusiness();
//        switch (type) {
//            case 0:
//                this.progressBar.setVisibility(View.GONE);
//                Toast.makeText(context, "Finished uploading", Toast.LENGTH_SHORT).show();
//                Picasso.with(context).load(result).into(roundedImageView);
//                business.setImage(result);
//                break;
//            case 22:
//                business.setCertificateNo(result);
//                progressText.setText(result);
//                break;
//            case 25:
//                business.setCertificateNo(result);
//                PhotoFragment photoFragment = new PhotoFragment();
//                Bundle bundle = new Bundle();
//                bundle.putString("business", this.businessId);
//                photoFragment.setArguments(bundle);
//
//                FragmentTransaction profFrag = fragmentManager.beginTransaction();
//                if(session.getAgent() == null) {
//                    profFrag.replace(R.id.business_image, photoFragment);
//                }else {
//                    profFrag.replace(R.id.business_image, photoFragment);
//                }
//                profFrag.setTransition(FragmentTransaction.TRANSIT_FRAGMENT_FADE);
//                profFrag.commit();
//                break;
//            case 2:
////                if (image.isEmpty()) {
////                    iview.setImageResource(R.drawable.placeholder);
////                } else{
////                    Picasso.with(_c).load(image).into(iview);
////                }
//               // if()
//                Toast.makeText(context, "Finished uploading", Toast.LENGTH_SHORT).show();
//                Picasso.with(context).load(result).into(imageView);
//                business.setImage(result);
//                break;
//            case 11:
//                if (!TextUtils.isEmpty(result)) {
//                    new CbSession(context).getAgent().setPicture(result);
//                    Picasso.with(context).load(result).into(roundedImageView);
//                }
//
//                break;
//        }
//        session.setBusiness(business);
//        super.onPostExecute(result);
//    }
//}