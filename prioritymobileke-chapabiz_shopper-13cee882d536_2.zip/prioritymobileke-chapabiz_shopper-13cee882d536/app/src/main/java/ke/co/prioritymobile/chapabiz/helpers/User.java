package ke.co.prioritymobile.chapabiz.helpers;

/**
 * Created by Millie Agallo on 5/24/2018.
 */

import com.google.gson.annotations.Expose;

public class User {

    @Expose
    private String id;
    @Expose
    private String full_name;
    @Expose
    private String email;
   @Expose
   private String phone_number;

    public User(String full_name, String email, String phone_number) {
        this.full_name       = full_name;
        this.email           = email;
        this.phone_number    = phone_number;

    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getFull_name() {
        return full_name;
    }

    public void setFull_name(String full_name) {
        this.full_name = full_name;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }



    public String getPhone_number() {
        return phone_number;
    }

    public void setPhone_number(String phone_number) {
        this.phone_number = phone_number;
    }



}
