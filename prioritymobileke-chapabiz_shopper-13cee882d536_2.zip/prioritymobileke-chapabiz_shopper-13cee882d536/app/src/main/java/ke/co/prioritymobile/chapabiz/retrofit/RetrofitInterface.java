package ke.co.prioritymobile.chapabiz.retrofit;

import java.util.ArrayList;

import ke.co.prioritymobile.chapabiz.adapters.FavGridAdapter;
import ke.co.prioritymobile.chapabiz.shopper.entities.Business;
import ke.co.prioritymobile.chapabiz.entities.ChatRoom;
import ke.co.prioritymobile.chapabiz.entities.County;
import ke.co.prioritymobile.chapabiz.entities.Message;
import ke.co.prioritymobile.chapabiz.entities.Photo;
import ke.co.prioritymobile.chapabiz.entities.Response;
import ke.co.prioritymobile.chapabiz.entities.User;
import ke.co.prioritymobile.chapabiz.shopper.entities.BusinessDets;
import ke.co.prioritymobile.chapabiz.shopper.entities.Interest;
import ke.co.prioritymobile.chapabiz.shopper.entities.InterestDetail;
import ke.co.prioritymobile.chapabiz.shopper.entities.InterestMarker;
import ke.co.prioritymobile.chapabiz.shopper.entities.Shopper;
import ke.co.prioritymobile.chapabiz.shopper.entities.ShopperFav;
import ke.co.prioritymobile.chapabiz.shopper.entities.SubCategoryDetail;
import okhttp3.MultipartBody;
import okhttp3.RequestBody;
import okhttp3.ResponseBody;
import retrofit2.Call;
import retrofit2.http.Field;
import retrofit2.http.FormUrlEncoded;
import retrofit2.http.Multipart;
import retrofit2.http.POST;
import retrofit2.http.Part;

public interface RetrofitInterface {
//Shared

    @FormUrlEncoded
    @POST(EndPoint.CHAT_ROOMS)
    Call<ArrayList<ChatRoom>> getChatRooms(@Field("user") String user);

    @FormUrlEncoded
    @POST(EndPoint.ADD_CHAT)
    Call<ResponseBody> addChat(@Field("user") String user, @Field("rec") String rec);

    @FormUrlEncoded
    @POST(EndPoint.SEND_TOKEN)
    Call<ResponseBody> sendToken(@Field("user") String user, @Field("gcm") String gcm, @Field("email") String email);

    @FormUrlEncoded
    @POST(EndPoint.UPDATE_TOKEN)
    Call<ResponseBody> updateToken(@Field("user") String user, @Field("gcm") String gcm);

    @FormUrlEncoded
    @POST(EndPoint.SEND_MESSAGE)
    Call<ResponseBody> sendMessage(@Field("user") String user, @Field("room") String room, @Field("message") String message);

    @FormUrlEncoded
    @POST(EndPoint.GET_MESSAGES)
    Call<ArrayList<Message>> getMessages(@Field("room") String room, @Field("user") String user);

//    Business

    @FormUrlEncoded
    @POST(EndPoint.SIGN_IN_BUSINESS)
    Call<Response> signInBusiness(@Field("phone") String phone, @Field("pin") String pin);

    @FormUrlEncoded
    @POST(EndPoint.SIGN_UP_BUSINESS)
    Call<Response> signUpBusiness(@Field("business") String business);

    //new user
    @FormUrlEncoded
    @POST(EndPoint.SIGN_UP_NEWSHOPPER)
    Call<Response> signUpNewUser(@Field("shopper") String shopper);

    @POST(EndPoint.GET_COUNTIES)
    Call<ArrayList<County>> getCounties();

    @FormUrlEncoded
    @POST(EndPoint.UPDATE_BUSINESS)
    Call<ResponseBody> updateBusiness(@Field("id") String id, @Field("business") String business);

    @FormUrlEncoded
    @POST(EndPoint.GET_PHOTOS)
    Call<ArrayList<Photo>> getPhotos(@Field("id") String id);

    @FormUrlEncoded
    @POST(EndPoint.DELETE_PHOTO)
    Call<ResponseBody> deletePhoto(@Field("id") String id);
//    Agent

//    @FormUrlEncoded
//    @POST(EndPoint.AGENT_SUMMARY)
//    Call<Summary> agentSummary(@Field("id") String id);
//
//    @FormUrlEncoded
//    @POST(EndPoint.SIGN_IN_AGENT)
//    Call<Agent> signInAgent(@Field("phone") String phone, @Field("pin") String pin);
//
//    @FormUrlEncoded
//    @POST(EndPoint.UPDATE_AGENT)
//    Call<Agent> updateAgent(@Field("agent") String agent, @Field("details") String details);
    //NEW_USER_AC

    @FormUrlEncoded
    @POST(EndPoint.AGENT_BUSINESSES)
    Call<ArrayList<Business>> getAgentBusinesses(@Field("agent") String agent);

    @FormUrlEncoded
    @POST(EndPoint.ACTUAL_AGENT_BUSINESSES)
    Call<ArrayList<Business>>getAgentRegBusinesses(@Field("id") String id);

    @FormUrlEncoded
    @POST(EndPoint.AGENT_COMMISSIONS_ALL)
    Call<ArrayList<Business>>getAgentCommissionsAll(@Field("id") String id);

    @FormUrlEncoded
    @POST(EndPoint.AGENT_COMMISSIONS_YEAR)
    Call<ArrayList<Business>>getAgentCommissionsYear(@Field("id") String id);

    @FormUrlEncoded
    @POST(EndPoint.AGENT_COMMISSIONS_MONTH)
    Call<ArrayList<Business>>getAgentCommissionsMonth(@Field("id") String id);


    @FormUrlEncoded
    @POST(EndPoint.AGENT_COMMISSIONS_WEEK)
    Call<ArrayList<Business>>getAgentCommissionsWeek(@Field("id") String id);

    @FormUrlEncoded
    @POST(EndPoint.AGENT_COMMISSIONS_DAY)
    Call<ArrayList<Business>>getAgentCommissionsDay(@Field("id") String id);

    //    Shopper
    @FormUrlEncoded
    @POST(EndPoint.SIGN_IN_SHOPPER)
    Call<Shopper> login(@Field("shopper") String shopper, @Field("method") String method);


    @FormUrlEncoded
    @POST(EndPoint.CATEGORIES)
    Call<ArrayList<InterestDetail>> getCategories(@Field("id") String id);

    //test business favs
    @FormUrlEncoded
    @POST(EndPoint.ALL_CHAPA_BIZS)
    Call<ArrayList<BusinessDets>> getCategoriestest(@Field("id") String id);

    @POST(EndPoint.SUB_CATEGORIES)
    Call<ArrayList<InterestDetail>> getSubCategories();

    //test
    @POST(EndPoint.SUB_CATEGORIES1)
    Call<ArrayList<ShopperFav>> gettest();
    //new sub categories
    @POST(EndPoint.SUB_CATEGORIES1)
    Call<ArrayList<Business>> getSubCategories1();

    @POST(EndPoint.SUB_CATEGORIES2)
    Call<ArrayList<Business>> getSubCategories2();

    @POST(EndPoint.SUB_CATEGORIES3)
    Call<ArrayList<Business>> getSubCategories3();

    @POST(EndPoint.SUB_CATEGORIES4)
    Call<ArrayList<Business>> getSubCategories4();

    @POST(EndPoint.SUB_CATEGORIES5)
    Call<ArrayList<Business>> getSubCategories5();

    @POST(EndPoint.SUB_CATEGORIES6)
    Call<ArrayList<Business>> getSubCategories6();

    @POST(EndPoint.SUB_CATEGORIES7)
    Call<ArrayList<Business>> getSubCategories7();

    @POST(EndPoint.SUB_CATEGORIES8)
    Call<ArrayList<Business>> getSubCategories8();

    @POST(EndPoint.SUB_CATEGORIES9)
    Call<ArrayList<Business>> getSubCategories9();


    @FormUrlEncoded
    @POST(EndPoint.INTERESTS)
    Call<ArrayList<InterestDetail>> getInterests(@Field("id") String id);


    @FormUrlEncoded
    @POST(EndPoint.INTERESTS_s)
    Call<ArrayList<BusinessDets>> getFavperShopper(@Field("id") String id);

    @FormUrlEncoded
    @POST(EndPoint.FAVORITES)
    Call<ArrayList<ShopperFav>> getShopperBiz(@Field("id") String id);

    @FormUrlEncoded
    @POST(EndPoint.ALL_BIZ)
    Call<ArrayList<SubCategoryDetail>> getAllBiz();



    @FormUrlEncoded
    @POST(EndPoint.UPDATE_INTEREST)
    Call<ResponseBody> updateInterest(@Field("id") String id, @Field("interest") int interest, @Field("state") int state);

    @FormUrlEncoded
    @POST(EndPoint.UPDATE_INTEREST_s)
    Call<ResponseBody> updateInterest_s(@Field("id") String id, @Field("interest") int interest, @Field("state") int state);

    @FormUrlEncoded
    @POST(EndPoint.GET_BUSINESSES)
    Call<ArrayList<Business>> getBusinesses(@Field("interest") int interest);

    @FormUrlEncoded
    @POST(EndPoint.UPDATE_BUSINESS_PER_SHOPPER)
    Call<ResponseBody> updateStatus(@Field("id") String id, @Field("state") int state);

}
