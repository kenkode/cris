package ke.co.prioritymobile.chapabiz.retrofit;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;

import okhttp3.OkHttpClient;
import okhttp3.logging.HttpLoggingInterceptor;
import retrofit2.Retrofit;
import retrofit2.converter.gson.GsonConverterFactory;

public class RetrofitSetup {

    public static Gson gson = new GsonBuilder().setLenient().create();

    private static HttpLoggingInterceptor interceptor = new HttpLoggingInterceptor();

    public static Retrofit retrofit = new Retrofit.Builder()
            .baseUrl(EndPoint.BASE_URL)
            .client(getClient())
            .addConverterFactory(GsonConverterFactory.create(gson))
            .build();

    public static final RetrofitInterface retrofitInterface = RetrofitSetup.retrofit.create(RetrofitInterface.class);

    private static OkHttpClient getClient() {
        interceptor.setLevel(HttpLoggingInterceptor.Level.BODY);
        OkHttpClient client = new OkHttpClient.Builder().addInterceptor(interceptor).build();
        return client;
    }

}