package ke.co.prioritymobile.chapabiz.shopper.activities;

import android.support.v4.content.ContextCompat;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;

import com.squareup.picasso.Picasso;

import ke.co.prioritymobile.chapabiz.R;

public class BusinessDetailsActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_business_details);

        ImageView imageView = findViewById(R.id.image);
        Picasso.with(this).load("http://www.bordermediagroup.com/wp-content/uploads/2015/07/Mpesa-640x383.png")
                .placeholder(ContextCompat.getDrawable(this, R.drawable.ic_chapabiz_logo_vert))
                .into(imageView);
    }

}
