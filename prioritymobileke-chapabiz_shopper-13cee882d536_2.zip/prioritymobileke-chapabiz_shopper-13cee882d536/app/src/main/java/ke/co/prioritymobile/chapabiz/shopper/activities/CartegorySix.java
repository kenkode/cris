package ke.co.prioritymobile.chapabiz.shopper.activities;

import android.os.Bundle;
import android.support.design.widget.FloatingActionButton;
import android.support.design.widget.Snackbar;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.GridLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.support.v7.widget.Toolbar;
import android.view.View;

import java.util.ArrayList;

import ke.co.prioritymobile.chapabiz.R;
import ke.co.prioritymobile.chapabiz.retrofit.RetrofitSetup;
import ke.co.prioritymobile.chapabiz.shopper.adapters.QuickInterestAdapter3;
import ke.co.prioritymobile.chapabiz.shopper.entities.Business;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class CartegorySix extends AppCompatActivity implements QuickInterestAdapter3.Clicked {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_cartegory_one);
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);


        final RecyclerView recyclerView = findViewById(R.id.subcategorylist1);
        GridLayoutManager gridLayoutManager = new GridLayoutManager(this,1 );
        recyclerView.setLayoutManager(gridLayoutManager);

        Call<ArrayList<Business>> arrayListCall = RetrofitSetup.retrofitInterface.getSubCategories6();
        arrayListCall.enqueue(new Callback<ArrayList<Business>>() {
            @Override
            public void onResponse(Call<ArrayList<Business>> call, Response<ArrayList<Business>> response) {
                if (response.isSuccessful()) {
                    ArrayList<Business> interests1 = response.body();

                    QuickInterestAdapter3 quickInterestAdapter2 = new QuickInterestAdapter3(CartegorySix.this, interests1);
                    recyclerView.setAdapter(quickInterestAdapter2);
                }
            }
            @Override
            public void onFailure(Call<ArrayList<Business>> call, Throwable t) {

            }
        });
    }

    @Override
    public void interestClicked(int interest) {

    }
}
