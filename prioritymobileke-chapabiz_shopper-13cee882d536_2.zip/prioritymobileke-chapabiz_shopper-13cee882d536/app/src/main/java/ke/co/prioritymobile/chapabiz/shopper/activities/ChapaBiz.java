package ke.co.prioritymobile.chapabiz.shopper.activities;

import android.Manifest;
import android.app.Activity;
import android.app.SearchManager;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.IntentSender;
import android.content.pm.PackageManager;
import android.database.MatrixCursor;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.location.Location;
import android.net.Uri;
import android.os.Bundle;
import android.provider.BaseColumns;
import android.provider.SyncStateContract;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.design.widget.BottomNavigationView;
import android.support.design.widget.BottomSheetBehavior;
import android.support.v4.app.ActivityCompat;
import android.support.v4.app.FragmentTransaction;
import android.support.v4.content.ContextCompat;
import android.support.v4.widget.CursorAdapter;
import android.support.v4.widget.SimpleCursorAdapter;
import android.support.v7.app.AlertDialog;
import android.support.v7.widget.GridLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.support.v7.widget.SearchView;
import android.text.TextUtils;
import android.util.DisplayMetrics;
import android.util.Log;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.support.design.widget.NavigationView;
import android.support.v4.view.GravityCompat;
import android.support.v4.widget.DrawerLayout;
import android.support.v7.app.ActionBarDrawerToggle;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.Menu;
import android.view.MenuItem;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.facebook.AccessToken;
import com.facebook.login.LoginManager;
import com.google.android.gms.auth.api.signin.GoogleSignIn;
import com.google.android.gms.auth.api.signin.GoogleSignInClient;
import com.google.android.gms.auth.api.signin.GoogleSignInOptions;
import com.google.android.gms.common.ConnectionResult;
import com.google.android.gms.common.api.GoogleApiClient;
import com.google.android.gms.common.api.PendingResult;
import com.google.android.gms.common.api.ResultCallback;
import com.google.android.gms.common.api.Status;
import com.google.android.gms.location.LocationListener;
import com.google.android.gms.location.LocationRequest;
import com.google.android.gms.location.LocationServices;
import com.google.android.gms.location.LocationSettingsRequest;
import com.google.android.gms.location.LocationSettingsResult;
import com.google.android.gms.location.LocationSettingsStatusCodes;
import com.google.android.gms.maps.CameraUpdate;
import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.model.BitmapDescriptorFactory;
import com.google.android.gms.maps.model.CameraPosition;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.Marker;
import com.google.android.gms.maps.model.MarkerOptions;
import com.makeramen.roundedimageview.RoundedImageView;
import com.squareup.picasso.Picasso;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Random;
import java.util.Set;

import ke.co.prioritymobile.chapabiz.Constants;
import ke.co.prioritymobile.chapabiz.R;
//import ke.co.prioritymobile.chapabiz.activities.LoginActivity;
import ke.co.prioritymobile.chapabiz.activities.Main3Activity;
//import ke.co.prioritymobile.chapabiz.activities.MainLogin;
import ke.co.prioritymobile.chapabiz.shopper.adapters.PhotoAdapter;
import ke.co.prioritymobile.chapabiz.activities.ShopperLogin;
import ke.co.prioritymobile.chapabiz.shopper.adapters.PhotoAdapter;
import ke.co.prioritymobile.chapabiz.shopper.entities.Business;
import ke.co.prioritymobile.chapabiz.chat.ChatRoomActivity;
import ke.co.prioritymobile.chapabiz.entities.Photo;
import ke.co.prioritymobile.chapabiz.entities.User;
import ke.co.prioritymobile.chapabiz.helpers.BottomNavigationViewHelper;
import ke.co.prioritymobile.chapabiz.helpers.CbSession;
import ke.co.prioritymobile.chapabiz.retrofit.RetrofitSetup;
import ke.co.prioritymobile.chapabiz.shopper.adapters.QuickInterestAdapter;
import ke.co.prioritymobile.chapabiz.shopper.adapters.SearchResultAdapter;
import ke.co.prioritymobile.chapabiz.shopper.entities.InterestDetail;
import ke.co.prioritymobile.chapabiz.shopper.entities.InterestMarker;
import ke.co.prioritymobile.chapabiz.shopper.entities.SearchResult;
import ke.co.prioritymobile.chapabiz.shopper.entities.Shopper;
import ke.co.prioritymobile.chapabiz.shopper.fragments.InterestFragment;
import ke.co.prioritymobile.chapabiz.shopper.fragments.ProfileFragment;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class ChapaBiz extends AppCompatActivity
        implements OnMapReadyCallback, NavigationView.OnNavigationItemSelectedListener,
        GoogleApiClient.ConnectionCallbacks,
        GoogleApiClient.OnConnectionFailedListener,
        LocationListener,
        QuickInterestAdapter.Clicked,
        SearchResultAdapter.Clicked {

    private GoogleMap googleMap;
    ArrayList<InterestMarker> markerPoints;
    //  private boolean isInFront;
    private SearchResultAdapter searchResultAdapter;
    private BottomSheetBehavior bottomSheetBehavior, companyInfoSheet, showListSheet, searchResultsSheet, companySubSheet;
    private QuickInterestAdapter quickInterestAdapter;
    private RecyclerView searchList;
    private TextView showList;
    private RecyclerView recyclerView, photos;
    private TextView addInterest, totalResults;
    private List<String> suggestionList;
    private ArrayList<SearchResult> searchResults;
    private SearchView searchView;
    private ImageView backButton;
    private LinearLayout backToInterest;
    private TextView companyName, subCompanyName, companyLocation, distance, availability, verified, description, phone, direction, message;
    private ArrayList<Business> interestMarkers;
    private Map<String, Business> markers;
    private Business currentBusiness;
    private ArrayList<InterestDetail> suggestionInterest, updatedSuggestionList;
    private GoogleApiClient googleApiClient;
    private final static int REQUEST_CHECK_SETTINGS_GPS = 0x1;
    private final static int REQUEST_ID_MULTIPLE_PERMISSIONS = 0x2;
    private Location myLocation;
    //    private GoogleSignInClient googleSignInClient;
//    private CbSession session;
    //bottom navigation
    private TextView mTextMessage;

    private boolean isInFront;
    private GoogleSignInClient googleSignInClient;
    private CbSession session;

    private BottomNavigationView.OnNavigationItemSelectedListener mOnNavigationItemSelectedListener
            = new BottomNavigationView.OnNavigationItemSelectedListener() {

        @Override
        public boolean onNavigationItemSelected(@NonNull MenuItem item) {
            switch (item.getItemId()) {
                case R.id.navigation_home:
                    //mTextMessage.setText(R.string.title_home);
                    Intent jobz = new Intent(ChapaBiz.this, Main3Activity.class);
                    startActivity(jobz);
                    return true;
                case R.id.navigation_search:
                    //  mTextMessage.setText(R.string.title_dashboard);
                    Intent job1 = new Intent(ChapaBiz.this, ChapaBiz.class);
                    startActivity(job1);
                    return true;
                case R.id.navigation_favorites:
                    //  mTextMessage.setText(R.string.title_notifications);
                    Intent joboneIntent = new Intent(ChapaBiz.this, FavoritesActivity.class);
                    startActivity(joboneIntent);
                    return true;
                case R.id.navigation_profile:
                    // mTextMessage.setText(R.string.title_notifications);
                    Intent jobz5 = new Intent(ChapaBiz.this, ProfileActivity.class);
                    startActivity(jobz5);
                    return true;
            }
            return false;
        }
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_chapa_biz);

        session = new CbSession(this);

        mTextMessage = (TextView) findViewById(R.id.message);
        BottomNavigationView navigation = (BottomNavigationView) findViewById(R.id.navigation);
        navigation.setOnNavigationItemSelectedListener(mOnNavigationItemSelectedListener);

        BottomNavigationView bottomNavigationView = (BottomNavigationView) findViewById(R.id.navigation);
        BottomNavigationViewHelper.disableShiftMode(bottomNavigationView);

        if (session.getUser() == null) {
            Shopper shopper = session.getShopper();
            String id = shopper.getId();
            String name = shopper.getName();
            String email = shopper.getEmail();
            User user = new User(id, name, email);
            session.storeUser(user);
        }

        markerPoints = new ArrayList<InterestMarker>();

        interestMarkers = new ArrayList<>();

        markers = new HashMap();

        totalResults = findViewById(R.id.total_results);

        companyLocation = findViewById(R.id.company_info_location);
        availability = findViewById(R.id.availability);
        verified = findViewById(R.id.verified);
        distance = findViewById(R.id.distance);
        companyName = findViewById(R.id.company_info_name);
        description = findViewById(R.id.company_description);
        photos = findViewById(R.id.photos);
        GridLayoutManager gridLayoutManager = new GridLayoutManager(this, 3);
        photos.setLayoutManager(gridLayoutManager);

        subCompanyName = findViewById(R.id.company_name);

        phone = findViewById(R.id.phone);
        message = findViewById(R.id.message);
        direction = findViewById(R.id.direction);

        message.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (currentBusiness != null) {
                    Intent intent = new Intent(ChapaBiz.this, ChatRoomActivity.class);
                    intent.putExtra("chat_room_id", currentBusiness.getId());
                    intent.putExtra("name", currentBusiness.getName());
                    startActivity(new Intent(intent));
                }
            }
        });

        phone.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (currentBusiness != null) {
                    Intent intent = new Intent(Intent.ACTION_DIAL, Uri.parse("tel:" + currentBusiness.getPhone()));
                    startActivity(intent);
                } else {
                    Toast toast = Toast.makeText(ChapaBiz.this, "Phone number not set up", Toast.LENGTH_SHORT);
                    toast.setGravity(Gravity.CENTER, 0, 0);
                    toast.show();
                }
            }
        });

        direction.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (currentBusiness != null) {
                    Intent intent = new Intent(Intent.ACTION_VIEW,
                            Uri.parse(String.format("google.navigation:q=%s,%s", currentBusiness.getLatitude(), currentBusiness.getLongitude())));
                    intent.setPackage("com.google.android.apps.maps");
                    startActivity(intent);
                }
            }
        });

        backButton = (ImageView) findViewById(R.id.back);

        backToInterest = (LinearLayout) findViewById(R.id.back_to_interest);

        suggestionList = new ArrayList<>();
        updatedSuggestionList = new ArrayList<>();

        searchResults = new ArrayList<>();

        searchResultAdapter = new SearchResultAdapter(this, getSupportFragmentManager(), searchResults);

        Call<ArrayList<InterestDetail>> subCatCall = RetrofitSetup.retrofitInterface.getSubCategories();
        subCatCall.enqueue(new Callback<ArrayList<InterestDetail>>() {
            @Override
            public void onResponse(Call<ArrayList<InterestDetail>> call, Response<ArrayList<InterestDetail>> response) {
                if (response.isSuccessful()) {
                    suggestionInterest = response.body();

                    for (InterestDetail interestDetail :
                            suggestionInterest) {
                        suggestionList.add(interestDetail.getName());
                    }

                    Intent intent = getIntent();
                    if (intent != null) {
                        String position = intent.getStringExtra("query");
                        String stringExtra = intent.getStringExtra("string");
                        if(!TextUtils.isEmpty(position)) {
                            interestClicked(Integer.parseInt(position));
                            searchView.setQuery(stringExtra, true);
                        }
                    }
                } else {

                }
            }

            @Override
            public void onFailure(Call<ArrayList<InterestDetail>> call, Throwable t) {

            }
        });

        backButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                companySubSheet.setHideable(true);
                companySubSheet.setState(BottomSheetBehavior.STATE_HIDDEN);

                searchResultsSheet.setHideable(true);
                searchResultsSheet.setState(BottomSheetBehavior.STATE_EXPANDED);
//                showListSheet.setState(BottomSheetBehavior.STATE_EXPANDED);

            }
        });

        backToInterest.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                searchResultsSheet.setHideable(true);
                searchResultsSheet.setState(BottomSheetBehavior.STATE_HIDDEN);
                bottomSheetBehavior.setHideable(false);
                bottomSheetBehavior.setState(BottomSheetBehavior.STATE_EXPANDED);
                showListSheet.setHideable(true);
                showListSheet.setState(BottomSheetBehavior.STATE_HIDDEN);
                googleMap.clear();
                interestMarkers.clear();
                searchResults.clear();
                currentBusiness = null;
            }
        });

        searchList = findViewById(R.id.interests);
        recyclerView = findViewById(R.id.list);
        GridLayoutManager photoLayoutManager = new GridLayoutManager(this, 3);
        recyclerView.setLayoutManager(photoLayoutManager);

        double latitude = 1.2921;
        double longitude = 36.8219;

        String[] placeNames = {"Nairobi", "Milimani", "Zone", "Urban"};

        for (int i = 0; i < 4; i++) {
            int rand = new Random().nextInt(2);
            InterestMarker interestMarker = new InterestMarker();
            LatLng latLng = new LatLng(latitude += rand, longitude += rand);
            interestMarker.setName(placeNames[i]);
            interestMarker.setDescription(placeNames[i]);
//            interestMarker.setLatLng(latLng);
            markerPoints.add(interestMarker);
        }

        SupportMapFragment mapFragment = (SupportMapFragment) getSupportFragmentManager()
                .findFragmentById(R.id.map);
        mapFragment.getMapAsync(this);

        session = new CbSession(this);

        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        NavigationView navigationView = (NavigationView) findViewById(R.id.nav_view);
        navigationView.setNavigationItemSelectedListener(this);

        View view = navigationView.getHeaderView(0);

        TextView showProfile = view.findViewById(R.id.see_profile);
        showProfile.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(ChapaBiz.this, ProfileActivity.class));
                DrawerLayout drawer = (DrawerLayout) findViewById(R.id.drawer_layout);
                drawer.closeDrawer(GravityCompat.START);
            }
        });

        TextView name = view.findViewById(R.id.username);
        RoundedImageView circleImageView = view.findViewById(R.id.imageView);

        if (session.getShopper() != null) {
            name.setText(session.getShopper().getName());
            String path = session.getShopper().getPicture();
            if (TextUtils.isEmpty(path)) {
                path = "image";
            }
            Picasso.with(this).load(path)
                    .placeholder(ContextCompat.getDrawable(this, R.drawable.ic_chapabiz_logo_vert))
                    .into(circleImageView);
        }


        addInterest = findViewById(R.id.add_interest_text);

        addInterest.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(ChapaBiz.this, InterestActivity.class));
            }
        });

        showList = findViewById(R.id.showlist);

        showList.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                showListSheet.setHideable(true);
                showListSheet.setState(BottomSheetBehavior.STATE_HIDDEN);
                searchResultsSheet.setState(BottomSheetBehavior.STATE_EXPANDED);
            }
        });

        final TextView moreInfo = findViewById(R.id.more_info);
//        showList.setVisibility(View.GONE);

        moreInfo.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                companyInfoSheet.setState(BottomSheetBehavior.STATE_EXPANDED);
            }
        });

        LinearLayout companySubInfo = findViewById(R.id.company_sub_info);
        companySubSheet = BottomSheetBehavior.from(companySubInfo);
        companySubSheet.setHideable(true);
        companySubSheet.setState(BottomSheetBehavior.STATE_HIDDEN);

        companySubInfo.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                companyInfoSheet.setState(BottomSheetBehavior.STATE_EXPANDED);

                companySubSheet.setHideable(true);
                companySubSheet.setState(BottomSheetBehavior.STATE_HIDDEN);
            }
        });

        LinearLayout companyInfo = findViewById(R.id.company_info);
        companyInfoSheet = BottomSheetBehavior.from(companyInfo);
        companyInfoSheet.setHideable(true);
        companyInfoSheet.setState(BottomSheetBehavior.STATE_HIDDEN);

        companyInfoSheet.setBottomSheetCallback(new BottomSheetBehavior.BottomSheetCallback() {
            @Override
            public void onStateChanged(@NonNull View bottomSheet, int newState) {
                switch (newState) {
                    case BottomSheetBehavior.STATE_HIDDEN:
                        companySubSheet.setHideable(false);
                        companySubSheet.setState(BottomSheetBehavior.STATE_EXPANDED);
                        showListSheet.setHideable(true);
                        showListSheet.setState(BottomSheetBehavior.STATE_HIDDEN);
                        break;
                    case BottomSheetBehavior.STATE_EXPANDED:
                        searchResultsSheet.setHideable(true);
                        searchResultsSheet.setState(BottomSheetBehavior.STATE_HIDDEN);
                        setUpBusinessProfile(currentBusiness);
                        break;
                }
            }

            @Override
            public void onSlide(@NonNull View bottomSheet, float slideOffset) {

            }
        });

        LinearLayout showListTrigger = findViewById(R.id.showlist_sheet);
        showListSheet = BottomSheetBehavior.from(showListTrigger);
        showListSheet.setHideable(true);
        showListSheet.setState(BottomSheetBehavior.STATE_HIDDEN);

        LinearLayout searchResultsLayout = findViewById(R.id.search_results);
        searchResultsSheet = BottomSheetBehavior.from(searchResultsLayout);
        searchResultsSheet.setHideable(true);
        searchResultsSheet.setState(BottomSheetBehavior.STATE_HIDDEN);

        LinearLayout bottomSheet = findViewById(R.id.bottom_sheet);
        bottomSheetBehavior = BottomSheetBehavior.from(bottomSheet);
        searchResultsSheet.setBottomSheetCallback(new BottomSheetBehavior.BottomSheetCallback() {
            @Override
            public void onStateChanged(@NonNull View bottomSheet, int newState) {
                switch (newState) {
                    case BottomSheetBehavior.STATE_HIDDEN:
//                        showList.setVisibility(View.VISIBLE);
                        if (searchResults.size() > 0) {
                            showListSheet.setHideable(false);
                            showListSheet.setState(BottomSheetBehavior.STATE_EXPANDED);
                        }
                        break;
                    case BottomSheetBehavior.STATE_DRAGGING:
//                        showList.setVisibility(View.GONE);
//                        bottomSheetBehavior.setHideable(true);
//                        bottomSheetBehavior.setPeekHeight(480);
                        break;
                    case BottomSheetBehavior.STATE_EXPANDED:

//                        showList.setVisibility(View.GONE);
//                        bottomSheetBehavior.setHideable(true);
//                        bottomSheetBehavior.setPeekHeight(480);
                        break;
                }
            }

            @Override
            public void onSlide(@NonNull View bottomSheet, float slideOffset) {
//                if(slideOffset <= 120) {
//                    showList.setVisibility(View.VISIBLE);
//                    bottomSheetBehavior.setPeekHeight(120);
//                }else {
//                    showList.setVisibility(View.GONE);
//                }
            }
        });

        bottomSheetBehavior.setHideable(false);
        bottomSheetBehavior.setState(BottomSheetBehavior.STATE_EXPANDED);

//        showListSheet.setBottomSheetCallback(new BottomSheetBehavior.BottomSheetCallback() {
//            @Override
//            public void onStateChanged(@NonNull View bottomSheet, int newState) {
//                switch (newState) {
//                    case BottomSheetBehavior.STATE_EXPANDED:
//                        Toast.makeText(ChapaBiz.this, "Expanded", Toast.LENGTH_SHORT).show();
//                        break;
//                }
//            }
//
//            @Override
//            public void onSlide(@NonNull View bottomSheet, float slideOffset) {
//
//            }
//        });
//        bottomSheetBehavior.set
//        bottomSheetBehavior.setPeekHeight(120);
        setUpGoogleClient();
    }

    private synchronized void setUpGoogleClient() {
        googleApiClient = new GoogleApiClient.Builder(this)
                .enableAutoManage(this, 0, this)
                .addConnectionCallbacks(this)
                .addOnConnectionFailedListener(this)
                .addApi(LocationServices.API)
                .build();
    }

    @Override
    protected void onStart() {
        super.onStart();
        Call<ArrayList<InterestDetail>> arrayListCall = RetrofitSetup.retrofitInterface.getInterests(session.getShopper().getId());
        arrayListCall.enqueue(new Callback<ArrayList<InterestDetail>>() {
            @Override
            public void onResponse(Call<ArrayList<InterestDetail>> call, Response<ArrayList<InterestDetail>> response) {
                if (response.isSuccessful()) {
                    ArrayList<InterestDetail> interests = response.body();
                    if (interests.size() < 1) {
                        addInterest.setVisibility(View.VISIBLE);
                    } else {
                        addInterest.setVisibility(View.GONE);
                    }
                    quickInterestAdapter = new QuickInterestAdapter(ChapaBiz.this, interests);
                    recyclerView.setAdapter(quickInterestAdapter);
                }
            }

            @Override
            public void onFailure(Call<ArrayList<InterestDetail>> call, Throwable t) {

            }
        });
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.chapa_biz, menu);

        SearchManager searchManager = (SearchManager) getSystemService(Context.SEARCH_SERVICE);
        searchView = (SearchView) menu.findItem(R.id.menu_search).getActionView();

        searchView.setSearchableInfo(searchManager.getSearchableInfo(getComponentName()));
        searchView.setIconifiedByDefault(true);

        final CursorAdapter cursorAdapter = new SimpleCursorAdapter(this,
                R.layout.search_view,
                null,
                new String[]{SearchManager.SUGGEST_COLUMN_TEXT_1},
                new int[]{R.id.text1}, 0);

        searchView.setSuggestionsAdapter(cursorAdapter);

        searchView.setOnSuggestionListener(new SearchView.OnSuggestionListener() {
            @Override
            public boolean onSuggestionSelect(int position) {
                return false;
            }

            @Override
            public boolean onSuggestionClick(int position) {
                searchView.clearFocus();
                searchView.setQuery(updatedSuggestionList.get(position).getName(), false);
                interestClicked(Integer.parseInt(updatedSuggestionList.get(position).getId()));

                //appAdp.list.removeAll(templist);
                return true;
            }
        });

        searchView.setOnCloseListener(new SearchView.OnCloseListener() {
            @Override
            public boolean onClose() {
                searchView.clearFocus();
//                searchView.setIconified(true);
                bottomSheetBehavior.setState(BottomSheetBehavior.STATE_EXPANDED);
                searchList.setAdapter(null);
                googleMap.clear();
                searchResultAdapter.notifyDataSetChanged();
                return true;
            }
        });

        searchView.setOnQueryTextListener(new SearchView.OnQueryTextListener() {
            @Override
            public boolean onQueryTextSubmit(String query) {
                for (int i = 0; i < updatedSuggestionList.size(); i++) {
                    if (updatedSuggestionList.get(i).getName().equals(query)) {
                        placeMarkers(Integer.parseInt(updatedSuggestionList.get(i).getId()));
                        break;
                    }
                }

                return true;
            }

            @Override
            public boolean onQueryTextChange(String newText) {
                String columns[] = {BaseColumns._ID,
                        SearchManager.SUGGEST_COLUMN_TEXT_1,
                        SearchManager.SUGGEST_COLUMN_INTENT_ACTION};

                MatrixCursor matrixCursor = new MatrixCursor(columns);
                updatedSuggestionList.clear();
                for (int i = 0; i < suggestionList.size(); i++) {
                    if (newText.regionMatches(true, 0, suggestionList.get(i), 0, newText.length())) {
                        String temp[] = {Integer.toString(i), suggestionList.get(i), suggestionList.get(i)};
                        matrixCursor.addRow(temp);
                        updatedSuggestionList.add(suggestionInterest.get(i));
                    }
                }
                cursorAdapter.swapCursor(matrixCursor);
                return true;
            }
        });

        return true;
    }

    @Override
    public boolean onSearchRequested() {
        Toast.makeText(this, "Triggered", Toast.LENGTH_SHORT).show();

        return true;
    }

    @SuppressWarnings("StatementWithEmptyBody")
    @Override
    public boolean onNavigationItemSelected(MenuItem item) {
        // Handle navigation view item clicks here.
        int id = item.getItemId();
        DrawerLayout drawer = (DrawerLayout) findViewById(R.id.drawer_layout);

        if (id == R.id.home) {
            // if (isInFront) {
//                drawer.closeDrawer(GravityCompat.START);
//                return false;

            //  }
            //  Intent joboneIntent = new Intent(UserHome.this, ChapaBiz.class);
            //startActivity(joboneIntent);
            startActivity(new Intent(ChapaBiz.this, UserHome.class));
        } else if (id == R.id.map) {
            startActivity(new Intent(ChapaBiz.this, ChapaBiz.class));
        } else if (id == R.id.interests) {
            startActivity(new Intent(ChapaBiz.this, InterestActivity.class));
        } else if (id == R.id.messages) {
            startActivity(new Intent(ChapaBiz.this, ChatRoomActivity.class));
        } else if (id == R.id.logout) {
            logout();
        }

        drawer.closeDrawer(GravityCompat.START);

        return true;
    }

    private void startMaps() {
//        updateToolbar(false, false, "Search Businesses");
//        SearchFragment searchFragment = new SearchFragment();
//        FragmentTransaction fragmentTransaction = getSupportFragmentManager().beginTransaction();
//        fragmentTransaction.replace(R.id.content_frame, searchFragment, InterestFragment.class.getSimpleName());
//        fragmentTransaction.commit();
    }

    private void startInterests() {
//        updateToolbar(true, false, "What are your interests?");
        InterestFragment interestFragment = new InterestFragment();
        FragmentTransaction fragmentTransaction = getSupportFragmentManager().beginTransaction();
        fragmentTransaction.replace(R.id.content_frame, interestFragment, InterestFragment.class.getSimpleName());
        fragmentTransaction.commit();
    }

    private void startProfile() {
//        updateToolbar(false, false, "Profile");
        ProfileFragment profileFragment = new ProfileFragment();
        FragmentTransaction fragmentTransaction = getSupportFragmentManager().beginTransaction();
        fragmentTransaction.replace(R.id.content_frame, profileFragment, InterestFragment.class.getSimpleName());
        fragmentTransaction.commit();
    }

    private void logout() {

        GoogleSignInOptions gso = new GoogleSignInOptions.Builder(GoogleSignInOptions.DEFAULT_SIGN_IN)
                .requestEmail()
                .build();
        googleSignInClient = GoogleSignIn.getClient(this, gso);
        if (googleSignInClient != null) {
            googleSignInClient.signOut();
        }
        boolean loggedIn = AccessToken.getCurrentAccessToken() != null;
        if (loggedIn) {
            LoginManager.getInstance().logOut();
        }
        session.clear();
        startActivity(new Intent(ChapaBiz.this, ShopperLogin.class));
    }
    @Override
    public void onMapReady(GoogleMap googleMap) {
        this.googleMap = googleMap;
        if (checkLocationPermission()) {
            if (ContextCompat.checkSelfPermission(this,
                    Manifest.permission.ACCESS_FINE_LOCATION)
                    == PackageManager.PERMISSION_GRANTED) {

                googleMap.setMyLocationEnabled(true);


            }
        }

        googleMap.setOnMapClickListener(new GoogleMap.OnMapClickListener() {
            @Override
            public void onMapClick(LatLng latLng) {
                if (companySubSheet.getState() == BottomSheetBehavior.STATE_EXPANDED) {
                    companySubSheet.setHideable(true);
                    companySubSheet.setState(BottomSheetBehavior.STATE_HIDDEN);
                    companyInfoSheet.setState(BottomSheetBehavior.STATE_EXPANDED);
                } else if (companyInfoSheet.getState() == BottomSheetBehavior.STATE_EXPANDED
                        || companyInfoSheet.getState() == BottomSheetBehavior.STATE_COLLAPSED) {
                    companyInfoSheet.setState(BottomSheetBehavior.STATE_HIDDEN);
                    companySubSheet.setHideable(false);
                    companySubSheet.setState(BottomSheetBehavior.STATE_EXPANDED);
                } else if (searchResultsSheet.getState() == BottomSheetBehavior.STATE_EXPANDED) {
                    searchResultsSheet.setHideable(true);
                    searchResultsSheet.setState(BottomSheetBehavior.STATE_HIDDEN);
                    showListSheet.setHideable(false);
                    showListSheet.setState(BottomSheetBehavior.STATE_EXPANDED);
                } else if (showListSheet.getState() == BottomSheetBehavior.STATE_EXPANDED) {
                    showListSheet.setHideable(true);
                    showListSheet.setState(BottomSheetBehavior.STATE_HIDDEN);
                    searchResultsSheet.setHideable(false);
                    searchResultsSheet.setState(BottomSheetBehavior.STATE_EXPANDED);
                } else if (bottomSheetBehavior.getState() == BottomSheetBehavior.STATE_EXPANDED) {
                    bottomSheetBehavior.setHideable(true);
                    bottomSheetBehavior.setState(BottomSheetBehavior.STATE_HIDDEN);
                } else {
                    bottomSheetBehavior.setHideable(false);
                    bottomSheetBehavior.setState(BottomSheetBehavior.STATE_EXPANDED);
                }
            }
        });

        googleMap.setOnMarkerClickListener(new GoogleMap.OnMarkerClickListener() {
            @Override
            public boolean onMarkerClick(Marker marker) {
                String businessName = marker.getTitle();
                companyName.setText(businessName);
                subCompanyName.setText(businessName);

                Business business = markers.get(marker.getId());
                setUpBusinessProfile(business);
                currentBusiness = business;

                if (searchResultsSheet.getState() == BottomSheetBehavior.STATE_EXPANDED) {
                    searchResultsSheet.setHideable(true);
                    searchResultsSheet.setState(BottomSheetBehavior.STATE_HIDDEN);
                } else if (showListSheet.getState() == BottomSheetBehavior.STATE_EXPANDED) {
                    showListSheet.setHideable(true);
                    showListSheet.setState(BottomSheetBehavior.STATE_HIDDEN);
                }

                companyInfoSheet.setState(BottomSheetBehavior.STATE_EXPANDED);

                return false;
            }
        });

        googleMap.getUiSettings().setCompassEnabled(true);
        googleMap.getUiSettings().setMyLocationButtonEnabled(true);
        googleMap.getUiSettings().setRotateGesturesEnabled(false);
    }

    private void placeMarkers(int interest) {
        Call<ArrayList<Business>> interestCall = RetrofitSetup.retrofitInterface.getBusinesses(interest);
        interestCall.enqueue(new Callback<ArrayList<Business>>() {
            @Override
            public void onResponse(Call<ArrayList<Business>> call, Response<ArrayList<Business>> response) {
                if (response.isSuccessful()) {
                    interestMarkers = response.body();
                    markers.clear();
                    for (Business interestMarker :
                            interestMarkers) {
                        View marker = LayoutInflater.from(ChapaBiz.this).inflate(R.layout.marker_view, null);
                        TextView numTxt = marker.findViewById(R.id.business_type);
                        numTxt.setText(interestMarker.getName().toUpperCase().substring(0, 1));
                        LatLng latLng = new LatLng(interestMarker.getLatitude(), interestMarker.getLongitude());
                        Marker m = googleMap.addMarker(new MarkerOptions().position(latLng)
                                .title(interestMarker.getName())
//                                .snippet(interestMarker.getDescription())
                                .icon(BitmapDescriptorFactory.fromBitmap(createDrawableFromView(ChapaBiz.this, marker))));

                        markers.put(m.getId(), interestMarker);

                        CameraPosition cameraPosition = new CameraPosition.Builder().target(latLng).zoom(11).build();
                        googleMap.animateCamera(CameraUpdateFactory.newCameraPosition
                                (cameraPosition));
                    }
                    loadSearchResults(interestMarkers);
                } else {
                    Toast.makeText(ChapaBiz.this, "Something went wrong", Toast.LENGTH_SHORT).show();
                }
            }

            @Override
            public void onFailure(Call<ArrayList<Business>> call, Throwable t) {
                t.printStackTrace();
            }
        });
    }

    private void loadSearchResults(ArrayList<Business> businesses) {
        searchResults.clear();
        if(businesses.size() == 0){
            Toast.makeText(this,"No business available",Toast.LENGTH_LONG).show();
        }
        for (int i = 0; i < businesses.size(); i++) {
            Business business = businesses.get(i);
            SearchResult searchResult = new SearchResult();
            searchResult.setDescription(business.getDescription());
            searchResult.setId(business.getId());
            searchResult.setName(business.getName());
            searchResult.setType(business.getCategory());
//            searchResult.setPhoto(business.getPhotos().size() > 0 ? business.getPhotos().get(0) : "Image");

            float[] results = new float[2];

            try {
                Location.distanceBetween(myLocation.getLatitude(), myLocation.getLongitude(),
                        business.getLatitude(), business.getLongitude(), results);

                int distance = (int) results[0];

                searchResult.setDistance(String.valueOf(distance));
                business.setDistance(String.valueOf(distance));

            } catch (Exception e) {
                Toast.makeText(this, e.getMessage(), Toast.LENGTH_SHORT).show();
            }

            searchResults.add(searchResult);
        }

        totalResults.setText(String.format("%s results", searchResults.size()));

        searchList.setAdapter(searchResultAdapter);
        searchResultAdapter.notifyDataSetChanged();
    }

    public static Bitmap createDrawableFromView(Context context, View view) {
        DisplayMetrics displayMetrics = new DisplayMetrics();
        ((Activity) context).getWindowManager().getDefaultDisplay().getMetrics(displayMetrics);
        view.setLayoutParams(new ViewGroup.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        view.measure(displayMetrics.widthPixels, displayMetrics.heightPixels);
        view.layout(0, 0, displayMetrics.widthPixels, displayMetrics.heightPixels);
        view.buildDrawingCache();
        Bitmap bitmap = Bitmap.createBitmap(view.getMeasuredWidth(), view.getMeasuredHeight(), Bitmap.Config.ARGB_8888);

        Canvas canvas = new Canvas(bitmap);
        view.draw(canvas);

        return bitmap;
    }

    public boolean checkLocationPermission() {
        if (ContextCompat.checkSelfPermission(this,
                Manifest.permission.ACCESS_FINE_LOCATION)
                != PackageManager.PERMISSION_GRANTED) {

            if (ActivityCompat.shouldShowRequestPermissionRationale(this,
                    Manifest.permission.ACCESS_FINE_LOCATION)) {

                new AlertDialog.Builder(this)
                        .setTitle("")
                        .setMessage("")
                        .setPositiveButton("Ok", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialogInterface, int i) {
                                ActivityCompat.requestPermissions(ChapaBiz.this, new String[]
                                        {Manifest.permission.ACCESS_FINE_LOCATION}, 1);
                            }
                        })
                        .create()
                        .show();

            } else {
                ActivityCompat.requestPermissions(this,
                        new String[]{Manifest.permission.ACCESS_FINE_LOCATION},
                        1);
            }
            return false;
        } else {
            return true;
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode,
                                           String permissions[], int[] grantResults) {
        switch (requestCode) {
            case 1: {
                // If request is cancelled, the result arrays are empty.
                if (grantResults.length > 0
                        && grantResults[0] == PackageManager.PERMISSION_GRANTED) {

                    // permission was granted, yay! Do the
                    // location-related task you need to do.
                    if (ContextCompat.checkSelfPermission(this,
                            Manifest.permission.ACCESS_FINE_LOCATION)
                            == PackageManager.PERMISSION_GRANTED) {

                        googleMap.setMyLocationEnabled(true);
                    }

                } else {

                }
                return;
            }

        }
    }

    @Override
    protected void onResume() {
        super.onResume();
        googleApiClient.connect();
        isInFront = true;
    }

    @Override
    public void onPause() {
        super.onPause();
        if (googleApiClient.isConnected()) {
            LocationServices.FusedLocationApi.removeLocationUpdates(googleApiClient, this);
            googleApiClient.disconnect();
        }
        isInFront = false;
    }

    @Override
    public void interestClicked(int interest) {
        googleMap.clear();
//        searchView.setQuery(interest, true);
        //Get businesses from db then place markers
        interestMarkers.clear();
        searchResultAdapter.notifyDataSetChanged();
        bottomSheetBehavior.setHideable(true);
        bottomSheetBehavior.setState(BottomSheetBehavior.STATE_HIDDEN);
        searchResultsSheet.setHideable(true);
        searchResultsSheet.setState(BottomSheetBehavior.STATE_EXPANDED);
        placeMarkers(interest);
    }

    private void markerClicked() {
        // update bottom sheet
    }

    @Override
    public void businessClicked(String id) {

        Set<String> keySet = markers.keySet();

        for (String key : keySet) {
            Business business = markers.get(key);
            if (business.getId().equals(id)) {
                currentBusiness = business;
                companyInfoSheet.setState(BottomSheetBehavior.STATE_EXPANDED);
                searchResultsSheet.setHideable(true);
                searchResultsSheet.setState(BottomSheetBehavior.STATE_HIDDEN);
                break;
            }
        }
    }

    private void setUpBusinessProfile(final Business business) {
        companyLocation.setText(business.getTown());
        distance.setText(business.getDistance() != null ? String.format("%s Km(s) Away", Integer.parseInt(business.getDistance()) / 1000) : "__Km(s)");
        availability.setText(business.getTimestamps());
        verified.setText(business.getVerified() == 1 ? "Verified" : "Not Verified");
        verified.setTextColor(business.getVerified() == 1 ? ContextCompat.getColor(this, R.color.colorGreenAccent) : ContextCompat.getColor(this, R.color.colorRedAccent));
        description.setText(business.getDescription());
        companyName.setText(business.getName());
        subCompanyName.setText(business.getName());

        Call<ArrayList<Photo>> call = RetrofitSetup.retrofitInterface.getPhotos(business.getId());
        call.enqueue(new Callback<ArrayList<Photo>>() {
            @Override
            public void onResponse(Call<ArrayList<Photo>> call, Response<ArrayList<Photo>> response) {
                if (response.isSuccessful()) {
                    ArrayList<Photo> p = response.body();
                    PhotoAdapter photoAdapter = new PhotoAdapter(ChapaBiz.this, p);
                    photos.setAdapter(photoAdapter);
                }

            }

            @Override
            public void onFailure(Call<ArrayList<Photo>> call, Throwable t) {
                t.printStackTrace();
            }
        });
    }

    public int calculateDistance() {
        checkPermissions();
        return 0;
    }

    @Override
    public void onConnected(@Nullable Bundle bundle) {
        checkPermissions();
    }

    @Override
    public void onConnectionSuspended(int i) {

    }

    @Override
    public void onConnectionFailed(@NonNull ConnectionResult connectionResult) {

    }

    @Override
    public void onLocationChanged(Location location) {
        myLocation = location;
        if (myLocation != null) {
            searchResultAdapter.notifyDataSetChanged();
           /* CameraPosition cameraPosition = new CameraPosition.Builder()
                    .target(new LatLng(myLocation.getLatitude(), myLocation.getLongitude()))
                    .zoom(14)
                    .build();
            googleMap.animateCamera(CameraUpdateFactory.newCameraPosition
                    (cameraPosition));*/

//            CameraUpdate center = CameraUpdateFactory.newLatLng(new LatLng(myLocation.getLatitude(),myLocation.getLongitude()));
//            CameraUpdate zoom = CameraUpdateFactory.zoomTo(11);
//            googleMap.moveCamera(center);
//            googleMap.animateCamera(zoom);
        }

    }

    private void getMyLocation() {
        if (googleApiClient != null) {
            if (googleApiClient.isConnected()) {
                if (ContextCompat.checkSelfPermission(ChapaBiz.this, Manifest.permission.ACCESS_FINE_LOCATION)
                        == PackageManager.PERMISSION_GRANTED) {
                    myLocation = LocationServices.FusedLocationApi.getLastLocation(googleApiClient);
                    LocationRequest locationRequest = new LocationRequest();
                    locationRequest.setInterval(3000);
                    locationRequest.setFastestInterval(3000);
                    locationRequest.setPriority(LocationRequest.PRIORITY_HIGH_ACCURACY);

                    LocationSettingsRequest.Builder locationSettingsRequest = new LocationSettingsRequest.Builder()
                            .addLocationRequest(locationRequest);

                    locationSettingsRequest.setAlwaysShow(true);

                    LocationServices.FusedLocationApi.requestLocationUpdates(googleApiClient, locationRequest, this);

                    PendingResult<LocationSettingsResult> requestPendingResult = LocationServices.SettingsApi.checkLocationSettings(googleApiClient, locationSettingsRequest.build());

                    requestPendingResult.setResultCallback(new ResultCallback<LocationSettingsResult>() {
                        @Override
                        public void onResult(@NonNull LocationSettingsResult locationSettingsResult) {
                            final Status status = locationSettingsResult.getStatus();
                            switch (status.getStatusCode()) {
                                case LocationSettingsStatusCodes.SUCCESS:
                                    int permissionLocation = ContextCompat
                                            .checkSelfPermission(ChapaBiz.this,
                                                    Manifest.permission.ACCESS_FINE_LOCATION);
                                    if (permissionLocation == PackageManager.PERMISSION_GRANTED) {
                                        myLocation = LocationServices.FusedLocationApi
                                                .getLastLocation(googleApiClient);
                                        if (myLocation != null) {
                                            CameraPosition cameraPosition = new CameraPosition.Builder()
                                                    .target(new LatLng(myLocation.getLatitude(), myLocation.getLongitude()))
                                                    .zoom(11)
                                                    .build();
                                            googleMap.animateCamera(CameraUpdateFactory.newCameraPosition
                                                    (cameraPosition));
                                        }
//                                        myLocation = new LocationManager().getLastKnownLocation(LocationManager.NETWORK_PROVIDER)
                                    }
                                    break;
                                case LocationSettingsStatusCodes.RESOLUTION_REQUIRED:
                                    try {
                                        status.startResolutionForResult(ChapaBiz.this,
                                                REQUEST_CHECK_SETTINGS_GPS);
                                    } catch (IntentSender.SendIntentException e) {
                                        // Ignore the error.
                                    }
                                    break;
                                case LocationSettingsStatusCodes.SETTINGS_CHANGE_UNAVAILABLE:
                                    // Location settings are not satisfied.
                                    // However, we have no way
                                    // to fix the
                                    // settings so we won't show the dialog.
                                    // finish();
                                    break;
                            }
                        }
                    });

                }
            }
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        switch (requestCode) {
            case REQUEST_CHECK_SETTINGS_GPS:
                switch (resultCode) {
                    case Activity.RESULT_OK:
                        getMyLocation();
                        break;
                    case Activity.RESULT_CANCELED:
                        finish();
                        break;
                }
                break;
        }
    }

    private void checkPermissions() {
        int permissionLocation = ContextCompat.checkSelfPermission(ChapaBiz.this,
                android.Manifest.permission.ACCESS_FINE_LOCATION);
        List<String> listPermissionsNeeded = new ArrayList<>();
        if (permissionLocation != PackageManager.PERMISSION_GRANTED) {
            listPermissionsNeeded.add(android.Manifest.permission.ACCESS_FINE_LOCATION);
            if (!listPermissionsNeeded.isEmpty()) {
                ActivityCompat.requestPermissions(this,
                        listPermissionsNeeded.toArray(new String[listPermissionsNeeded.size()]), REQUEST_ID_MULTIPLE_PERMISSIONS);
            }
        } else {
            getMyLocation();
        }
    }

}
