package ke.co.prioritymobile.chapabiz.shopper.activities;

import android.app.ProgressDialog;
import android.content.Intent;
import android.os.Bundle;
import android.support.design.widget.FloatingActionButton;
import android.support.design.widget.Snackbar;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.text.InputType;
import android.text.TextUtils;
import android.util.Log;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.facebook.CallbackManager;
import com.google.gson.Gson;

import ke.co.prioritymobile.chapabiz.R;
import ke.co.prioritymobile.chapabiz.activities.Email_Login;
import ke.co.prioritymobile.chapabiz.activities.Main3Activity;
import ke.co.prioritymobile.chapabiz.activities.RequestPwdReset;
import ke.co.prioritymobile.chapabiz.activities.ShopperLogin;
import ke.co.prioritymobile.chapabiz.entities.Response;
import ke.co.prioritymobile.chapabiz.helpers.CbSession;
import ke.co.prioritymobile.chapabiz.retrofit.RetrofitSetup;
import ke.co.prioritymobile.chapabiz.shopper.entities.Shopper;
import retrofit2.Call;
import retrofit2.Callback;

import static ke.co.prioritymobile.chapabiz.helpers.CbSession.FACEBOOK;
import static ke.co.prioritymobile.chapabiz.helpers.CbSession.GOOGLE;

public class CreateShopper extends AppCompatActivity {

    private CallbackManager callbackManager;
    private static final String EMAIL = "email";
    private EditText username, password,first_name, last_name, email;

    CbSession session;

    Button createAccount;

    TextView login;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_create_shopper);
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);

        session = new CbSession(this);

        createAccount = (Button) findViewById(R.id.create_account);

        login = (TextView) findViewById(R.id.login);

        login.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(CreateShopper.this, Email_Login.class));
            }
        });

        login = (TextView) findViewById(R.id.login);

       // username = (EditText) findViewById(R.id.username);

        first_name = (EditText) findViewById(R.id.first_name);
        last_name = (EditText) findViewById(R.id.last_name);
        email = (EditText) findViewById(R.id.email);
        password = (EditText) findViewById(R.id.password);

        createAccount.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String m = first_name.getText().toString();
                String n = last_name.getText().toString();
                String o = email.getText().toString();
                String p = password.getText().toString();

                if (TextUtils.isEmpty(m) || TextUtils.isEmpty(n) || TextUtils.isEmpty(o) ||  TextUtils.isEmpty(p)) {
                    Toast.makeText(CreateShopper.this, "Provide credentials", Toast.LENGTH_SHORT).show();
                    return;
                }

                        Shopper shopper = new Shopper();
                        String user = first_name.getText().toString().trim();
                        String user2 = last_name.getText().toString().trim();
                        String user3 = email.getText().toString().trim();
                        String pass = password.getText().toString().trim();

                        if (TextUtils.isEmpty(user) || TextUtils.isEmpty(user2)  || TextUtils.isEmpty(user3)  || TextUtils.isEmpty(pass)) {
                            Toast toast = Toast.makeText(CreateShopper.this, "Provide credentials", Toast.LENGTH_SHORT);
                            toast.setGravity(Gravity.CENTER, 0, 0);
                            toast.show();
                            return;
                        }


                        shopper.setFirst_name(user);
                        shopper.setLast_name(user2);
                        shopper.setEmail(user3);
                        shopper.setPassword(pass);

                String bsJson = new Gson().toJson(shopper);
                Call<Response> call1 = RetrofitSetup.retrofitInterface.signUpNewUser(bsJson);
                call1.enqueue(new Callback<Response>() {
                    @Override
                    public void onResponse(Call<Response> call, retrofit2.Response<Response> response) {
                        if (response.isSuccessful()) {
                            Response response1 = response.body();

                            switch (response1.getStatus()) {
                                case 200:
                                    session.setShopper(response1.getShopper());
                                    startActivity(new Intent(CreateShopper.this, ShopperLogin.class));
                                    finish();
                                    break;
                                case 301:
                                    break;
                                case 302:
                                    break;
                            }
                            Toast.makeText(CreateShopper.this, response1.getMessage(), Toast.LENGTH_SHORT).show();
                        }
                      //  progressDialog.dismiss();
                    }

                    @Override
                    public void onFailure(Call<Response> call, Throwable t) {
                        t.printStackTrace();
                      //  progressDialog.dismiss();
                    }
                });


                        Log.e("error", new Gson().toJson(shopper));

                       attemptSignIn(new Gson().toJson(shopper), EMAIL);
                      //  break;
                setupEmailLogin();
                }

        });

     //   updateInput();

    }


    @Override
    protected void onStart() {
        super.onStart();
//
        if (session.getShopper() != null) {
            startActivity(new Intent(CreateShopper.this, Main3Activity.class));

           // startActivity(new Intent(CreateShopper.this, Email_Login.class));

            finish();
        }
}

    public void updateInput() {

      //  password.setHint("Password");
      //  username.setHint("First name");
     //   username.setInputType(InputType.TYPE_CLASS_TEXT);

    }
    private void setupEmailLogin() {
        session.setSignInMethod(EMAIL);
        startActivity(new Intent(CreateShopper.this, Email_Login.class));
        finish();
    }

    private void attemptSignIn(String userJson, final String method) {

        Call<Shopper> call = RetrofitSetup.retrofitInterface.login(userJson, method);
        final ProgressDialog progressDialog = new ProgressDialog(this);
        progressDialog.setIndeterminate(true);
        progressDialog.setMessage("Authenticating...");
        progressDialog.show();
        call.enqueue(new Callback<Shopper>() {
            @Override
            public void onResponse(Call<Shopper> call, retrofit2.Response<Shopper> response) {
//                progressDialog.dismiss();
                if (response.isSuccessful()) {
                    Shopper shopper = response.body();
                    CbSession session = new CbSession(CreateShopper.this);
                    session.setSignInMethod(method);

                    if (shopper.getStatus() != 200) {
                        Toast toast = Toast.makeText(CreateShopper.this, "Authentication failed!", Toast.LENGTH_SHORT);
                        toast.setGravity(Gravity.CENTER, 0, 0);
                        toast.show();
                        return;
                    }

                    session.setShopper(shopper);

//                    switch (method) {
//                        case GOOGLE:
//                            session.setBusiness(null);
//                            session.setAgent(null);
//                            break;
//                        case FACEBOOK:
//                            session.setBusiness(null);
//                            session.setAgent(null);
//                            break;
//                        case EMAIL:
//                            session.setBusiness(null);
//                            session.setAgent(null);
//                            session.setSignInMethod(EMAIL);
//                            break;
//                    }

                    startActivity(new Intent(CreateShopper.this, Main3Activity.class));
                   // startActivity(new Intent(CreateShopper.this, Email_Login.class));

                    finish();
                } else {
                    Toast toast = Toast.makeText(CreateShopper.this, "Try again later!", Toast.LENGTH_SHORT);
                    toast.setGravity(Gravity.CENTER, 0, 0);
                    toast.show();
                }
            }

            @Override
            public void onFailure(Call<Shopper> call, Throwable t) {
                t.printStackTrace();
            }
        });
    }

}
