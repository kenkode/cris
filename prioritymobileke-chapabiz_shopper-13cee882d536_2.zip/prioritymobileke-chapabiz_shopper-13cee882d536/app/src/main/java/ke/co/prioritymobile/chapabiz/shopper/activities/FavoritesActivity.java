package ke.co.prioritymobile.chapabiz.shopper.activities;

import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.design.widget.BottomNavigationView;
import android.support.design.widget.FloatingActionButton;
import android.support.v7.app.AppCompatActivity;
import android.view.Gravity;
import android.view.MenuItem;
import android.view.View;
import android.widget.GridView;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.auth.api.signin.GoogleSignInClient;

import java.util.ArrayList;

import ke.co.prioritymobile.chapabiz.R;
import ke.co.prioritymobile.chapabiz.activities.Email_Login;
import ke.co.prioritymobile.chapabiz.activities.Main3Activity;
import ke.co.prioritymobile.chapabiz.activities.RequestPwdReset;
import ke.co.prioritymobile.chapabiz.adapters.FavGridAdapter;
import ke.co.prioritymobile.chapabiz.adapters.InterestGridAdapter;
import ke.co.prioritymobile.chapabiz.helpers.BottomNavigationViewHelper;
import ke.co.prioritymobile.chapabiz.helpers.CbSession;
import ke.co.prioritymobile.chapabiz.retrofit.RetrofitSetup;
import ke.co.prioritymobile.chapabiz.shopper.adapters.QuickInterestAdapter;
import ke.co.prioritymobile.chapabiz.shopper.entities.Business;
import ke.co.prioritymobile.chapabiz.shopper.entities.BusinessDets;
import ke.co.prioritymobile.chapabiz.shopper.entities.InterestDetail;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

/**
 * Created by Millie Agallo on 5/30/2018.
 */

public class FavoritesActivity extends AppCompatActivity implements QuickInterestAdapter.Clicked {

    private TextView mTextMessage;

    private boolean isInFront;
    private GoogleSignInClient googleSignInClient;
    private CbSession session;

    private BottomNavigationView.OnNavigationItemSelectedListener mOnNavigationItemSelectedListener
            = new BottomNavigationView.OnNavigationItemSelectedListener() {

        @Override
        public boolean onNavigationItemSelected(@NonNull MenuItem item) {
            switch (item.getItemId()) {
                case R.id.navigation_home:
                    //  mTextMessage.setText(R.string.title_home);
                    Intent jobz = new Intent(FavoritesActivity.this, Main3Activity.class);
                    startActivity(jobz);
                    return false;
                case R.id.navigation_search:
                    //  mTextMessage.setText(R.string.title_dashboard);
                    Intent job1 = new Intent(FavoritesActivity.this, ChapaBiz.class);
                    startActivity(job1);
                    return true;
                case R.id.navigation_favorites:
                    //  mTextMessage.setText(R.string.title_notifications);
                    Intent joboneIntent = new Intent(FavoritesActivity.this, FavoritesActivity.class);
                    startActivity(joboneIntent);
                    return true;
                case R.id.navigation_profile:
                    // mTextMessage.setText(R.string.title_notifications);
                    Intent jobz2 = new Intent(FavoritesActivity.this, ProfileActivity.class);
                    startActivity(jobz2);
                    return true;
            }
            return true;
        }
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_favorites);

        session = new CbSession(this);

        mTextMessage = (TextView) findViewById(R.id.message);
        BottomNavigationView navigation = (BottomNavigationView) findViewById(R.id.navigation);
        navigation.setOnNavigationItemSelectedListener(mOnNavigationItemSelectedListener);

        BottomNavigationView bottomNavigationView = (BottomNavigationView) findViewById(R.id.navigation);
        BottomNavigationViewHelper.disableShiftMode(bottomNavigationView);

        final ProgressBar progressBar = findViewById(R.id.progress_bar);

        FloatingActionButton imageView = (FloatingActionButton) findViewById(R.id.fab);

        CbSession session = new CbSession(this);
        final GridView gridView = (GridView)findViewById(R.id.gridview);


        imageView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(FavoritesActivity.this, ViewShopperBizFavorites.class));
            }
        });



        Call<ArrayList<BusinessDets>> interestsCall = RetrofitSetup.retrofitInterface.getCategoriestest(session.getShopper().getId());
        interestsCall.enqueue(new Callback<ArrayList<BusinessDets>>() {
            @Override
            public void onResponse(Call<ArrayList<BusinessDets>> call, Response<ArrayList<BusinessDets>> response) {
                progressBar.setVisibility(View.GONE);
                if(response.isSuccessful()) {
                    ArrayList<BusinessDets> interests = response.body();
                    FavGridAdapter interestAdapter = new FavGridAdapter(FavoritesActivity.this, interests);
                    gridView.setAdapter(interestAdapter);
                }else {
                    Toast toast = Toast.makeText(FavoritesActivity.this, "Interests could not be loaded at the moment", Toast.LENGTH_SHORT);
                    toast.setGravity(Gravity.CENTER, 0, 0);
                    toast.show();
                }
            }

            @Override
            public void onFailure(Call<ArrayList<BusinessDets>> call, Throwable t) {
                progressBar.setVisibility(View.GONE);
                t.printStackTrace();
            }
        });

    }

    @Override
    public void interestClicked(int interest) {

    }


}
