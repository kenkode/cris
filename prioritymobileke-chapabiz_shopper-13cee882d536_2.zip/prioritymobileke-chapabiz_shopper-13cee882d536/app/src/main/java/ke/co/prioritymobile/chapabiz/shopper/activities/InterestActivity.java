package ke.co.prioritymobile.chapabiz.shopper.activities;

import android.content.Intent;
import android.support.annotation.NonNull;
import android.support.design.widget.BottomNavigationView;
import android.support.v4.view.MenuItemCompat;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.GridLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.support.v7.widget.SearchView;
import android.view.Gravity;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.GridView;
import android.widget.ListView;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.auth.api.signin.GoogleSignInClient;

import java.util.ArrayList;

import ke.co.prioritymobile.chapabiz.R;
import ke.co.prioritymobile.chapabiz.activities.Main3Activity;
import ke.co.prioritymobile.chapabiz.adapters.InterestGridAdapter;
import ke.co.prioritymobile.chapabiz.helpers.BottomNavigationViewHelper;
import ke.co.prioritymobile.chapabiz.helpers.CbSession;
import ke.co.prioritymobile.chapabiz.retrofit.RetrofitSetup;
import ke.co.prioritymobile.chapabiz.shopper.adapters.InterestAdapter;
import ke.co.prioritymobile.chapabiz.shopper.adapters.QuickInterestAdapter;
import ke.co.prioritymobile.chapabiz.shopper.adapters.QuickInterestAdapter3f;
import ke.co.prioritymobile.chapabiz.shopper.entities.Interest;
import ke.co.prioritymobile.chapabiz.shopper.entities.InterestDetail;
import ke.co.prioritymobile.chapabiz.shopper.entities.ShopperFav;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class InterestActivity extends AppCompatActivity implements QuickInterestAdapter.Clicked {

    private TextView mTextMessage;

    private boolean isInFront;
    private GoogleSignInClient googleSignInClient;
    private CbSession session;

    private BottomNavigationView.OnNavigationItemSelectedListener mOnNavigationItemSelectedListener
            = new BottomNavigationView.OnNavigationItemSelectedListener() {

        @Override
        public boolean onNavigationItemSelected(@NonNull MenuItem item) {
            switch (item.getItemId()) {
                case R.id.navigation_home:
                  //  mTextMessage.setText(R.string.title_home);
                    Intent jobz = new Intent(InterestActivity.this, Main3Activity.class);
                    startActivity(jobz);
                    return false;
                case R.id.navigation_search:
                    //  mTextMessage.setText(R.string.title_dashboard);
                    Intent job1 = new Intent(InterestActivity.this, ChapaBiz.class);
                    startActivity(job1);
                    return true;
                case R.id.navigation_favorites:
                    //  mTextMessage.setText(R.string.title_notifications);
                    Intent joboneIntent = new Intent(InterestActivity.this, InterestActivity.class);
                    startActivity(joboneIntent);
                    return true;
                case R.id.navigation_profile:
                    // mTextMessage.setText(R.string.title_notifications);
                    Intent jobz2 = new Intent(InterestActivity.this, ProfileActivity.class);
                    startActivity(jobz2);
                    return true;
            }
            return true;
        }
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_interest);

        session = new CbSession(this);

        mTextMessage = (TextView) findViewById(R.id.message);
        BottomNavigationView navigation = (BottomNavigationView) findViewById(R.id.navigation);
        navigation.setOnNavigationItemSelectedListener(mOnNavigationItemSelectedListener);

        BottomNavigationView bottomNavigationView = (BottomNavigationView) findViewById(R.id.navigation);
        BottomNavigationViewHelper.disableShiftMode(bottomNavigationView);

        final ProgressBar progressBar = findViewById(R.id.progress_bar);

        CbSession session = new CbSession(this);
        final GridView gridView = (GridView)findViewById(R.id.gridview);


        Call<ArrayList<InterestDetail>> interestsCall = RetrofitSetup.retrofitInterface.getCategories(session.getShopper().getId());
        interestsCall.enqueue(new Callback<ArrayList<InterestDetail>>() {
            @Override
            public void onResponse(Call<ArrayList<InterestDetail>> call, Response<ArrayList<InterestDetail>> response) {
                progressBar.setVisibility(View.GONE);
                if(response.isSuccessful()) {
                    ArrayList<InterestDetail> interests = response.body();
                    InterestGridAdapter interestAdapter = new InterestGridAdapter(InterestActivity.this, interests);
                    gridView.setAdapter(interestAdapter);
                }else {
                    Toast toast = Toast.makeText(InterestActivity.this, "Interests could not be loaded at the moment", Toast.LENGTH_SHORT);
                    toast.setGravity(Gravity.CENTER, 0, 0);
                    toast.show();
                }
            }

            @Override
            public void onFailure(Call<ArrayList<InterestDetail>> call, Throwable t) {
                progressBar.setVisibility(View.GONE);
                t.printStackTrace();
            }
        });
       // final RecyclerView recyclerView = findViewById(R.id.interest_list);

//        final GridView gridView = (GridView)findViewById(R.id.gridview);
//
////        GridLayoutManager gridLayoutManager = new GridLayoutManager(this, 3);
////        recyclerView.setLayoutManager(gridLayoutManager);
//
//        Call<ArrayList<ShopperFav>> arrayListCall = RetrofitSetup.retrofitInterface.getShopperBiz(session.getShopper().getId());
//        arrayListCall.enqueue(new Callback<ArrayList<ShopperFav>>() {
//            @Override
//            public void onResponse(Call<ArrayList<ShopperFav>> call, Response<ArrayList<ShopperFav>> response) {
//                if (response.isSuccessful()) {
//                    ArrayList<ShopperFav> interests = response.body();
//                    InterestGridAdapter quickInterestAdapter = new InterestGridAdapter(InterestActivity.this, interests);
//                    gridView.setAdapter(quickInterestAdapter);
//
////                    QuickInterestAdapter3f quickInterestAdapter = new QuickInterestAdapter3f(InterestActivity.this, interests);
////                    recyclerView.setAdapter(quickInterestAdapter);
//                }
//            }
//
//            @Override
//            public void onFailure(Call<ArrayList<ShopperFav>> call, Throwable t) {
//
//            }
//        });

    }

//    @Override
//    public boolean onCreateOptionsMenu(Menu menu) {
//        getMenuInflater().inflate(R.menu.chapa_biz, menu);
//        MenuItem search = menu.findItem(R.id.menu_search);
//
//        SearchView searchView  = (SearchView) MenuItemCompat.getActionView(search);
//
//
//        return true;
//    }


    @Override
    public void interestClicked(int interest) {

    }


}
