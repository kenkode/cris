package ke.co.prioritymobile.chapabiz.shopper.activities;


import android.Manifest;
import android.app.DatePickerDialog;
import android.app.Dialog;
import android.app.ProgressDialog;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.media.session.MediaSession;
import android.net.Uri;
import android.support.design.widget.Snackbar;
import android.support.design.widget.TextInputLayout;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.CardView;
import android.text.TextUtils;
import android.util.Log;
import android.util.Patterns;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import com.google.gson.Gson;
import com.makeramen.roundedimageview.RoundedImageView;
import com.squareup.picasso.Picasso;

import java.io.FileNotFoundException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.Locale;

import ke.co.prioritymobile.chapabiz.R;
import ke.co.prioritymobile.chapabiz.activities.Main3Activity;
import ke.co.prioritymobile.chapabiz.activities.ShopperLogin;
import ke.co.prioritymobile.chapabiz.shopper.entities.Business;
import ke.co.prioritymobile.chapabiz.entities.User;
import ke.co.prioritymobile.chapabiz.helpers.GEPreference;
import ke.co.prioritymobile.chapabiz.helpers.UserAuth;
import ke.co.prioritymobile.chapabiz.retrofit.RetrofitInterface;
import ke.co.prioritymobile.chapabiz.shopper.entities.Shopper;
import ke.co.prioritymobile.chapabiz.entities.County;
import ke.co.prioritymobile.chapabiz.entities.Response;
import ke.co.prioritymobile.chapabiz.helpers.CbSession;
import ke.co.prioritymobile.chapabiz.retrofit.RetrofitSetup;
import ke.co.prioritymobile.chapabiz.shopper.entities.InterestDetail;
import ke.co.prioritymobile.chapabiz.shopper.entities.Shopper;
import retrofit2.Call;
import retrofit2.Callback;


//import butterknife.ButterKnife;
//import butterknife.InjectView;
import retrofit2.Call;
import retrofit2.Callback;

public class NewUser  extends AppCompatActivity {

    private TextInputLayout first_name,last_name, email, phone, description;
    //    private TextView certNo;
   private Button button;
   //testing
//    private Spinner category, county;
//    private ArrayList<InterestDetail> interestDetails;
//    private ArrayList<County> counties;

    private CbSession session;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_new_user);

        session = new CbSession(this);


        first_name = (TextInputLayout) findViewById(R.id.name);
        last_name = (TextInputLayout) findViewById(R.id.phone);
        email = (TextInputLayout) findViewById(R.id.email);
        button = (Button) findViewById(R.id.submit);


        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String strName = first_name.getEditText().getText().toString();
                String strEmail = last_name.getEditText().getText().toString();
                String strPhone = email.getEditText().getText().toString();
              //  String strDesc = description.getEditText().getText().toString();
              //  int cat = category.getSelectedItemPosition();

              //  int countySelected = county.getSelectedItemPosition();

                if (isEmpty(new String[]{strEmail, strName, strPhone})) {
                    Toast.makeText(NewUser.this, "Include all fields", Toast.LENGTH_SHORT).show();
                    return;
                }

                final ProgressDialog progressDialog = new ProgressDialog(NewUser.this);
                progressDialog.setCancelable(false);
                progressDialog.setMessage("Signing up...");
                progressDialog.setIndeterminate(true);
                progressDialog.show();

                final Shopper shopper = new Shopper();
                shopper.setName(strName);
                shopper.setEmail(strEmail);
                shopper.setPhone(strPhone);
//                business.setDescription(strDesc);
//                business.setCounty(countyId);
//                business.setCategory(String.valueOf(interestDetail.getId()));
               // business.setOperationsSince(String.valueOf(new SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()).format(calendar.getTime())));
                String bsJson = new Gson().toJson(shopper);

                Call<Response> call1 = RetrofitSetup.retrofitInterface.signUpNewUser(bsJson);
                call1.enqueue(new Callback<Response>() {
                    @Override
                    public void onResponse(Call<Response> call, retrofit2.Response<Response> response) {
                        if (response.isSuccessful()) {
                            Response response1 = response.body();

                            switch (response1.getStatus()) {
                                case 200:
                                    session.setShopper(response1.getShopper());
                                    startActivity(new Intent(NewUser.this, ShopperLogin.class));
                                    finish();
                                    break;
                                case 301:
                                    break;
                                case 302:
                                    break;
                            }
                            Toast.makeText(NewUser.this, response1.getMessage(), Toast.LENGTH_SHORT).show();
                        }
                        progressDialog.dismiss();
                    }

                    @Override
                    public void onFailure(Call<Response> call, Throwable t) {
                        t.printStackTrace();
                        progressDialog.dismiss();
                    }
                });

//                String strName;
            }
        });

    }

    private boolean isEmpty(String[] fields) {
        for (String field :
                fields) {
            if (TextUtils.isEmpty(field)) {
                return true;
            }
        }
        return false;
    }

}
