package ke.co.prioritymobile.chapabiz.shopper.activities;

import android.content.Intent;
import android.os.Bundle;
import android.support.design.widget.FloatingActionButton;
import android.support.design.widget.Snackbar;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.text.InputType;
import android.text.TextUtils;
import android.util.Log;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.facebook.CallbackManager;
import com.google.gson.Gson;

import ke.co.prioritymobile.chapabiz.R;
import ke.co.prioritymobile.chapabiz.activities.Email_Login;
import ke.co.prioritymobile.chapabiz.activities.Main3Activity;
import ke.co.prioritymobile.chapabiz.helpers.CbSession;
import ke.co.prioritymobile.chapabiz.shopper.entities.Shopper;

public class NewUserLogin extends AppCompatActivity {

    private CallbackManager callbackManager;
    private static final String EMAIL = "email";
    private EditText username, password;

    CbSession session;

    Button createAccount;

    TextView login;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_new_user_login);
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);

        session = new CbSession(this);

        createAccount = (Button) findViewById(R.id.create_account);

        login = (TextView) findViewById(R.id.login);

        login.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(NewUserLogin.this, Email_Login.class));
            }
        });

        login = (TextView) findViewById(R.id.login);

        username = (EditText) findViewById(R.id.username);
        password = (EditText) findViewById(R.id.password);

        createAccount.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String m = username.getText().toString();
                String p = password.getText().toString();

                if (TextUtils.isEmpty(m) || TextUtils.isEmpty(p)) {
                    Toast.makeText(NewUserLogin.this, "Provide credentials", Toast.LENGTH_SHORT).show();
                    return;
                }

                Shopper shopper = new Shopper();
                String user = username.getText().toString().trim();
                String pass = password.getText().toString().trim();

                if (TextUtils.isEmpty(user) || TextUtils.isEmpty(pass)) {
                    Toast toast = Toast.makeText(NewUserLogin.this, "Provide credentials", Toast.LENGTH_SHORT);
                    toast.setGravity(Gravity.CENTER, 0, 0);
                    toast.show();
                    return;
                }

                shopper.setPassword(pass);
                shopper.setEmail(user);

                Log.e("error", new Gson().toJson(shopper));

                //  attemptSignIn(new Gson().toJson(shopper), EMAIL);
                //  break;
                setupEmailLogin();
            }

        });

        updateInput();

    }


    @Override
    protected void onStart() {
        super.onStart();

        if (session.getShopper() != null) {
            startActivity(new Intent(NewUserLogin.this, Main3Activity.class));
            finish();
        }

    }

    public void updateInput() {

        password.setHint("Password");
        username.setHint("Email");
        username.setInputType(InputType.TYPE_CLASS_TEXT);

    }
    private void setupEmailLogin() {
        session.setSignInMethod(EMAIL);
        startActivity(new Intent(NewUserLogin.this, Main3Activity.class));
        finish();
    }

}
