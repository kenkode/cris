//package ke.co.prioritymobile.chapabiz.shopper.activities;
//
//import android.app.SearchManager;
//import android.content.Context;
//import android.content.Intent;
//import android.database.MatrixCursor;
//import android.os.Bundle;
//import android.provider.BaseColumns;
//import android.support.annotation.NonNull;
//import android.support.design.widget.BottomNavigationView;
//import android.support.design.widget.BottomSheetBehavior;
//import android.support.v4.content.ContextCompat;
//import android.support.v4.view.MenuItemCompat;
//import android.support.v4.widget.CursorAdapter;
//import android.support.v4.widget.SimpleCursorAdapter;
//import android.support.v7.app.AppCompatActivity;
//import android.support.v7.widget.GridLayoutManager;
//import android.support.v7.widget.LinearLayoutManager;
//import android.support.v7.widget.RecyclerView;
//import android.support.v7.widget.SearchView;
//import android.view.Menu;
//import android.view.MenuItem;
//import android.view.View;
//import android.widget.GridView;
//import android.widget.TextView;
//
//import com.facebook.AccessToken;
//import com.facebook.login.LoginManager;
//import com.google.android.gms.auth.api.signin.GoogleSignIn;
//import com.google.android.gms.auth.api.signin.GoogleSignInClient;
//import com.google.android.gms.auth.api.signin.GoogleSignInOptions;
//import com.makeramen.roundedimageview.RoundedImageView;
//import com.squareup.picasso.Picasso;
//
//import java.util.ArrayList;
//
//import ke.co.prioritymobile.chapabiz.R;
//import ke.co.prioritymobile.chapabiz.activities.ShopperLogin;
//import ke.co.prioritymobile.chapabiz.adapters.FavGridAdapter;
//import ke.co.prioritymobile.chapabiz.adapters.InterestGridAdapter;
//import ke.co.prioritymobile.chapabiz.helpers.BottomNavigationViewHelper;
//import ke.co.prioritymobile.chapabiz.helpers.CbSession;
//import ke.co.prioritymobile.chapabiz.retrofit.RetrofitSetup;
//import ke.co.prioritymobile.chapabiz.shopper.adapters.QuickInterestAdapter;
//import ke.co.prioritymobile.chapabiz.shopper.adapters.QuickInterestAdapter2;
//import ke.co.prioritymobile.chapabiz.shopper.entities.InterestDetail;
//import ke.co.prioritymobile.chapabiz.shopper.entities.ShopperFav;
//import ke.co.prioritymobile.chapabiz.shopper.entities.SubCategoryDetail;
//import retrofit2.Call;
//import retrofit2.Callback;
//import retrofit2.Response;
//
//public class ShopperHome extends AppCompatActivity implements QuickInterestAdapter2.Clicked {
//
//    private TextView mTextMessage;
//    private SearchView searchView;
//    private boolean isInFront;
//    private GoogleSignInClient googleSignInClient;
//    private CbSession session;
//    private ArrayList<SubCategoryDetail> suggestionInterest, updatedSuggestionList;
//
//    private BottomNavigationView.OnNavigationItemSelectedListener mOnNavigationItemSelectedListener
//            = new BottomNavigationView.OnNavigationItemSelectedListener() {
//
//        @Override
//        public boolean onNavigationItemSelected(@NonNull MenuItem item) {
//            switch (item.getItemId()) {
//                case R.id.navigation_home:
//                    mTextMessage.setText(R.string.title_home);
//                    return true;
//                case R.id.navigation_search:
//                  //  mTextMessage.setText(R.string.title_dashboard);
//                    Intent job1 = new Intent(ShopperHome.this, ChapaBiz.class);
//                    startActivity(job1);
//                    return true;
//                case R.id.navigation_favorites:
//                  //  mTextMessage.setText(R.string.title_notifications);
//                    Intent joboneIntent = new Intent(ShopperHome.this, InterestActivity.class);
//                    startActivity(joboneIntent);
//                    return true;
//                case R.id.navigation_profile:
//                   // mTextMessage.setText(R.string.title_notifications);
//                    Intent jobz = new Intent(ShopperHome.this, ProfileActivity.class);
//                    startActivity(jobz);
//                    return true;
//            }
//            return false;
//        }
//    };
//
//    @Override
//    protected void onCreate(Bundle savedInstanceState) {
//        super.onCreate(savedInstanceState);
//        setContentView(R.layout.activity_shopper_home);
//
//        session = new CbSession(this);
//
//        mTextMessage = (TextView) findViewById(R.id.message);
//        BottomNavigationView navigation = (BottomNavigationView) findViewById(R.id.navigation);
//        navigation.setOnNavigationItemSelectedListener(mOnNavigationItemSelectedListener);
//
//        BottomNavigationView bottomNavigationView = (BottomNavigationView) findViewById(R.id.navigation);
//        BottomNavigationViewHelper.disableShiftMode(bottomNavigationView);
//
//
//        CbSession session = new CbSession(this);
//        try {
//            TextView name = findViewById(R.id.name);
//
//            name.setText(session.getShopper().getName());
//
//            // ImageView imageView = findViewById(R.id.im1);
//            RoundedImageView imageView = findViewById(R.id.im1);
//            Picasso.with(this).load(session.getShopper().getPicture())
//                    .placeholder(ContextCompat.getDrawable(this, R.drawable.user))
//                    .into(imageView);
//        } catch (Exception e) {
//            if (session.getSignInMethod() == CbSession.FACEBOOK) {
//
//            }
//        }
//
//        //sub category 1
//        final GridView recyclerView = findViewById(R.id.subcategorylist1);
//      //  GridLayoutManager gridLayoutManager = new GridLayoutManager(this, 5);
//      //  recyclerView.setLayoutManager(gridLayoutManager);
//
//        Call<ArrayList<SubCategoryDetail>> arrayListCall = RetrofitSetup.retrofitInterface.getSubCategories1();
//        arrayListCall.enqueue(new Callback<ArrayList<SubCategoryDetail>>() {
//            @Override
//            public void onResponse(Call<ArrayList<SubCategoryDetail>> call, Response<ArrayList<SubCategoryDetail>> response) {
//                if (response.isSuccessful()) {
//                    ArrayList<SubCategoryDetail> interests1 = response.body();
//
//                    FavGridAdapter quickInterestAdapter2 = new FavGridAdapter(ShopperHome.this, interests1);
//                    recyclerView.setAdapter(quickInterestAdapter2);
//                }
//            }
//            @Override
//            public void onFailure(Call<ArrayList<SubCategoryDetail>> call, Throwable t) {
//
//            }
//        });
//
//        //  //sub category 2
//        final RecyclerView recyclerView2 = findViewById(R.id.subcategorylist2);
//        GridLayoutManager gridLayoutManager2 = new GridLayoutManager(this, 7);
//        recyclerView2.setLayoutManager(gridLayoutManager2);
//
//        Call<ArrayList<SubCategoryDetail>> arrayListCall2 = RetrofitSetup.retrofitInterface.getSubCategories2();
//        arrayListCall2.enqueue(new Callback<ArrayList<SubCategoryDetail>>() {
//            @Override
//            public void onResponse(Call<ArrayList<SubCategoryDetail>> call2, Response<ArrayList<SubCategoryDetail>> response) {
//                if (response.isSuccessful()) {
//                    ArrayList<SubCategoryDetail> interests2 = response.body();
//
//                    QuickInterestAdapter2 quickInterestAdapter2 = new QuickInterestAdapter2(ShopperHome.this, interests2);
//                    recyclerView2.setAdapter(quickInterestAdapter2);
//                }
//            }
//            @Override
//            public void onFailure(Call<ArrayList<SubCategoryDetail>> call2, Throwable t) {
//
//            }
//        });
//
//        //sub category 3
//
//        final RecyclerView recyclerView3 = findViewById(R.id.subcategorylist3);
//        GridLayoutManager gridLayoutManager3 = new GridLayoutManager(this, 10);
//        recyclerView3.setLayoutManager(gridLayoutManager3);
//
//        Call<ArrayList<SubCategoryDetail>> arrayListCall3 = RetrofitSetup.retrofitInterface.getSubCategories3();
//        arrayListCall3.enqueue(new Callback<ArrayList<SubCategoryDetail>>() {
//            @Override
//            public void onResponse(Call<ArrayList<SubCategoryDetail>> call3, Response<ArrayList<SubCategoryDetail>> response) {
//                if (response.isSuccessful()) {
//                    ArrayList<SubCategoryDetail> interests3 = response.body();
//
//                    QuickInterestAdapter2 quickInterestAdapter3 = new QuickInterestAdapter2(ShopperHome.this, interests3);
//                    recyclerView3.setAdapter(quickInterestAdapter3);
//                }
//            }
//            @Override
//            public void onFailure(Call<ArrayList<SubCategoryDetail>> call3, Throwable t) {
//
//            }
//        });
//
//        //sub cat 4
//
//        final RecyclerView recyclerView4 = findViewById(R.id.subcategorylist4);
//        GridLayoutManager gridLayoutManager4 = new GridLayoutManager(this, 4);
//        recyclerView4.setLayoutManager(gridLayoutManager4);
//
//        Call<ArrayList<SubCategoryDetail>> arrayListCall4 = RetrofitSetup.retrofitInterface.getSubCategories4();
//        arrayListCall4.enqueue(new Callback<ArrayList<SubCategoryDetail>>() {
//            @Override
//            public void onResponse(Call<ArrayList<SubCategoryDetail>> call4, Response<ArrayList<SubCategoryDetail>> response) {
//                if (response.isSuccessful()) {
//                    ArrayList<SubCategoryDetail> interests4 = response.body();
//
//                    QuickInterestAdapter2 quickInterestAdapter4 = new QuickInterestAdapter2(ShopperHome.this, interests4);
//                    recyclerView4.setAdapter(quickInterestAdapter4);
//                }
//            }
//            @Override
//            public void onFailure(Call<ArrayList<SubCategoryDetail>> call4, Throwable t) {
//
//            }
//        });
//
//       // sub cat 5
//
//        final RecyclerView recyclerView5 = findViewById(R.id.subcategorylist5);
//        GridLayoutManager gridLayoutManager5 = new GridLayoutManager(this, 10);
//       // recyclerView.setLayoutManager(gridLayoutManager5);
//
//        Call<ArrayList<SubCategoryDetail>> arrayListCall5 = RetrofitSetup.retrofitInterface.getSubCategories5();
//        arrayListCall5.enqueue(new Callback<ArrayList<SubCategoryDetail>>() {
//            @Override
//            public void onResponse(Call<ArrayList<SubCategoryDetail>> call5, Response<ArrayList<SubCategoryDetail>> response) {
//                if (response.isSuccessful()) {
//                    ArrayList<SubCategoryDetail> interests5 = response.body();
//
//                    QuickInterestAdapter2 quickInterestAdapter5 = new QuickInterestAdapter2(ShopperHome.this, interests5);
//                    recyclerView5.setAdapter(quickInterestAdapter5);
//                }
//            }
//            @Override
//            public void onFailure(Call<ArrayList<SubCategoryDetail>> call5, Throwable t) {
//
//            }
//        });
//
//        // sub cat 6
//
//        final RecyclerView recyclerView6 = findViewById(R.id.subcategorylist6);
//        GridLayoutManager gridLayoutManager6 = new GridLayoutManager(this, 10);
//        recyclerView6.setLayoutManager(gridLayoutManager6);
//
//        Call<ArrayList<SubCategoryDetail>> arrayListCall6 = RetrofitSetup.retrofitInterface.getSubCategories5();
//        arrayListCall6.enqueue(new Callback<ArrayList<SubCategoryDetail>>() {
//            @Override
//            public void onResponse(Call<ArrayList<SubCategoryDetail>> call6, Response<ArrayList<SubCategoryDetail>> response) {
//                if (response.isSuccessful()) {
//                    ArrayList<SubCategoryDetail> interests6 = response.body();
//
//                    QuickInterestAdapter2 quickInterestAdapter6 = new QuickInterestAdapter2(ShopperHome.this, interests6);
//                    recyclerView6.setAdapter(quickInterestAdapter6);
//                }
//            }
//            @Override
//            public void onFailure(Call<ArrayList<SubCategoryDetail>> call6, Throwable t) {
//
//            }
//        });
//
//        //sub cat 7
//
//        final RecyclerView recyclerView7 = findViewById(R.id.subcategorylist7);
//        GridLayoutManager gridLayoutManager7 = new GridLayoutManager(this, 10);
//        recyclerView7.setLayoutManager(gridLayoutManager7);
//
//        Call<ArrayList<SubCategoryDetail>> arrayListCall7 = RetrofitSetup.retrofitInterface.getSubCategories5();
//        arrayListCall7.enqueue(new Callback<ArrayList<SubCategoryDetail>>() {
//            @Override
//            public void onResponse(Call<ArrayList<SubCategoryDetail>> call7, Response<ArrayList<SubCategoryDetail>> response) {
//                if (response.isSuccessful()) {
//                    ArrayList<SubCategoryDetail> interests7 = response.body();
//
//                    QuickInterestAdapter2 quickInterestAdapter7 = new QuickInterestAdapter2(ShopperHome.this, interests7);
//                    recyclerView7.setAdapter(quickInterestAdapter7);
//                }
//            }
//            @Override
//            public void onFailure(Call<ArrayList<SubCategoryDetail>> call7, Throwable t) {
//
//            }
//        });
//
//        //sub cat 8
//
//        final RecyclerView recyclerView8 = findViewById(R.id.subcategorylist8);
//        GridLayoutManager gridLayoutManager8 = new GridLayoutManager(this, 10);
//        recyclerView8.setLayoutManager(gridLayoutManager8);
//
//        Call<ArrayList<SubCategoryDetail>> arrayListCall8 = RetrofitSetup.retrofitInterface.getSubCategories5();
//        arrayListCall8.enqueue(new Callback<ArrayList<SubCategoryDetail>>() {
//            @Override
//            public void onResponse(Call<ArrayList<SubCategoryDetail>> call8, Response<ArrayList<SubCategoryDetail>> response) {
//                if (response.isSuccessful()) {
//                    ArrayList<SubCategoryDetail> interests8 = response.body();
//
//                    QuickInterestAdapter2 quickInterestAdapter8 = new QuickInterestAdapter2(ShopperHome.this, interests8);
//                    recyclerView8.setAdapter(quickInterestAdapter8);
//                }
//            }
//            @Override
//            public void onFailure(Call<ArrayList<SubCategoryDetail>> call8, Throwable t) {
//
//            }
//        });
//
//        //sub cat 9
//
//        final RecyclerView recyclerView9 = findViewById(R.id.subcategorylist9);
//        GridLayoutManager gridLayoutManager9 = new GridLayoutManager(this, 10);
//        recyclerView9.setLayoutManager(gridLayoutManager9);
//
//        Call<ArrayList<SubCategoryDetail>> arrayListCall9 = RetrofitSetup.retrofitInterface.getSubCategories5();
//        arrayListCall9.enqueue(new Callback<ArrayList<SubCategoryDetail>>() {
//            @Override
//            public void onResponse(Call<ArrayList<SubCategoryDetail>> call9, Response<ArrayList<SubCategoryDetail>> response) {
//                if (response.isSuccessful()) {
//                    ArrayList<SubCategoryDetail> interests9 = response.body();
//
//                    QuickInterestAdapter2 quickInterestAdapter9 = new QuickInterestAdapter2(ShopperHome.this, interests9);
//                    recyclerView9.setAdapter(quickInterestAdapter9);
//                }
//            }
//            @Override
//            public void onFailure(Call<ArrayList<SubCategoryDetail>> call9, Throwable t) {
//
//            }
//        });
//    }
//
//    @Override
//    public boolean onCreateOptionsMenu(Menu menu) {
//        getMenuInflater().inflate(R.menu.chapa_biz, menu);
//        MenuItem search = menu.findItem(R.id.menu_search);
//
//        SearchView searchView  = (SearchView) MenuItemCompat.getActionView(search);
//
//
//                return true;
//            }
//
//
//    @Override
//    public void interestClicked(int interest) {
//
//    }
//
//    public void card1(View view)
//    {
//      //  Intent joboneIntent = new Intent(ShopperHome.this, UserHome.class);
//      //  startActivity(joboneIntent);
//
//    }
//    //interests
//    public void card2(View view)
//    {
//        Intent joboneIntent = new Intent(ShopperHome.this, InterestActivity.class);
//        startActivity(joboneIntent);
//
//    }
//    //bookmarks //find biz
//    public void card3(View view)
//    {
//        Intent joboneIntent = new Intent(ShopperHome.this, ChapaBiz.class);
//        startActivity(joboneIntent);
//
//    }
//    //logout
//    public void card4(View view)
//    {
////        Intent joboneIntent = new Intent(UserHome.this, UserHome.class);
////        startActivity(joboneIntent);
//
//        logout();
//    }
//    //profile
//    public void textview(View view)
//    {
//        Intent jobz = new Intent(ShopperHome.this, ProfileActivity.class);
//        startActivity(jobz);
//    }
//    private void logout() {
//
//        GoogleSignInOptions gso = new GoogleSignInOptions.Builder(GoogleSignInOptions.DEFAULT_SIGN_IN)
//                .requestEmail()
//                .build();
//        googleSignInClient = GoogleSignIn.getClient(this, gso);
//        if (googleSignInClient != null) {
//            googleSignInClient.signOut();
//        }
//        boolean loggedIn = AccessToken.getCurrentAccessToken() != null;
//        if (loggedIn) {
//            LoginManager.getInstance().logOut();
//        }
//        session.clear();
//        startActivity(new Intent(ShopperHome.this, ShopperLogin.class));
//    }
//
//}
