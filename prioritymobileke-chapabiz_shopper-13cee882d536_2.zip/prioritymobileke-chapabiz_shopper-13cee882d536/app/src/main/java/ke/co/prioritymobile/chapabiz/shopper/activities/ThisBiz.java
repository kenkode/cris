package ke.co.prioritymobile.chapabiz.shopper.activities;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.support.design.widget.FloatingActionButton;
import android.support.design.widget.Snackbar;
import android.support.v4.content.ContextCompat;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.util.Log;
import android.view.Gravity;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.bumptech.glide.Glide;

import ke.co.prioritymobile.chapabiz.R;
import ke.co.prioritymobile.chapabiz.shopper.entities.Business;
import ke.co.prioritymobile.chapabiz.chat.ChatRoomActivity;

public class ThisBiz extends AppCompatActivity {

    private TextView companyName, subCompanyName, companyLocation, distance, availability, verified, description;
    private TextView  phone, direction, message;

    private Business currentBusiness;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_this_biz);
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        getIncomingIntent();
    }

    private void getIncomingIntent(){
       // Log.d(TAG, "getIncomingIntent: checking for incoming intents.");

        if(getIntent().hasExtra("business_name") ){
           // Log.d(TAG, "getIncomingIntent: found intent extras.");

            String imageName = getIntent().getStringExtra("business_name");
           // String imageName = getIntent().getStringExtra("image_name");

            setImage(imageName);
        }
    }


    private void setImage(String imageName){
     //   Log.d(TAG, "setImage: setting te image and name to widgets.");

        TextView name = findViewById(R.id.interest);
        name.setText(imageName);

//        ImageView image = findViewById(R.id.image);
//        Glide.with(this)
//                .asBitmap()
//                .load(imageUrl)
//                .into(image);
    }

}


















