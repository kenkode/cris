package ke.co.prioritymobile.chapabiz.shopper.activities;

import android.content.Intent;
import android.os.Bundle;
import android.support.design.widget.FloatingActionButton;
import android.support.design.widget.Snackbar;
import android.support.v4.content.ContextCompat;
import android.view.View;
import android.support.design.widget.NavigationView;
import android.support.v4.view.GravityCompat;
import android.support.v4.widget.DrawerLayout;
import android.support.v7.app.ActionBarDrawerToggle;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.view.Menu;
import android.view.MenuItem;
import android.widget.ImageView;
import android.widget.TextView;

import com.facebook.AccessToken;
import com.facebook.login.LoginManager;
import com.google.android.gms.auth.api.signin.GoogleSignIn;
import com.google.android.gms.auth.api.signin.GoogleSignInClient;
import com.google.android.gms.auth.api.signin.GoogleSignInOptions;
import com.makeramen.roundedimageview.RoundedImageView;
import com.squareup.picasso.Picasso;

import ke.co.prioritymobile.chapabiz.R;
import ke.co.prioritymobile.chapabiz.activities.ShopperLogin;
import ke.co.prioritymobile.chapabiz.entities.User;
import ke.co.prioritymobile.chapabiz.helpers.CbSession;
import ke.co.prioritymobile.chapabiz.shopper.entities.Shopper;

public class UserHome extends AppCompatActivity{
       // implements NavigationView.OnNavigationItemSelectedListener {
    private boolean isInFront;
    private GoogleSignInClient googleSignInClient;
    private CbSession session;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        setContentView(R.layout.activity_user_home);
        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

        session = new CbSession(this);

//        if(session.getUser() == null) {
//            Shopper shopper = session.getShopper();
//            String id = shopper.getId();
//            String name = shopper.getName();
//            String email = shopper.getEmail();
//            User user = new User(id, name, email);
//            session.storeUser(user);
//        }

        CbSession session = new CbSession(this);
        try {
            TextView name = findViewById(R.id.name);

            name.setText(session.getShopper().getName());

           // ImageView imageView = findViewById(R.id.im1);
            RoundedImageView imageView = findViewById(R.id.im1);
            Picasso.with(this).load(session.getShopper().getPicture())
                    .placeholder(ContextCompat.getDrawable(this, R.drawable.user))
                    .into(imageView);
        }catch (Exception e) {
            if(session.getSignInMethod() == CbSession.FACEBOOK) {

            }
        }
        FloatingActionButton fab = (FloatingActionButton) findViewById(R.id.fab);
        fab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Snackbar.make(view, "Replace with your own action", Snackbar.LENGTH_LONG)
                        .setAction("Action", null).show();
            }
        });

//        DrawerLayout drawer = (DrawerLayout) findViewById(R.id.drawer_layout);
//        ActionBarDrawerToggle toggle = new ActionBarDrawerToggle(
//                this, drawer, toolbar, R.string.navigation_drawer_open, R.string.navigation_drawer_close);
//        drawer.addDrawerListener(toggle);
//        toggle.syncState();
//
//        NavigationView navigationView = (NavigationView) findViewById(R.id.nav_view);
//        navigationView.setNavigationItemSelectedListener(this);
    }

//    @Override
//    public void onBackPressed() {
//        DrawerLayout drawer = (DrawerLayout) findViewById(R.id.drawer_layout);
//        if (drawer.isDrawerOpen(GravityCompat.START)) {
//            drawer.closeDrawer(GravityCompat.START);
//        } else {
//            super.onBackPressed();
//        }
//    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.user_home, menu);
        return true;
    }


    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.action_settings) {
            return true;
        }

        return super.onOptionsItemSelected(item);
    }
//home
    public void card1(View view)
    {
        Intent joboneIntent = new Intent(UserHome.this, UserHome.class);
        startActivity(joboneIntent);

    }
    //interests
    public void card2(View view)
    {
        Intent joboneIntent = new Intent(UserHome.this, InterestActivity.class);
        startActivity(joboneIntent);

    }
    //bookmarks //find biz
    public void card3(View view)
    {
        Intent joboneIntent = new Intent(UserHome.this, ChapaBiz.class);
        startActivity(joboneIntent);

    }
    //logout
    public void card4(View view)
    {
//        Intent joboneIntent = new Intent(UserHome.this, UserHome.class);
//        startActivity(joboneIntent);

        logout();
    }
//profile
    public void textview(View view)
    {
        Intent jobz = new Intent(UserHome.this, ProfileActivity.class);
        startActivity(jobz);
    }

//
//    @SuppressWarnings("StatementWithEmptyBody")
//    @Override
//    public boolean onNavigationItemSelected(MenuItem item) {
//        // Handle navigation view item clicks here.
//        int id = item.getItemId();
//        DrawerLayout drawer = (DrawerLayout) findViewById(R.id.drawer_layout);
//
//        if (id == R.id.home) {
//            if (isInFront) {
//                drawer.closeDrawer(GravityCompat.START);
//                return false;
//            }
//
//        } else if (id == R.id.map) {
//            startActivity(new Intent(UserHome.this, ChapaBiz.class));
//        }
//
//        else if (id == R.id.interests) {
//            startActivity(new Intent(UserHome.this, InterestActivity.class));
//        } else if (id == R.id.messages) {
////            startActivity(new Intent(ChapaBiz.this, ChatActivity.class));
//        } else if (id == R.id.logout) {
//            logout();
//        }
//
//        drawer.closeDrawer(GravityCompat.START);
//
//        return true;
//    }
    private void logout() {

        GoogleSignInOptions gso = new GoogleSignInOptions.Builder(GoogleSignInOptions.DEFAULT_SIGN_IN)
                .requestEmail()
                .build();
        googleSignInClient = GoogleSignIn.getClient(this, gso);
        if (googleSignInClient != null) {
            googleSignInClient.signOut();
        }
        boolean loggedIn = AccessToken.getCurrentAccessToken() != null;
        if (loggedIn) {
            LoginManager.getInstance().logOut();
        }
        session.clear();
        startActivity(new Intent(UserHome.this, ShopperLogin.class));
    }
}
