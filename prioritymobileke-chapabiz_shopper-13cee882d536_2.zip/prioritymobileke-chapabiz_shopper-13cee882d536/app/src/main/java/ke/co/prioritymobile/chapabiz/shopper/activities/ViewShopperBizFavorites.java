package ke.co.prioritymobile.chapabiz.shopper.activities;

import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.design.widget.BottomNavigationView;
import android.support.v4.content.ContextCompat;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.GridLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.view.MenuItem;
import android.view.View;
import android.widget.TextView;

import com.facebook.AccessToken;
import com.facebook.login.LoginManager;
import com.google.android.gms.auth.api.signin.GoogleSignIn;
import com.google.android.gms.auth.api.signin.GoogleSignInClient;
import com.google.android.gms.auth.api.signin.GoogleSignInOptions;
import com.makeramen.roundedimageview.RoundedImageView;
import com.squareup.picasso.Picasso;

import java.util.ArrayList;

import ke.co.prioritymobile.chapabiz.R;
import ke.co.prioritymobile.chapabiz.activities.Main3Activity;
import ke.co.prioritymobile.chapabiz.activities.ShopperLogin;
import ke.co.prioritymobile.chapabiz.helpers.BottomNavigationViewHelper;
import ke.co.prioritymobile.chapabiz.helpers.CbSession;
import ke.co.prioritymobile.chapabiz.retrofit.RetrofitSetup;
import ke.co.prioritymobile.chapabiz.shopper.adapters.PreferencesAdapter;
import ke.co.prioritymobile.chapabiz.shopper.adapters.UserFavAdapter;
import ke.co.prioritymobile.chapabiz.shopper.entities.BusinessDets;
import ke.co.prioritymobile.chapabiz.shopper.entities.InterestDetail;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

/**
 * Created by Millie Agallo on 5/30/2018.
 */

public class ViewShopperBizFavorites extends AppCompatActivity implements UserFavAdapter.Clicked {

    private TextView mTextMessage;

    private boolean isInFront;
    private GoogleSignInClient googleSignInClient;
    private CbSession session;

    private BottomNavigationView.OnNavigationItemSelectedListener mOnNavigationItemSelectedListener
            = new BottomNavigationView.OnNavigationItemSelectedListener() {

        @Override
        public boolean onNavigationItemSelected(@NonNull MenuItem item) {
            switch (item.getItemId()) {

                case R.id.navigation_profile:
                    // mTextMessage.setText(R.string.title_notifications);
                    Intent jobz5 = new Intent(ViewShopperBizFavorites.this, ProfileActivity.class);
                    startActivity(jobz5);
                    return true;
                case R.id.navigation_home:
                    //mTextMessage.setText(R.string.title_home);
                    Intent jobz = new Intent(ViewShopperBizFavorites.this, Main3Activity.class);
                    startActivity(jobz);
                    return true;
                case R.id.navigation_search:
                    //  mTextMessage.setText(R.string.title_dashboard);
                    Intent job1 = new Intent(ViewShopperBizFavorites.this, ChapaBiz.class);
                    startActivity(job1);
                    return true;
                case R.id.navigation_favorites:
                    //  mTextMessage.setText(R.string.title_notifications);
                    Intent joboneIntent = new Intent(ViewShopperBizFavorites.this, FavoritesActivity.class);
                    startActivity(joboneIntent);
                    return true;

            }
            return true;
        }
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_favs);

        //   CbSession session = new CbSession(this);

        mTextMessage = (TextView) findViewById(R.id.message);
        BottomNavigationView navigation = (BottomNavigationView) findViewById(R.id.navigation);
        navigation.setOnNavigationItemSelectedListener(mOnNavigationItemSelectedListener);

        BottomNavigationView bottomNavigationView = (BottomNavigationView) findViewById(R.id.navigation);
        BottomNavigationViewHelper.disableShiftMode(bottomNavigationView);

        session = new CbSession(this);

        CbSession session = new CbSession(this);

        final TextView logoutb = (TextView) findViewById(R.id.logout);

        logoutb.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                logout();
            }
        });


        try {
            TextView name = findViewById(R.id.name);
            TextView email = findViewById(R.id.email);
            name.setText(session.getShopper().getName());
            email.setText(session.getShopper().getEmail());
            RoundedImageView imageView = findViewById(R.id.picture);
            Picasso.with(this).load(session.getShopper().getPicture())
                    .placeholder(ContextCompat.getDrawable(this, R.drawable.ic_chapabiz_logo_vert))
                    .into(imageView);
        }catch (Exception e) {
            if(session.getSignInMethod() == CbSession.FACEBOOK) {

            }
        }

        final RecyclerView recyclerView = findViewById(R.id.interest_list);
        GridLayoutManager gridLayoutManager = new GridLayoutManager(this, 1);
        recyclerView.setLayoutManager(gridLayoutManager);

        Call<ArrayList<BusinessDets>> arrayListCall = RetrofitSetup.retrofitInterface.getFavperShopper(session.getShopper().getId());
        arrayListCall.enqueue(new Callback<ArrayList<BusinessDets>>() {
            @Override
            public void onResponse(Call<ArrayList<BusinessDets>> call, Response<ArrayList<BusinessDets>> response) {
                if (response.isSuccessful()) {
                    ArrayList<BusinessDets> interests = response.body();

                    UserFavAdapter quickInterestAdapter = new UserFavAdapter(ViewShopperBizFavorites.this, interests);
                    recyclerView.setAdapter(quickInterestAdapter);
                }
            }

            @Override
            public void onFailure(Call<ArrayList<BusinessDets>> call, Throwable t) {

            }
        });

    }

    @Override
    public void interestClicked(int interest) {

    }
    private void logout() {

        GoogleSignInOptions gso = new GoogleSignInOptions.Builder(GoogleSignInOptions.DEFAULT_SIGN_IN)
                .requestEmail()
                .build();
        googleSignInClient = GoogleSignIn.getClient(this, gso);
        if (googleSignInClient != null) {
            googleSignInClient.signOut();
        }
        boolean loggedIn = AccessToken.getCurrentAccessToken() != null;
        if (loggedIn) {
            LoginManager.getInstance().logOut();
        }
        session.clear();
        startActivity(new Intent(ViewShopperBizFavorites.this, ShopperLogin.class));
    }
}
