package ke.co.prioritymobile.chapabiz.shopper.adapters;

import android.content.Context;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;

import ke.co.prioritymobile.chapabiz.R;
import ke.co.prioritymobile.chapabiz.shopper.entities.Interest;

public class InterestAdapter extends RecyclerView.Adapter<InterestAdapter.ViewHolder> {

    private Context context;
    private ArrayList<Interest> interests;

    public InterestAdapter(Context context, ArrayList<Interest> interests) {
        this.context = context;
        this.interests = interests;
    }

    @Override
    public InterestAdapter.ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(context).inflate(R.layout.shopper_interest_item, parent, false);
        return new InterestAdapter.ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(InterestAdapter.ViewHolder holder, int position) {
        Interest interest = interests.get(position);
        holder.name.setText(interest.getName());

        SubInterestAdapter subInterestAdapter = new SubInterestAdapter(context, interest.getInterestList());
        holder.recyclerView.setAdapter(subInterestAdapter);
    }

    @Override
    public int getItemCount() {
        return interests.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder {

        public TextView name;
        public RecyclerView recyclerView;

        public ViewHolder(View view) {
            super(view);
            name = view.findViewById(R.id.name);
            recyclerView = view.findViewById(R.id.list);
        }

    }

}
