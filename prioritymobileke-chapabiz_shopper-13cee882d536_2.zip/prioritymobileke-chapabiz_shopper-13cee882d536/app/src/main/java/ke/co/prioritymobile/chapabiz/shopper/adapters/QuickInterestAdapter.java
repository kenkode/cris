package ke.co.prioritymobile.chapabiz.shopper.adapters;

import android.content.Context;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;

import ke.co.prioritymobile.chapabiz.R;
import ke.co.prioritymobile.chapabiz.shopper.entities.Interest;
import ke.co.prioritymobile.chapabiz.shopper.entities.InterestDetail;

public class QuickInterestAdapter extends RecyclerView.Adapter<QuickInterestAdapter.ViewHolder> {

    private Context context;
    private ArrayList<InterestDetail> interests;
    public interface Clicked {
        void interestClicked(int interest);
    }
    private Clicked clicked;

    public QuickInterestAdapter(Context context, ArrayList<InterestDetail> interests) {
        this.context = context;
        this.interests = interests;
        clicked = (Clicked) context;
    }

    @Override
    public QuickInterestAdapter.ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(context).inflate(R.layout.quick_interest_item, parent, false);
        return new QuickInterestAdapter.ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(QuickInterestAdapter.ViewHolder holder, int position) {
        InterestDetail interest = interests.get(position);
        holder.interest.setText(interest.getName());
    }

    @Override
    public int getItemCount() {
        return interests.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder implements View.OnClickListener {

        public TextView interest;

        public ViewHolder(View view) {
            super(view);
            view.setOnClickListener(this);
            interest = view.findViewById(R.id.interest);
        }

        @Override
        public void onClick(View view) {
            InterestDetail interest = interests.get(getAdapterPosition());
            String id = interest.getId();
            clicked.interestClicked(Integer.parseInt(id));
        }
    }

}
