package ke.co.prioritymobile.chapabiz.shopper.adapters;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.support.v4.app.FragmentTransaction;
import android.support.v4.content.ContextCompat;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.RecyclerView;
import android.view.GestureDetector;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.maps.GoogleMap;

import java.util.ArrayList;

import ke.co.prioritymobile.chapabiz.R;
//import ke.co.prioritymobile.chapabiz.agent.fragments.BusinessDetails;
import ke.co.prioritymobile.chapabiz.adapters.ChatRoomsAdapter;
import ke.co.prioritymobile.chapabiz.shopper.entities.Business;
import ke.co.prioritymobile.chapabiz.shopper.activities.ThisBiz;
import ke.co.prioritymobile.chapabiz.shopper.entities.InterestDetail;
import ke.co.prioritymobile.chapabiz.shopper.entities.SubCategoryDetail;
import ke.co.prioritymobile.chapabiz.helpers.CbSession;
import ke.co.prioritymobile.chapabiz.shopper.fragments.BusinessDetails;

/**
 * Created by Millie Agallo on 5/17/2018.
 */

public class QuickInterestAdapter2 extends RecyclerView.Adapter<QuickInterestAdapter2.ViewHolder> {

    private Context context;
    private ArrayList<Business> businesses;

    public interface Clicked {
        void interestClicked(int interest);

        void onMapReady(GoogleMap googleMap);
    }
    private QuickInterestAdapter2.Clicked clicked;

//
    public QuickInterestAdapter2(Context context, ArrayList<Business> businesses) {
        this.context = context;
        this.businesses = businesses;
       clicked = (QuickInterestAdapter2.Clicked) context;
    }
    private void updateBackground(int state, Button button) {
        if (state == 1) {
            button.setText("x");
            button.setBackground(ContextCompat.getDrawable(context, R.drawable.interest_button_selected));
            button.setTextColor(ContextCompat.getColor(context, android.R.color.white));
        } else {
            button.setText("+");
            button.setBackground(ContextCompat.getDrawable(context, R.drawable.interest_button_deselected));
            button.setTextColor(ContextCompat.getColor(context, android.R.color.white));
        }
    }


    @Override
    public QuickInterestAdapter2.ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(context).inflate(R.layout.quick_interest_item, parent, false);
        return new QuickInterestAdapter2.ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(QuickInterestAdapter2.ViewHolder holder, int position) {
        Business business = businesses.get(position);
        holder.name.setText(business.getName());
       // holder.interest.setText(interest.);
        //Intent intent = new Intent(context,ThisBiz.class);

       // intent.putExtra("business_name",interests.get(position));
    }

    @Override
    public int getItemCount() {
        return businesses.size();
    }


    public class ViewHolder extends RecyclerView.ViewHolder implements View.OnClickListener {

        public TextView name;
       public TextView companyName, subCompanyName, companyLocation, distance, availability, verified, description;

        public ViewHolder(View view) {
            super(view);

            view.setOnClickListener(this);
            name = view.findViewById(R.id.interest);
        }

        @Override
        public void onClick(View view) {
            Business business = businesses.get(getAdapterPosition());
            CbSession session = new CbSession(context);
            session.setBusiness(business);
            BusinessDetails businessDetails = new BusinessDetails();
            Bundle bundle = new Bundle();
            bundle.putString("business", business.getId());
            businessDetails.setArguments(bundle);
            FragmentTransaction fragmentTransaction = ((AppCompatActivity) context).getSupportFragmentManager().beginTransaction();
            fragmentTransaction.replace(R.id.test1, businessDetails);
            fragmentTransaction.commit();

        }
    }

}

