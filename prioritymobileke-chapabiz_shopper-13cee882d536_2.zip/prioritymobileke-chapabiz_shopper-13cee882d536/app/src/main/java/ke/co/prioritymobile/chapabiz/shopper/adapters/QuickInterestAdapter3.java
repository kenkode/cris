package ke.co.prioritymobile.chapabiz.shopper.adapters;

import android.content.Context;
import android.os.Bundle;
import android.support.v4.app.FragmentTransaction;
import android.support.v4.content.ContextCompat;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;

import com.google.android.gms.maps.GoogleMap;

import java.util.ArrayList;

import ke.co.prioritymobile.chapabiz.R;
import ke.co.prioritymobile.chapabiz.helpers.CbSession;
import ke.co.prioritymobile.chapabiz.shopper.entities.Business;
import ke.co.prioritymobile.chapabiz.shopper.fragments.BusinessDetails;

/**
 * Created by Millie Agallo on 6/5/2018.
 */

public class QuickInterestAdapter3 extends RecyclerView.Adapter<QuickInterestAdapter3.ViewHolder> {

    private Context context;
    private ArrayList<Business> businesses;

    public interface Clicked {
        void interestClicked(int interest);

       // void onMapReady(GoogleMap googleMap);
    }
    private QuickInterestAdapter3.Clicked clicked;

    //
    public QuickInterestAdapter3(Context context, ArrayList<Business> businesses) {
        this.context = context;
        this.businesses = businesses;
        clicked = (QuickInterestAdapter3.Clicked) context;
    }
//    private void updateBackground(int state, Button button) {
//        if (state == 1) {
//            button.setText("x");
//            button.setBackground(ContextCompat.getDrawable(context, R.drawable.interest_button_selected));
//            button.setTextColor(ContextCompat.getColor(context, android.R.color.white));
//        } else {
//            button.setText("+");
//            button.setBackground(ContextCompat.getDrawable(context, R.drawable.interest_button_deselected));
//            button.setTextColor(ContextCompat.getColor(context, android.R.color.white));
//        }
//    }

    @Override
    public QuickInterestAdapter3.ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(context).inflate(R.layout.cart, parent, false);
        return new QuickInterestAdapter3.ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(QuickInterestAdapter3.ViewHolder holder, int position) {
        Business business = businesses.get(position);
        holder.name.setText(business.getName());

    }

    @Override
    public int getItemCount() {
        return businesses.size();
    }


    public class ViewHolder extends RecyclerView.ViewHolder implements View.OnClickListener {

        public TextView name;
        public TextView companyName, subCompanyName, companyLocation, distance, availability, verified, description;

        public ViewHolder(View view) {
            super(view);

            view.setOnClickListener(this);
            name = view.findViewById(R.id.interest);
        }

        @Override
        public void onClick(View view) {
            Business business = businesses.get(getAdapterPosition());
            CbSession session = new CbSession(context);
            session.setBusiness(business);
            BusinessDetails businessDetails = new BusinessDetails();
            Bundle bundle = new Bundle();
            bundle.putString("business", business.getId());
            businessDetails.setArguments(bundle);
            FragmentTransaction fragmentTransaction = ((AppCompatActivity) context).getSupportFragmentManager().beginTransaction();
            fragmentTransaction.replace(R.id.test2, businessDetails);
            fragmentTransaction.commit();

        }
    }

}

