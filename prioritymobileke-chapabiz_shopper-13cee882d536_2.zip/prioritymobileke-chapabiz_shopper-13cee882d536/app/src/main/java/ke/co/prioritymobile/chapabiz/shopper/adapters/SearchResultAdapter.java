package ke.co.prioritymobile.chapabiz.shopper.adapters;

import android.content.Context;
import android.content.Intent;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentTransaction;
import android.support.v4.content.ContextCompat;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.squareup.picasso.Picasso;

import java.util.ArrayList;

import ke.co.prioritymobile.chapabiz.R;
import ke.co.prioritymobile.chapabiz.shopper.activities.BusinessDetailsActivity;
import ke.co.prioritymobile.chapabiz.shopper.entities.SearchResult;
import ke.co.prioritymobile.chapabiz.shopper.fragments.BusinessFragment;
import ke.co.prioritymobile.chapabiz.shopper.fragments.InterestFragment;

public class SearchResultAdapter extends RecyclerView.Adapter<SearchResultAdapter.ViewHolder> {

//    public interface SearchListener {
//        void clickedBusiness();
//    }
//
//    private SearchListener searchListener;

    private Context context;
    private FragmentManager fragmentManager;
    private ArrayList<SearchResult> searchResults;

    public interface Clicked {
        void businessClicked(String id);
    }

    private Clicked clicked;

    public SearchResultAdapter(Context context, FragmentManager fragmentManager, ArrayList<SearchResult> searchResults) {
        this.context = context;
        this.fragmentManager = fragmentManager;
        this.searchResults = searchResults;
//        clicked = (Clicked) context;
    }

    @Override
    public SearchResultAdapter.ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(context).inflate(R.layout.search_result, null, false);
        return new SearchResultAdapter.ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(SearchResultAdapter.ViewHolder holder, int position) {
        SearchResult searchResult = searchResults.get(position);
        holder.name.setText(searchResult.getName());
        holder.desc.setText(searchResult.getDescription());

        String url = searchResult.getPhoto();

        Picasso.with(context).load(url)
                .placeholder(ContextCompat.getDrawable(context, R.drawable.ic_chapabiz_logo_vert))
                .into(holder.imageView);

        try {
            int distance = Integer.parseInt(searchResult.getDistance()) / 1000;
            holder.distance.setText(searchResult.getDistance() == null ? "__Km(s)" : String.format("%s Km(s)", distance));
        } catch (Exception ignored) {
        }

    }

    @Override
    public int getItemCount() {
        return searchResults.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder implements View.OnClickListener {

        public TextView name, desc, distance;
        public ImageView imageView;

        public ViewHolder(View view) {
            super(view);
            view.setOnClickListener(this);
            name = view.findViewById(R.id.name);
            desc = view.findViewById(R.id.description);
            distance = view.findViewById(R.id.distance);
            imageView = view.findViewById(R.id.image);
        }

        @Override
        public void onClick(View view) {
            clicked.businessClicked(searchResults.get(getAdapterPosition()).getId());
        }
    }

}
