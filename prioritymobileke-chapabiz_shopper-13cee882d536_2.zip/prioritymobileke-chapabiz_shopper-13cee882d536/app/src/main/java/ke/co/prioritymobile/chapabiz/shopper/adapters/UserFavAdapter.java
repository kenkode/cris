package ke.co.prioritymobile.chapabiz.shopper.adapters;

import android.content.Context;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import java.util.ArrayList;

import ke.co.prioritymobile.chapabiz.R;
import ke.co.prioritymobile.chapabiz.shopper.entities.BusinessDets;
import ke.co.prioritymobile.chapabiz.shopper.entities.InterestDetail;

/**
 * Created by Millie Agallo on 5/30/2018.
 */

public class UserFavAdapter extends RecyclerView.Adapter<UserFavAdapter.ViewHolder> {

    private Context context;
    private ArrayList<BusinessDets> interests;
    public interface Clicked {
        void interestClicked(int interest);
    }
    private UserFavAdapter.Clicked clicked;

    public UserFavAdapter(Context context, ArrayList<BusinessDets> interests) {
        this.context = context;
        this.interests = interests;
        clicked = (UserFavAdapter.Clicked) context;
    }

    @Override
    public UserFavAdapter.ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(context).inflate(R.layout.fav_list, parent, false);
        return new UserFavAdapter.ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(UserFavAdapter.ViewHolder holder, int position) {
        BusinessDets interest = interests.get(position);
        holder.interest.setText(interest.getBusiness_name());
    }

    @Override
    public int getItemCount() {
        return interests.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder implements View.OnClickListener {

        public TextView interest;

        public ViewHolder(View view) {
            super(view);
            view.setOnClickListener(this);
            interest = view.findViewById(R.id.interest);
        }

        @Override
        public void onClick(View view) {
            BusinessDets interest = interests.get(getAdapterPosition());
            String id = interest.getId();
            clicked.interestClicked(Integer.parseInt(id));
        }
    }

}
