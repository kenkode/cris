package ke.co.prioritymobile.chapabiz.shopper.entities;

/**
 * Created by Millie Agallo on 5/30/2018.
 */

public class BusinessDets {

        private String name, photo, id, business_name;
        private boolean selected;

        public boolean isSelected() {
            return selected;
        }

        public void setSelected(boolean selected) {
            this.selected = selected;
        }

        public String getName() {
            return name;
        }

        public void setName(String name) {
            this.name = name;
        }

        public String getPhoto() {
            return photo;
        }

        public void setPhoto(String photo) {
            this.photo = photo;
        }

        public String getId() {
            return id;
        }

        public void setId(String id) {
            this.id = id;
        }

        public String getBusiness_name(){
            return business_name;
        }

        public void setBusiness_name(String business_name){
            this.business_name = business_name;
        }


}
