package ke.co.prioritymobile.chapabiz.shopper.entities;

import com.google.gson.annotations.SerializedName;

import java.util.ArrayList;

public class Interest {

    private String name;
    @SerializedName("interest_list")
    private ArrayList<InterestDetail> interestList;

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public ArrayList<InterestDetail> getInterestList() {
        return interestList;
    }

    public void setInterestList(ArrayList<InterestDetail> interestList) {
        this.interestList = interestList;
    }

}
