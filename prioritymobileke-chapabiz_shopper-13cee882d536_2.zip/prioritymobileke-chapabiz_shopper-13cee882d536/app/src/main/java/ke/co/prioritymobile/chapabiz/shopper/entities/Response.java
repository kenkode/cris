package ke.co.prioritymobile.chapabiz.shopper.entities;

//package ke.co.prioritymobile.chapabiz.entities;

public class Response {


    //private Business business;
    private Shopper shopper;



    public Shopper getShopper() {
        return shopper;
    }


}
