package ke.co.prioritymobile.chapabiz.shopper.fragments;

import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.design.widget.Snackbar;
import android.support.design.widget.TextInputLayout;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentTransaction;
import android.support.v4.content.ContextCompat;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.CompoundButton;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.Toast;

import com.google.gson.Gson;
import com.makeramen.roundedimageview.RoundedImageView;
import com.squareup.picasso.Picasso;

import ke.co.prioritymobile.chapabiz.R;
import ke.co.prioritymobile.chapabiz.chat.ChatRoomActivity;
import ke.co.prioritymobile.chapabiz.helpers.CbSession;
import ke.co.prioritymobile.chapabiz.retrofit.RetrofitSetup;
import ke.co.prioritymobile.chapabiz.shopper.activities.ChapaBiz;
import ke.co.prioritymobile.chapabiz.shopper.entities.Business;
import okhttp3.ResponseBody;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

/**
 * Created by Millie Agallo on 5/28/2018.
 */

public class BusinessDetails extends Fragment {

    private CbSession session;
    private TextView name, email, phone, description;
    Switch heart;
    public FragmentManager fragmentManager;
    private Business currentBusiness;

    public interface Clicked {
        void logoClicked(ProgressBar progressBar, TextView progressText, RoundedImageView businessImage, String business);

        void uploadFile(ProgressBar progressBar, TextView progressText, String business);
    }

    private Clicked clicked;
    private static String businessId;

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setHasOptionsMenu(true);

        session = new CbSession(getContext());
        Bundle bundle = getArguments();
        if (bundle != null) {
            businessId = bundle.getString("business");
        } else {
            businessId = session.getBusiness().getId();
        }
    }

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.business_profile_fragment, container, false);

        final ProgressBar progressBar = view.findViewById(R.id.progress_bar);

        final RoundedImageView businessImage = view.findViewById(R.id.business_image);
        String url = session.getBusiness().getImage();
        if (url == null) {
            url = "image";
        }
        Picasso.with(getContext()).load(url).placeholder(ContextCompat.getDrawable(getContext(), R.drawable.ic_chapabiz_logo_vert)).into(businessImage);

//        businessImage.setOnClickListener(new View.OnClickListener() {
//            @Override
//            public void onClick(View view) {
//                clicked.logoClicked(progressBar, null, businessImage, businessId);
//            }
//        });

        final TextView certificate;



        name = view.findViewById(R.id.name);
     //   certificate = view.findViewById(R.id.certificate);
        email = view.findViewById(R.id.email);
        phone = view.findViewById(R.id.phone);
        description = view.findViewById(R.id.description);
        heart = view.findViewById(R.id.heart);

        final Business business = session.getBusiness();
     //   certificate.setText(business.getCertificateNo() == null ? "Certificate: Upload" : business.getCertificateNo());
        name.setText(business.getName());
        email.setText(business.getEmail());
        phone.setText(business.getPhone());
        description.setText(business.getDescription());

        email.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (currentBusiness != null) {
                    Intent intent = new Intent(getActivity(), ChatRoomActivity.class);
                    intent.putExtra("chat_room_id", currentBusiness.getId());
                    intent.putExtra("name", currentBusiness.getName());
                    startActivity(new Intent(intent));
                }
            }
        });

        phone.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if (currentBusiness != null) {
                    Intent intent = new Intent(Intent.ACTION_DIAL, Uri.parse("tel:" + currentBusiness.getPhone()));
                    startActivity(intent);
                } else {

                    Toast toast = Toast.makeText(getActivity(), "Phone number not set up", Toast.LENGTH_SHORT);
                    toast.setGravity(Gravity.CENTER, 0, 0);
                    toast.show();
                }
            }
        });

//        heart.setOnClickListener(new View.OnClickListener(){
//            @Override
//            public void onClick(View view){
//                Toast toast = Toast.makeText(getActivity(), "Business added to favorites", Toast.LENGTH_SHORT);
//                toast.setGravity(Gravity.CENTER, 0, 0);
//                toast.show();
//            }
//        });

        heart.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                int state = 0;
                if (isChecked) {
                    state = 1;
                    Toast.makeText(getContext(), "Added to favorites", Toast.LENGTH_LONG).show();
                } else {
                    state = 0;
                    Toast.makeText(getContext(), "Removed from favorites", Toast.LENGTH_LONG).show();
                }

                Call<ResponseBody> call = RetrofitSetup.retrofitInterface.updateStatus(session.getBusiness().getId(),state );

                call.enqueue(new Callback<ResponseBody>() {
                    @Override
                    public void onResponse(Call<ResponseBody> call, Response<ResponseBody> response) {

                    }

                    @Override
                    public void onFailure(Call<ResponseBody> call, Throwable t) {

                    }
                });

            }
        });


        return view;
    }

    @Override
    public void onAttach(Context context) {
        super.onAttach(context);
//        clicked = (Clicked) context;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {
            case R.id.photos:
                PhotoFragment photoFragment = new PhotoFragment();
                Bundle bundle = new Bundle();
                bundle.putString("business", session.getBusiness().getId());
                photoFragment.setArguments(bundle);
                FragmentTransaction profFrag = getActivity().getSupportFragmentManager().beginTransaction();
                // FragmentTransaction profFrag = getChildFragmentManager().beginTransaction();
                profFrag.replace(R.id.ttbb2, photoFragment);
                profFrag.setTransition(FragmentTransaction.TRANSIT_FRAGMENT_FADE);
                profFrag.commit();
                return true;
        }
        return false;
    }

}
