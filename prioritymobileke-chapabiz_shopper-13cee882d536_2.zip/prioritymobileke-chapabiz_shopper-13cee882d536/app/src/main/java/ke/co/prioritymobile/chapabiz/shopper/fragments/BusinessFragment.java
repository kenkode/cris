package ke.co.prioritymobile.chapabiz.shopper.fragments;

import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.support.v4.content.ContextCompat;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;

import com.squareup.picasso.Picasso;

import ke.co.prioritymobile.chapabiz.R;

public class BusinessFragment extends Fragment {

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.business_desc, container, false);
        ImageView imageView = view.findViewById(R.id.image);
        Picasso.with(getContext()).load("http://www.bordermediagroup.com/wp-content/uploads/2015/07/Mpesa-640x383.png")
                .placeholder(ContextCompat.getDrawable(getContext(), R.drawable.ic_chapabiz_logo_vert))
                .into(imageView);

        return view;
    }
}
