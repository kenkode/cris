package ke.co.prioritymobile.chapabiz.shopper.fragments;

import android.app.SearchManager;
import android.content.Context;
import android.os.Bundle;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.support.v7.widget.RecyclerView;
import android.support.v7.widget.SearchView;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ProgressBar;
import android.widget.TextView;

import java.util.ArrayList;

import ke.co.prioritymobile.chapabiz.R;
import ke.co.prioritymobile.chapabiz.shopper.adapters.InterestAdapter;
import ke.co.prioritymobile.chapabiz.shopper.entities.Interest;
import ke.co.prioritymobile.chapabiz.shopper.entities.InterestDetail;

public class InterestFragment extends Fragment {

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setHasOptionsMenu(true);
    }

    @Nullable
    @Override
    public View onCreateView(LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.shopper_interest_fragment, container, false);
        RecyclerView recyclerView = view.findViewById(R.id.interest_list);

        ProgressBar progressBar = view.findViewById(R.id.progress_bar);

        ArrayList<Interest> interests = new ArrayList<>();

        for (int i = 0; i < 4; i++) {
            Interest interest = new Interest();
            interest.setName("Popular");
            ArrayList<InterestDetail> interestDetails = new ArrayList<>();
            for (int j = 0; j < 3; j++) {
                InterestDetail interestDetail = new InterestDetail();
                interestDetail.setId("23423");
                interestDetail.setName("Retail");
                interestDetail.setPhoto("");
                interestDetail.setSelected(false);
                interestDetails.add(interestDetail);
            }
            interest.setInterestList(interestDetails);
            interests.add(interest);
        }

        progressBar.setVisibility(View.GONE);

        InterestAdapter interestAdapter = new InterestAdapter(getContext(), interests);
        recyclerView.setAdapter(interestAdapter);

        return view;
    }

    @Override
    public void onCreateOptionsMenu(Menu menu, MenuInflater inflater) {
        super.onCreateOptionsMenu(menu, inflater);

        inflater.inflate(R.menu.chapa_biz, menu);
        SearchManager searchManager = (SearchManager) getContext().getSystemService(Context.SEARCH_SERVICE);
        SearchView searchView = (SearchView) menu.findItem(R.id.menu_search).getActionView();
        searchView.setSearchableInfo(searchManager.getSearchableInfo(getActivity().getComponentName()));
        searchView.setIconifiedByDefault(true); // Do not iconify the widget; expand it by default

    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        return super.onOptionsItemSelected(item);
    }

}
