package ke.co.prioritymobile.chapabiz.shopper.sheets;

import android.annotation.SuppressLint;
import android.app.Dialog;
import android.support.annotation.NonNull;
import android.support.design.widget.BottomSheetBehavior;
import android.support.design.widget.BottomSheetDialogFragment;
import android.support.design.widget.CoordinatorLayout;
import android.support.v7.widget.CardView;
import android.support.v7.widget.RecyclerView;
import android.view.View;

import java.util.ArrayList;

import ke.co.prioritymobile.chapabiz.R;
import ke.co.prioritymobile.chapabiz.shopper.adapters.SearchResultAdapter;
import ke.co.prioritymobile.chapabiz.shopper.entities.SearchResult;

public class BottomSheetFragment extends BottomSheetDialogFragment {

    private BottomSheetBehavior.BottomSheetCallback mBottomSheetBehaviorCallback = new BottomSheetBehavior.BottomSheetCallback() {

        @Override
        public void onStateChanged(@NonNull View bottomSheet, int newState) {
            if (newState == BottomSheetBehavior.STATE_HIDDEN) {
                dismiss();
            }
        }

        @Override
        public void onSlide(@NonNull View bottomSheet, float slideOffset) {
//            if(slideOffset)
        }
    };

    @Override
    public void setupDialog(Dialog dialog, int style) {
        super.setupDialog(dialog, style);
        View contentView = View.inflate(getContext(), R.layout.search_list_layout, null);

        RecyclerView recyclerView = contentView.findViewById(R.id.list);

        ArrayList<SearchResult> searchResults = new ArrayList<>();

        String[] names = {"CornerView MPesa", "KCB Bank", "Mama Mike's MPesa"};
        String[] description = {"14 Morningside Office Park", "Prestige Plaza Ngong Road", "Prestige Plaza Ngong Road"};

        for (int i = 0; i < 2; i++) {
            SearchResult searchResult = new SearchResult();
            searchResult.setDescription(description[i]);
            searchResult.setId("234sfrsd");
            searchResult.setName(names[i]);
            searchResult.setType("d");
            searchResult.setDistance("12");
            searchResults.add(searchResult);
        }

        SearchResultAdapter adapter = new SearchResultAdapter(getContext(), getFragmentManager(), searchResults);
        recyclerView.setAdapter(adapter);

        dialog.setContentView(contentView);

        CoordinatorLayout.LayoutParams params = (CoordinatorLayout.LayoutParams) ((View) contentView.getParent()).getLayoutParams();
        CoordinatorLayout.Behavior behavior = params.getBehavior();

        if (behavior != null && behavior instanceof BottomSheetBehavior) {
            ((BottomSheetBehavior) behavior).setBottomSheetCallback(mBottomSheetBehaviorCallback);
            ((BottomSheetBehavior) behavior).setHideable(false);
            ((BottomSheetBehavior) behavior).setState(BottomSheetBehavior.STATE_EXPANDED);
        }
    }
}