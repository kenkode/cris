<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Business extends Model
{
    protected $fillable=['business_name', 'owner_id', 'category', 'business_phone', 'business_email', 'street_address', 'town', 'county','business_description', 'operations_since', 'certificate_no', 'certificate_copy','img', 'verified'];
}
