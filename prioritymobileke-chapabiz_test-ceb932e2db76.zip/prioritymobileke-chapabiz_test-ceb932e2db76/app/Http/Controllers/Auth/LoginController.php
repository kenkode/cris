<?php

namespace App\Http\Controllers\Auth;

use App\Http\Controllers\Controller;
use Illuminate\Foundation\Auth\AuthenticatesUsers;
use Auth;
use Socialite;
use App\User;
use Illuminate\Http\Request;

class LoginController extends Controller
{
    /*
    |--------------------------------------------------------------------------
    | Login Controller
    |--------------------------------------------------------------------------
    |
    | This controller handles authenticating users for the application and
    | redirecting them to your home screen. The controller uses a trait
    | to conveniently provide its functionality to your applications.
    |
    */

    use AuthenticatesUsers;

    protected $redirectTo = '/home'; 


    /*protected function authenticated(Request $request, $user)
    {



        if ( $user->role=="user") {

            return redirect('dashboard');

            
        }elseif ( $user->role=="Admin"){

             return redirect('/home');

        }
       
    } */

    /**
     * Where to redirect users after login.
     *
     * @var string
     */

      

    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct()
    {
       
        $this->middleware('guest')->except('logout');
    }


    public function redirectToProvider($provider)
    {
        return Socialite::driver($provider)->redirect();
    }


    public function handleProviderCallback($provider)
    {
        $user = Socialite::driver($provider)->user();

        $authUser = $this->findOrCreateUser($user, $provider);
        Auth::login($authUser, true);
        return redirect($this->redirectTo);
    }

    public function findOrCreateUser($user, $provider)
    {
        $authUser = User::where('provider_id', $user->id)->first();
        if ($authUser) {
            return $authUser;
        }

        $token=str_random(60);

        if($user->email==""){
          $email="danstan@quinstech.co.ke";  
        }else{
          $email=$user->email;  
        }

        Controller::send_mail("danstan@quinstech.co.ke","Quinstech CRM",$email,"Api Token",$token);

        return User::create([
            'name'     => $user->name,
            'email'    => $user->email,
            'provider' => $provider,
            'provider_id' => $user->id,
            'api_token'=>$token,
            
        ]);

        
    }

        public function redirectPath()
        {
        return url()->previous() == route('login') || url()->previous() == route('login')? $this->redirectTo : url()->previous();
        }


}
