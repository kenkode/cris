<?php

namespace App\Http\Controllers;

use App\Business;
use App\Categories;
use App\County;
use Auth;
use App\Invoice;

use Illuminate\Http\Request;

class BusinessController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        if(Auth::user()->role=='Agent'){

           $data['businesses']=Business::where('verified','=',Auth::user()->id)
                                         ->orWhere('verified','=',0)
                                         ->get();
        }elseif(Auth::user()->role=='Owner'){
        $data['businesses']=Business::where('owner_id','=',Auth::user()->id)->get();

        }else{

           $data['businesses']=Business::all();
 
        }

        
        return view('businesses.index',$data);
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        if(Auth::user()->role!='Owner'){
          $data['owner_id']=$_REQUEST['owner_id'];
        }


        $data['categories']=Categories::all();
        $data['counties']=County::all();
        return view('businesses.create',$data);
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $cert=Controller::uploadFile($request);
        if($file=$request->file('img'))$img= Controller::upload_img($file); else $img= "";

        if(Auth::user()->role=='Agent'||Auth::user()->role=='Administrator'){
            $verified=Auth::user()->id;
        }else{
            $verified=0;
        }

        $business=Business::create(['business_name'=>$request->business_name,'owner_id'=>$request->owner_id,'category'=>$request->category, 'business_phone'=>$request->business_phone, 'business_email'=>$request->business_email, 'street_address'=>$request->street_address, 'town'=>$request->town, 'county'=>$request->county,'business_description'=>$request->business_description, 'operations_since'=>$request->operations_since, 'certificate_no'=>$request->certificate_no, 'certificate_copy'=>$cert, 'img'=>$img, 'verified'=>$verified]);

        $amount=Categories::find($request->category)->price;

        $vat=(16/100)*$amount;

        $balance=$amount+$vat;
 
        Invoice::create(['user_id'=>$request->owner_id,'business_id'=>$business->id,'amount'=>$amount,'balance'=>$balance,'status'=>'Pending']);


           return redirect('business');
        

    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Business  $business
     * @return \Illuminate\Http\Response
     */
    public function show(Business $business)
    {
        $data['business']=$business;


        return view('businesses.show',$data);
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Business  $business
     * @return \Illuminate\Http\Response
     */
    public function edit(Business $business)
    {
        $data['business']=$business;
        $data['categories']=Categories::all();
        $data['counties']=County::all();

        return view('businesses.edit',$data);
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Business  $business
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, Business $business)
    {
         
       

        if($file=$request->file('img')){
          $img= Controller::upload_img($file);
          $business->update(array('img'=>$img));

        }

        if($file2=$request->file('thefile')){
          $cert= Controller::upload_img($file2);
          $business->update(array('certificate_copy'=>$cert));

        }

        $business->update(['business_name'=>$request->business_name,'owner_id'=>$request->owner_id,'category'=>$request->category, 'business_phone'=>$request->business_phone, 'business_email'=>$request->business_email, 'street_address'=>$request->street_address, 'town'=>$request->town, 'county'=>$request->county,'business_description'=>$request->business_description, 'operations_since'=>$request->operations_since, 'certificate_no'=>$request->certificate_no]);

        
           return redirect('business');
         
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Business  $business
     * @return \Illuminate\Http\Response
     */
    public function destroy(Business $business)
    {
        $business->delete();
        
           return redirect('business');
          
    }

    public function verify($id)
    {
        
        $business=Business::find($id);
        $business->update(['verified'=>Auth::user()->id]);
        
           return redirect('business');
           
    }

    public function per_region()
    {

        $county=$_REQUEST['region'];

        $data['county']=$county;
        $data['businesses']=Business::where('county','=',$county)->get();
   

        
        return view('businesses.per_region',$data);


        
    }
}
