<?php

namespace App\Http\Controllers;

use Illuminate\Foundation\Bus\DispatchesJobs;
use Illuminate\Routing\Controller as BaseController;
use Illuminate\Foundation\Validation\ValidatesRequests;
use Illuminate\Foundation\Auth\Access\AuthorizesRequests;
use App\User;
use Illuminate\Support\Facades\Auth;
use Illuminate\Http\Request;
use Mail;
use App\Categories;
use App\County;
use App\Business;
use App\Invoice;
use App\Rating;


use App\Http\Controllers\AfricasTalkingGateway;

class Controller extends BaseController
{
    use AuthorizesRequests, DispatchesJobs, ValidatesRequests;



  public static function businesses_per_category($cat)
    {
        
     return Business::where('category','=',$cat)->count();
    
    
    }


  public static function likes($business)
    {
        
     return Rating::where('business_id','=',$business)->where('reaction','=',1)->count();
    
    
    }

 public static function dislikes($business)
    {
        
     return Rating::where('business_id','=',$business)->where('reaction','=',0)->count();
    
    
    }

    public static function role()
    {
        
      $data = User::select('*')
               ->where('id', '=', Auth::user()->id)  
               ->get();

    return $data[0]->role;
    
    
    }


    public static function category_name($id)
    {
        
      $data = Categories::where('id', '=', $id)->first();


          if(!is_null($data)){
              return $data->name;
          }else{
             return "";

          }   
    
    
    }

    public static function user_by_id($id)
    {
        
      return User::find($id);
    
    }

    public static function invoicee($invoice_no)
    {
      
      $invoicee=Invoice::find($invoice_no);

      return User::find($invoicee->user_id);
    
    }


   public static function signups($id)
    {
        
      return Business::where('verified','=',$id)->count();
    
    }

  public static function county_signups($id)
    {
        
      return Business::where('county','=',$id)->count();
    
    }



   public static function percentage_sign_ups($id)
    {
        
      $mine=Business::where('verified','=',$id)->count();
      $all=Business::count();

      return ($mine/$all)*100;
    
    }


  public static function county_percentage_sign_ups($id)
    {
        
      $mine=Business::where('county','=',$id)->count();
      $all=Business::count();

      return ($mine/$all)*100;
    
    }

   public static function user_name($id)
    {
        
      $user= User::find($id);

      if(is_null($user)){

        return "";

      }else{

          return $user->first_name." ".$user->last_name;
    
      }

    
    }


    public static function businessname($id)
    {
        
      $bus= Business::find($id);

      if(is_null($bus)){

        return "";

      }else{

          return $bus->business_name;
      }

    
    }



    public static function county_name($id)
    {
        
      $county= County::find($id);

      if(is_null($county)){

        return "";

      }else{
        
          return $county->county_name;
    
      }

    
    }


    public static function uploadFile($request){

        

	     if($file = $request->file('thefile')){
	   
	      
	      $destinationPath = 'uploads';

	      $thefile=$file->move($destinationPath,time().$file->getClientOriginalName());

	      return $thefile;
	     }else{

	     	return 1;
	     }

     }


     public static function upload_img($file){       

	      
	      $destinationPath = 'uploads';

	      $path=$file->move($destinationPath,time().$file->getClientOriginalName());

	      return $path;
	    
     }

    public function send_mail($from,$from_name,$to,$subject,$msg){

    	$data = array( 'to' =>$to, 'subject' => $subject, 'from' =>$from,'from_name' =>$from_name,'msg'=>$msg);

        Mail::send([], [], function($message) use ($data) {
            $message->from($data['from'],$data['from_name']);
            $message->to($data['to']);
            $message->subject($data['subject']);
            $message->setBody($data['msg'], 'text/html');
        });
    }

  
      


    public function send_sms($number,$msg){
		
			//require_once('AfricasTalkingGateway.php');

			$username   = "danstan";
			$apikey     = "69727f2865dd3564454e3c865ae1df01e1afa6a878a2933f8c098604eda7ab48";

			$recipients = $number;
			$message    = $msg;

			$gateway    = new AfricasTalkingGateway($username, $apikey);
			
				try 
				{ 
				  				  
				  $results = $gateway->sendMessage($recipients, $message);
				  
				 /* foreach($results as $result) {
					//echo " Number: " .$result->number;
					echo " Status: " .$result->status."<br>";
					//echo " MessageId: " .$result->messageId;
					//echo " Cost: "   .$result->cost."<br>";
				  }*/

				  return $results; 
				 
				}
				catch ( AfricasTalkingGatewayException $e )
				{
				  $error="Encountered an error while sending: ".$e->getMessage();
				  return $error;
				}
		
				
				
	}


  Public function has_paid($current_user){
   
   
  $consumer_key="VzqW6ARK/xCS3uHynr7hkA0zkbxMEq9F";//Register a merchant account on
                   //demo.pesapal.com and use the merchant key for testing.
                   //When you are ready to go live make sure you change the key to the live account
                   //registered on www.pesapal.com!
    $consumer_secret="dYUilsxUKnWq3WeJv7re2/IhKVA=";// Use the secret from your test
                   //account on demo.pesapal.com. When you are ready to go live make sure you 
                   //change the secret to the live account registered on www.pesapal.com!
    $statusrequestAPI = 'https://www.pesapal.com/api/querypaymentstatus';//change to      
                   //https://www.pesapal.com/api/querypaymentstatus' when you are ready to go live!
           
             
   $member = "SELECT * FROM `payments` WHERE `user_email`='".$current_user->user_email."'";
     //$result=mysqli_query($member) or die( mysqli_error($connection));
   $rs = $wpdb->get_results($member);
 if($wpdb->query($member)==0){ return "NO";}
   else{
   foreach($rs as $row):
   
   //-------------------------------------------------------
   

   $pesapalTrackingId=$row->pesapal_tracking_id;
   $pesapal_merchant_reference=$row->reference;
   
   $token = $params = NULL;
   $consumer = new OAuthConsumer($consumer_key, $consumer_secret);
   $signature_method = new OAuthSignatureMethod_HMAC_SHA1();

   //get transaction status
   $request_status = OAuthRequest::from_consumer_and_token($consumer, $token, "GET", $statusrequestAPI, $params);
   $request_status->set_parameter("pesapal_merchant_reference", $pesapal_merchant_reference);
   $request_status->set_parameter("pesapal_transaction_tracking_id",$pesapalTrackingId);
   $request_status->sign_request($signature_method, $consumer, $token);

   $ch = curl_init();
   curl_setopt($ch, CURLOPT_URL, $request_status);
   curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
   curl_setopt($ch, CURLOPT_HEADER, 1);
   curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);
   if(defined('CURL_PROXY_REQUIRED')) if (CURL_PROXY_REQUIRED == 'True')
   {
      $proxy_tunnel_flag = (defined('CURL_PROXY_TUNNEL_FLAG') && strtoupper(CURL_PROXY_TUNNEL_FLAG) == 'FALSE') ? false : true;
      curl_setopt ($ch, CURLOPT_HTTPPROXYTUNNEL, $proxy_tunnel_flag);
      curl_setopt ($ch, CURLOPT_PROXYTYPE, CURLPROXY_HTTP);
      curl_setopt ($ch, CURLOPT_PROXY, CURL_PROXY_SERVER_DETAILS);
   }

   $response = curl_exec($ch);

   $header_size = curl_getinfo($ch, CURLINFO_HEADER_SIZE);
   $raw_header  = substr($response, 0, $header_size - 4);
   $headerArray = explode("\r\n\r\n", $raw_header);
   $header      = $headerArray[count($headerArray) - 1];

   //transaction status
   $elements = preg_split("/=/",substr($response, $header_size));
   $status = $elements[1];
   //echo "transaction status is ". $status;
   curl_close ($ch);
   
//UPDATE YOUR DB TABLE WITH NEW STATUS FOR TRANSACTION WITH pesapal_transaction_tracking_id $pesapalTrackingId
$trans = "UPDATE `payments` SET `status`='".$status."' 
          WHERE `pesapal_tracking_id`='".$pesapal_tracking_id."'";


   $wpdb->query($trans);

   
   
   
   //---------------------------------------------------------
   
   
   
   
   
    
  if($status=="COMPLETED") return "YES";
  else return $status;
  endforeach;
   }
 }





Public function response(){
 
  
     
//include "wp-admin/includes/connection.php";
//include "wp-admin/includes/functions.php";
include_once('pesapal/OAuth.php');

$reference = null;
$pesapal_tracking_id = null;
if(isset($_GET['pesapal_merchant_reference']))
$reference = $_GET['pesapal_merchant_reference'];

    if(isset($_GET['pesapal_transaction_tracking_id']))
    {

    $pesapal_tracking_id = $_GET['pesapal_transaction_tracking_id'];

    $user_email=$current_user->user_email;
    //store $pesapal_tracking_id in your database against the order with orderid = $reference
    // listen and get status

    $trans = "INSERT INTO `payments` (`pesapal_tracking_id`, `reference`, `user_email`)
                                       VALUES 
                                    ('".$pesapal_tracking_id."', '".$reference."','".$user_email."')";
    $wpdb->query($trans);

    $consumer_key="VzqW6ARK/xCS3uHynr7hkA0zkbxMEq9F";//Register a merchant account on
                       //demo.pesapal.com and use the merchant key for testing.
                       //When you are ready to go live make sure you change the key to the live account
                       //registered on www.pesapal.com!
    $consumer_secret="dYUilsxUKnWq3WeJv7re2/IhKVA=";// Use the secret from your test
                       //account on demo.pesapal.com. When you are ready to go live make sure you 
                       //change the secret to the live account registered on www.pesapal.com!
    $statusrequestAPI = 'https://www.pesapal.com/api/querypaymentstatus';//change to      
                       //https://www.pesapal.com/api/querypaymentstatus' when you are ready to go live!

               
               
    // Parameters sent to you by PesaPal IPN
    $pesapalNotification=$_GET['pesapal_notification_type'];
    $pesapalTrackingId=$_GET['pesapal_transaction_tracking_id'];
    $pesapal_merchant_reference=$_GET['pesapal_merchant_reference'];
    //echo "Notification=".$pesapalNotification;
    //echo "Tracking id=".$pesapalTrackingId;


          if($pesapalTrackingId!='')
          {
             $token = $params = NULL;
             $consumer = new OAuthConsumer($consumer_key, $consumer_secret);
             $signature_method = new OAuthSignatureMethod_HMAC_SHA1();

             //get transaction status
             $request_status = OAuthRequest::from_consumer_and_token($consumer, $token, "GET", $statusrequestAPI, $params);
             $request_status->set_parameter("pesapal_merchant_reference", $pesapal_merchant_reference);
             $request_status->set_parameter("pesapal_transaction_tracking_id",$pesapalTrackingId);
             $request_status->sign_request($signature_method, $consumer, $token);

             $ch = curl_init();
             curl_setopt($ch, CURLOPT_URL, $request_status);
             curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
             curl_setopt($ch, CURLOPT_HEADER, 1);
             curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);
             if(defined('CURL_PROXY_REQUIRED')) if (CURL_PROXY_REQUIRED == 'True')
             {
                $proxy_tunnel_flag = (defined('CURL_PROXY_TUNNEL_FLAG') && strtoupper(CURL_PROXY_TUNNEL_FLAG) == 'FALSE') ? false : true;
                curl_setopt ($ch, CURLOPT_HTTPPROXYTUNNEL, $proxy_tunnel_flag);
                curl_setopt ($ch, CURLOPT_PROXYTYPE, CURLPROXY_HTTP);
                curl_setopt ($ch, CURLOPT_PROXY, CURL_PROXY_SERVER_DETAILS);
             }

             $response = curl_exec($ch);

             $header_size = curl_getinfo($ch, CURLINFO_HEADER_SIZE);
             $raw_header  = substr($response, 0, $header_size - 4);
             $headerArray = explode("\r\n\r\n", $raw_header);
             $header      = $headerArray[count($headerArray) - 1];

             //transaction status
             $elements = preg_split("/=/",substr($response, $header_size));
             $status = $elements[1];
             //echo "transaction status is ". $status;
             curl_close ($ch);
             
          //UPDATE YOUR DB TABLE WITH NEW STATUS FOR TRANSACTION WITH pesapal_transaction_tracking_id $pesapalTrackingId
          $trans = "UPDATE `payments` SET `status`='".$status."' 
                    WHERE `pesapal_tracking_id`='".$pesapal_tracking_id."'";


             if($wpdb->query($trans))
             {
                $resp="pesapal_notification_type=$pesapalNotification&pesapal_transaction_tracking_id=$pesapalTrackingId&pesapal_merchant_reference=$pesapal_merchant_reference";
                ob_start();
                //echo $resp;
                ob_flush();
              
             redirect('http://www.kwanet.com/platinum');
            
                  
              
             } else{"There was a problem. Please call 0724817546 for assistance";}
           }

    }


  
 
  
}

	





    

}
