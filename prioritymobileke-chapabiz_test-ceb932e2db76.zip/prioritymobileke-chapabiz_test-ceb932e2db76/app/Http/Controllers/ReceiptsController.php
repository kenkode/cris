<?php

namespace App\Http\Controllers;

use App\Receipt;
use App\Invoice;
use Illuminate\Http\Request;
use Auth;

class ReceiptsController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $data['receipts']=Receipt::all();

        return view('receipts.index',$data);
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        Receipt::create($request->all());

        $invoice=Invoice::find($request->invoice_no);

        if($invoice->balance > $request->amount){

            $balance=$invoice->balance-$request->amount;

           $invoice->update(['status'=>'Partial','balance'=>$balance]);

        }else{

           $balance=$invoice->balance-$request->amount;
           $invoice->update(['status'=>'Paid','balance'=>$balance]);
        }


        return redirect('invoices');
    }


    /**
     * Display the specified resource.
     *
     * @param  \App\Receipt  $receipt
     * @return \Illuminate\Http\Response
     */
    public function show(Receipt $receipt)
    {
        $data['receipt']=$receipt;

        return view('receipts.show',$data);
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Receipt  $receipt
     * @return \Illuminate\Http\Response
     */
    public function edit(Receipt $receipt)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Receipt  $receipt
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, Receipt $receipt)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Receipt  $receipt
     * @return \Illuminate\Http\Response
     */
    public function destroy(Receipt $receipt)
    {
        //
    }

    public function pay()
    {
        $data['invoice_no']=$_REQUEST['invoice_no'];
        return view('receipts.pay',$data);

    }

     public function my_receipts()
    {
        $data['receipts']=Receipt::select('receipts.*')
                                 ->join('invoices','invoices.id','=','receipts.invoice_no')
                                 ->where('invoices.user_id','=',Auth::user()->id)
                                 ->get();

        return view('receipts.mine',$data);
    }

    public function view_receipt()
    {
       $data['receipt']=Receipt::find($_REQUEST['receipt_no']);

       return view('receipts.my_receipt',$data);
    }


}
