<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\User;
use App\Categories;
use App\County;
use App\Role;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Hash;
class UserController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        if(Auth::user()->role=='Agent'){

          $data['users']= User::where('role','=','Owner')->get();
        }
        else{

            $data['users']= User::all(); 
        }
       

    
    return view('users.index',$data);
    
    }

   

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
       $data['roles']=Role::all();
       return view('users.create',$data);
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request ,User $user)
    {
        $this->validate($request,[
            'first_name' => 'required|string|max:255',
            'last_name' => 'required|string|max:255',
            'email' => 'required|string|email|max:255|unique:users',
            'password' => 'required|string|min:6|confirmed',
        ]);

         $user=User::create([
            'first_name' => $request->first_name,
            'last_name' => $request->last_name,
            'email' => $request->email,
            'role' => $request->role, 
            'gender' => $request->gender,           
            'password' => bcrypt($request->password)
            
        ]); 

        if(Auth::user()->role=='Agent') {
            $data['owner_id']=$user->id;
            $data['categories']=Categories::all();
            $data['counties']=County::all();
            return view('businesses.create',$data);
        }else{
           return redirect('users'); 
        }
         
        
    }

    public function register_supplier(Request $request)
    {
        $token=str_random(60);
        $user = new User;
        $insert=$user->create_user($request->name,$request->email,$request->phone,$request->password,$request->role);    
      
        return redirect('welcome');  
        
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit( User $user)
    {
         $data['user'] = $user;

         
        return view('users.edit',$data);
    }



    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, User $user)
    {
       
         
        $update=$user->update(array('first_name'=>$request->first_name,'last_name'=>$request->last_name,'email'=>$request->email,'phone_number'=>$request->phone_number,'postal_address'=>$request->postal_address,'role'=>$request->role,'county'=>$request->county));   


        return redirect('users');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
       
        user::find($id)->delete();
        $data['status'] = 'User deleted!';
        $data['status_class'] = 'alert-success';

        return redirect('users')->with($data);
    }

      

    public static function name_by_id($id)
    {
        
      $data = User::select('*')
               ->where('id', '=', $id)  
               ->get();

    return $data[0]->name;
    
    }
    
      public function profile()
    {

        $data['user']=Auth::user();

        return view('users.profile',$data);
        
      
    }

    public function profile_edit()
    {
        
        $data['user']=Auth::user();

        return view('users.profile_edit',$data);
    }

    public function profile_update(Request $request)
    {
        $user=Auth::user();

        $user->update($request->all());

        return redirect('profile');
      
    }

    public function password_edit()
    {
        $data['user']=Auth::user();

        return view('users.password_edit',$data);;
      
    }

    public function password_update(Request $request)
    {
        $user=Auth::user();
         $this->validate($request,[
            'password' => 'required|string|min:6|confirmed',
        ]);

         


     if (Hash::check($request->current_password, $user->password)) { 
                  
         $user->update(['password' => bcrypt($request->password)]);

               flash('Password changed')->success()->important();
                return redirect('password-edit');

            } else {
        
                flash('Current Password is incorrect')->error()->important();
               return redirect('password-edit');
            }


    }
 



    
}
