@extends('layouts.theme')

@section('content')
<?php use App\Http\Controllers\Controller; ?>

    
    <div class="wrapper wrapper-content">

        <div class="row">

            <div class="col-lg-12">
                <div class="contact-box">
                    <a href="profile.html">
                    <div class="col-sm-4">
                        <div class="text-center">

                        

           
                           
                            
                        </div>
                    </div>
                    <div class="col-sm-8 ">
               

                        <h3><strong> Welcome {{Auth::User()->first_name}} &nbsp {{Auth::User()->last_name}}</strong></h3>
                        
                        
                        
                    </div>
                    <div class="clearfix"></div>
                        </a>
                </div>
            </div>


        </div>

        

    </div>


       <div class="wrapper wrapper-content animated fadeInRight" >
            <div class="row">
               
            <div class="col-lg-12">
                <div class="ibox float-e-margins">
                    <div class="ibox-title">
                        <h5></h5>
                        
                    </div>
                    <div class="ibox-content">
                        <div id="morris-bar-chart"></div>
                    </div>
                </div>
            </div>
            </div>
           
 </div>
        


@endsection
