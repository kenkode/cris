@extends('layouts.register')

@section('content')

<div class="col-md-6 col-md-offset-3">

<p> Already have an account? <a href="{{url('/login')}}"> <button class="btn btn-primary">Login</button></a></p>

</div>


 <form class="form-horizontal" role="form" method="POST" action="{{ url('/register') }}">
                        {{ csrf_field() }}

                        <div class="form-group{{ $errors->has('name') ? ' has-error' : '' }}">
                            <label for="first_name" class="col-md-4 control-label">First Name</label>

                            <div class="col-md-6">
                                <input id="first_name" type="text" class="form-control" name="first_name" value="{{ old('first_name') }}">

                                @if ($errors->has('first_name'))
                                    <span class="help-block">
                                        <strong>{{ $errors->first('first_name') }}</strong>
                                    </span>
                                @endif
                            </div>
                        </div>

                        <div class="form-group{{ $errors->has('name') ? ' has-error' : '' }}">
                            <label for="last_name" class="col-md-4 control-label">Last Name</label>

                            <div class="col-md-6">
                                <input id="last_name" type="text" class="form-control" name="last_name" value="{{ old('last_name') }}">

                                @if ($errors->has('last_name'))
                                    <span class="help-block">
                                        <strong>{{ $errors->first('last_name') }}</strong>
                                    </span>
                                @endif
                            </div>
                        </div>


                        <div class="form-group{{ $errors->has('email') ? ' has-error' : '' }}">
                            <label for="email" class="col-md-4 control-label">E-Mail Address</label>

                            <div class="col-md-6">
                                <input id="email" type="email" class="form-control" name="email" value="{{ old('email') }}">

                                @if ($errors->has('email'))
                                    <span class="help-block">
                                        <strong>{{ $errors->first('email') }}</strong>
                                    </span>
                                @endif
                            </div>
                        </div>

                        <div class="form-group{{ $errors->has('password') ? ' has-error' : '' }}">
                            <label for="password" class="col-md-4 control-label">Password</label>

                            <div class="col-md-6">
                                <input id="password" type="password" class="form-control" name="password">

                                @if ($errors->has('password'))
                                    <span class="help-block">
                                        <strong>{{ $errors->first('password') }}</strong>
                                    </span>
                                @endif
                            </div>
                        </div>

                        <div class="form-group{{ $errors->has('password_confirmation') ? ' has-error' : '' }}">
                            <label for="password-confirm" class="col-md-4 control-label">Confirm Password</label>

                            <div class="col-md-6">
                                <input id="password-confirm" type="password" class="form-control" name="password_confirmation">

                                @if ($errors->has('password_confirmation'))
                                    <span class="help-block">
                                        <strong>{{ $errors->first('password_confirmation') }}</strong>
                                    </span>
                                @endif
                            </div>
                        </div>


                            <div class="form-group{{ $errors->has('phone_number') ? ' has-error' : '' }}">
                            <label for="phone_number" class="col-md-4 control-label">Phone Number</label>

                            <div class="col-md-6">
                                <input id="phone_number" type="text" class="form-control" name="phone_number" value="{{ old('phone_number') }}">

                                @if ($errors->has('phone_number'))
                                    <span class="help-block">
                                        <strong>{{ $errors->first('phone_number') }}</strong>
                                    </span>
                                @endif
                            </div>
                        </div>


                            <div class="form-group{{ $errors->has('phone_number') ? ' has-error' : '' }}">
                            <label for="postal_address" class="col-md-4 control-label">Postal Address</label>

                            <div class="col-md-6">
                                <input id="postal_address" type="text" class="form-control" name="postal_address" value="{{ old('postal_address') }}">

                                @if ($errors->has('postal_address'))
                                    <span class="help-block">
                                        <strong>{{ $errors->first('postal_address') }}</strong>
                                    </span>
                                @endif
                            </div>
                        </div>

                 <div class="form-group">
         <label for="county" class="col-md-4 control-label">County</label>
         <div class="col-md-6">
         <select name='county' class="form-control" id="county" >
              <option value=''></option>
                        <option value='Baringo'> Baringo</option>
                        <option value='Bomet'> Bomet</option>
                        <option value='Bungoma'> Bungoma</option>
                        <option value='Busia'> Busia</option>
                        <option value='Elgeyo Marakwet'> Elgeyo Marakwet</option>
                        <option value='Embu'> Embu</option>
                        <option value='Garissa'> Garissa</option>
                        <option value='Homa Bay'> Homa Bay</option>
                        <option value='Isiolo'> Isiolo</option>
                        <option value='Kajiado'> Kajiado</option>
                        <option value='Kakamega'> Kakamega</option>
                        <option value='Kericho'> Kericho</option>
                        <option value='Kiambu'> Kiambu</option>
                        <option value='Kilifi'> Kilifi</option>
                        <option value='Kirinyaga'> Kirinyaga</option>
                        <option value='Kisii'> Kisii</option>
                        <option value='Kisumu'> Kisumu</option>
                        <option value='Kwale'> Kwale</option>
                        <option value='Laikipia'> Laikipia</option>
                        <option value='Lamu'> Lamu</option>
                        <option value='Machakos'> Machakos</option>
                        <option value='Makueni'> Makueni</option>
                        <option value='Mandera'> Mandera</option>
                        <option value='Meru'> Meru</option>
                        <option value='Migori'> Migori</option>
                        <option value='Marsabit'> Marsabit</option>
                        <option value='Mombasa'> Mombasa</option>
                        <option value='Muranga'> Muranga</option>
                        <option value='Nairobi'> Nairobi</option>
                        <option value='Nakuru'> Nakuru</option>
                        <option value='Nandi'> Nandi</option>
                        <option value='Narok'> Narok</option>
                        <option value='Nyamira'> Nyamira</option>
                        <option value='Nyandarua'> Nyandarua</option>
                        <option value='Nyeri'> Nyeri</option>
                        <option value='Samburu'> Samburu</option>
                        <option value='Siaya'> Siaya</option>
                        <option value='Taita Taveta'> Taita Taveta</option>
                        <option value='Tana River'> Tana River</option>
                        <option value='Tharaka Nithi'> Tharaka Nithi</option>
                        <option value='Trans Nzoia'> Trans Nzoia</option>
                        <option value='Turkana'> Turkana</option>
                        <option value='Uasin Gishu'> Uasin Gishu</option>
                        <option value='Vihiga'> Vihiga</option>
                        <option value='Wajir'> Wajir</option>
                        <option value='West Pokot'> West Pokot</option>
                   </select>
       </div>
       </div>
     






                        <div class="form-group">
                            <div class="col-md-6 col-md-offset-4">
                                <button type="submit" class="btn btn-primary">
                                    <i class="fa fa-btn fa-user"></i> Register
                                </button>

                                

                            </div>
                        </div>
                    </form>
       
@endsection
