@extends('layouts.theme')
@section('content')

<div class="row wrapper border-bottom white-bg page-heading">
                <div class="col-lg-10">
                    <h2>Businesses</h2>
                    <ol class="breadcrumb">
                        <li>
                            <a href="index.html">Home</a>
                        </li>
                        <li>
                            <a>Businesses</a>
                        </li>
                        <li class="active">
                            <strong>Create</strong>
                        </li>
                    </ol>
                </div>
                <div class="col-lg-2">

          </div>
</div>


<div class="wrapper wrapper-content animated fadeInRight">
            <div class="row">
                <div class="col-lg-12">
                <div class="ibox float-e-margins">
                    <div class="ibox-title">
                        <h5>Add a Business</h5>                       

                        <div class="ibox-tools">

                    @if(Auth::user()->role=='Agent')

                        <a class="btn btn-primary" href="{{ route('users.index') }}"> Back</a>
                    @else
                        <a class="btn btn-primary" href="{{ route('business.index') }}"> Back</a>
                    @endif

                            <a class="collapse-link">
                                <i class="fa fa-chevron-up"></i>
                            </a>
                            <a class="dropdown-toggle" data-toggle="dropdown" href="#">
                                <i class="fa fa-wrench"></i>
                            </a>
                            <ul class="dropdown-menu dropdown-user">
                                <li><a href="#">Config option 1</a>
                                </li>
                                <li><a href="#">Config option 2</a>
                                </li>
                            </ul>
                            <a class="close-link">
                                <i class="fa fa-times"></i>
                            </a>
                        </div>
                    </div>
                    <div class="ibox-content">


                    @if (count($errors) > 0)
     <div class="alert alert-danger">
        <strong>Whoops!</strong> There were some problems with your input.<br><br>
    <ul>
      @foreach ($errors->all() as $error)
        <li>{{ $error }}</li>
      @endforeach
  </ul>
    </div>
@endif

  {!! Form::open(array('route' => 'business.store','method'=>'POST','files'=>'true')) !!}
<div class="row">
     
    @if(Auth::user()->role=='Owner')
    <input type="hidden" name="owner_id" value="{{Auth::user()->id}}" />

    @else

    <input type="hidden" name="owner_id" value="{{$owner_id}}" />
    @endif

    <div class="col-xs-4 col-sm-4 col-md-4">

            <div class="form-group">
                <strong>Business Name:</strong>
          {!! Form::text('business_name', null, array('placeholder' => 'Name','class' => 'form-control',required)) !!}

            </div>

        </div>

         <div class="col-xs-4 col-sm-4 col-md-4">

            <div class="form-group">
                <strong> Category:</strong>
            <select name="category"  data-placeholder="Choose a Category.." class="chosen-select"  tabindex="2" required="">
            @foreach($categories as $cat)
              
              <option value="{{$cat->id}}">{{$cat->name}}</option>

            @endforeach
          </select>

            </div>

        </div>

         <div class="col-xs-4 col-sm-4 col-md-4">

            <div class="form-group">
                <strong> Business Phone:</strong>
          {!! Form::text('business_phone', null, array('placeholder' => 'Business Phone','class' => 'form-control')) !!}

            </div>

        </div>

      <div class="col-xs-4 col-sm-4 col-md-4">

            <div class="form-group">

                <strong>Business Email:</strong>

                {!! Form::email('business_email', null, array('placeholder' => 'Email','class' => 'form-control')) !!}

            </div>

        </div>

         <div class="col-xs-4 col-sm-4 col-md-4">

            <div class="form-group">

                <strong>Business Location:</strong>

                {!! Form::text('street_address', null, array('placeholder' => 'Address','class' => 'form-control')) !!}

            </div>

        </div>

       <div class="col-xs-4 col-sm-4 col-md-4">

            <div class="form-group">

                <strong>Town:</strong>

                {!! Form::text('town', null, array('placeholder' => 'Town','class' => 'form-control')) !!}

            </div>

        </div>

        <div class="col-xs-4 col-sm-4 col-md-4">

            <div class="form-group">
                <strong> County:</strong>
          <select name="county" class="chosen-select"  tabindex="2" required="">
            @foreach($counties as $county)
              
              <option value="{{$county->id}}">{{$county->county_name}}</option>

            @endforeach
          </select>

            </div>

        </div>

        <div class="col-xs-4 col-sm-4 col-md-4">

            <div class="form-group">

                <strong>Business Description:</strong>

                {!! Form::text('business_description', null, array('placeholder' => 'Business description','class' => 'form-control')) !!}

            </div>

        </div>

 <div class="col-xs-4 col-sm-4 col-md-4">

            <div class="form-group">

                <strong>Operations Since:</strong>

                {!! Form::text('operations_since', null, array('placeholder' => 'Operations Since','class' => 'form-control daily')) !!}

            </div>

        </div>
         <div class="col-xs-4 col-sm-4 col-md-4">

            <div class="form-group">

                <strong>Certificate Number:</strong>

                {!! Form::text('certificate_no', null, array('placeholder' => 'Certificate No','class' => 'form-control')) !!}

            </div>

        </div>
        <div class="col-xs-4 col-sm-4 col-md-4">

            <div class="form-group">

                <strong> Copy of Certificate:</strong>

                {!! Form::file('thefile', null, array('placeholder' => 'Certificate No','class' => 'form-control')) !!}

            </div>

        </div>

        <div class="col-xs-4 col-sm-4 col-md-4">

            <div class="form-group">

                <strong> Business Image:</strong>

                {!! Form::file('img', null, array('placeholder' => 'Image','class' => 'form-control')) !!}

            </div>

        </div>




     


       
        <div class="col-md-12 text-center">
      
        <button type="submit" class="btn btn-primary">Submit</button>

        </div>

  </div>

  {!! Form::close() !!}
  </div></div></div></div></div>

  <script>

        $('.chosen-select').chosen({width: "100%"});

    </script>

@endsection





























