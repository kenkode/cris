@extends('layouts.theme')
@section('content')

<?php use App\Http\Controllers\Controller;?>

     <div class="row wrapper border-bottom white-bg page-heading">
                <div class="col-lg-10">
                    <h2>Businesses</h2>
                    <ol class="breadcrumb">
                        <li>
                            <a href="index.html">Home</a>
                        </li>
                        <li>
                            <a>Businesses</a>
                        </li>
                        <li class="active">
                            <strong>All</strong>
                        </li>
                    </ol>
                </div>
                <div class="col-lg-2">

                </div>
      </div>
            
            
        <div class="wrapper wrapper-content animated fadeInRight">
            <div class="row">
                <div class="col-lg-12">
                <div class="ibox float-e-margins">
                    <div class="ibox-title">

                      @if ($message = Session::get('success'))
                       <div class="alert alert-success">
                         <p>{{ $message }}</p>
                         </div>
                        @endif

                        <h5>Businesses</h5>                      
             

                        <div class="ibox-tools">

                          @if(Auth::user()->role=='Owner')

                        <a class="btn btn-primary" href="{{ route('business.create') }}"> Add a business</a>

                          @else

                          <a class="btn btn-primary" href="{{ route('users.index') }}"> Add a business</a>

                          @endif
                            <a class="collapse-link">
                                <i class="fa fa-chevron-up"></i>
                            </a>
                            <a class="dropdown-toggle" data-toggle="dropdown" href="#">
                                <i class="fa fa-wrench"></i>
                            </a>
                            <ul class="dropdown-menu dropdown-user">
                                <li><a href="#">Config option 1</a>
                                </li>
                                <li><a href="#">Config option 2</a>
                                </li>
                            </ul>
                            <a class="close-link">
                                <i class="fa fa-times"></i>
                            </a>
                        </div>
                    </div>
                    <div class="ibox-content">

                        <div class="table-responsive">
                    <table class="table table-striped table-bordered table-hover dataTables-example" >
                    <thead>
                      <tr>
                       
                        <th>Business Name</th>
                        <th>Category</th>
                        <th>Phone</th>
                        <th>Town</th>
                        <th>Address</th>
                        <th>Verified By</th>

                       
                        <th width="280px">Action</th>
                      </tr>
                    </thead>
                    <tbody>
                    @foreach ($businesses as $business)
                      <tr>
                         
                          <td>{{ $business->business_name }}   <span class="pull-right label label-danger">Dislikes: {{controller::dislikes($business->id)}}</span>
                                <span class="pull-right label label-primary"> Likes: {{controller::likes($business->id)}}</span>
                           </td>
                          <td>{{ Controller::category_name($business->category)}}</td>
                          <td>{{ $business->business_phone }}</td>
                          <td>{{ $business->town }}</td>
                          <td>{{ $business->street_address }}</td>
                          <td>{{ Controller::user_name($business->verified) }}</td>
                          <td>
                          <a class="btn btn-info" href="{{ route('business.show',$business->id) }}">Details</a>
                          <a class="btn btn-primary" href="{{ route('business.edit',$business->id) }}">Edit</a>

                              @if(Auth::user()->role!='Owner' && $business->verified==0)
                              <a class="btn btn-warning" href="{{ url('verify',$business->id) }}">Verify</a>
                              @endif

                           @if(Auth::user()->role!='Agent')
{!! Form::open(['method' => 'DELETE','route' => ['business.destroy', $business->id],'style'=>'display:inline', 'onsubmit' => 'return ConfirmDelete()']) !!}
                         {!! Form::submit('Delete', ['class' => 'btn btn-danger']) !!}
                          {!! Form::close() !!}

                          @endif


                         </td>

                        </tr>

                        @endforeach
                    
                    </tfoot>
                    </table>
                        </div>                      

                    </div>
                </div>
            </div>
            </div>
        </div>
        

@endsection
