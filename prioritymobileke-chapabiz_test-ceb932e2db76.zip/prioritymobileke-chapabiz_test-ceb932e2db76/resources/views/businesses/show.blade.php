@extends('layouts.theme')
@section('content')

<?php use App\Http\Controllers\Controller;?>

<div class="row wrapper border-bottom white-bg page-heading">
                <div class="col-lg-10">
                    <h2>Business</h2>
                    <ol class="breadcrumb">
                        <li>
                            <a href="index.html">Home</a>
                        </li>
                        <li>
                            <a>Business</a>
                        </li>
                        <li class="active">
                            <strong>Show</strong>
                        </li>
                    </ol>
                </div>
                <div class="col-lg-2">

          </div>
</div>



<div class="wrapper wrapper-content animated fadeInRight">

         <div class="row">
                <div class="col-lg-12">

                    <div class="ibox product-detail">
                        <div class="ibox-content">

                            <div class="row">
                                <div class="col-md-5">


                                    <div class="product-images">

                                        <div>
                                            @if($business->img==''||$business->img==1)
                                              <img src="{{asset('images/default_business.png')}}">
                                            @else
                                            <img src="{{asset($business->img)}}">
                                            @endif
                                        </div>
                                       
                                    </div>

                                </div>
                                <div class="col-md-7">

                                    <h2 class="font-bold m-b-xs">
                                       {{$business->business_name}}
                                    </h2>
                                    @if($business->verified==0)<span class="label label-warning">Not verified</span>
                                    @else <span class="label label-primary">Verified</span>@endif
                      &nbsp<small>Business number :<strong>{{$business->certificate_no}}  &nbsp @if($business->certificate_copy!=1)<a href="{{asset($business->certificate_copy)}}"> Download Certificate</a>@endif
                      </strong></small>
                                    <hr>
                                    <div>
                            <a class="btn btn-info btn-xs" href="{{ URL::previous() }}"> Back</a>
                        
                            <a class="btn btn-primary btn-xs" href="{{ route('business.edit',$business->id) }}">Edit</a>

                              @if(Auth::user()->role!='Owner' && $business->verified==0)
                              <a class="btn btn-warning btn-xs" href="{{ url('verify',$business->id) }}">Verify</a>
                              
                              @endif

                           @if(Auth::user()->role!='Agent')
                         {!! Form::open(['method' => 'DELETE','route' => ['business.destroy', $business->id],'style'=>'display:inline']) !!}
                         {!! Form::submit('Delete', ['class' => 'btn btn-danger btn-xs']) !!}
                          {!! Form::close() !!}

                          @endif
                               
                               @if(Auth::user()->role!='Owner')   
                                   <a class="btn btn-primary btn-xs" href="{{ url('like?bus='.$business->id) }}">Like</a>

                                  <a class="btn btn-danger btn-xs" href="{{ url('dislike?bus='.$business->id) }}">Dislike</a>@endif 
                            <span class="pull-right label label-danger">Dislikes: {{controller::dislikes($business->id)}}</span>
                                <span class="pull-right label label-primary"> Likes: {{controller::likes($business->id)}}</span>
                           
                                    
                                    </div>
                                    <hr>

                           <strong>Owner :</strong> {{Controller::user_name($business->owner_id)}}
                                       <hr>
                          <h4>Business description</h4>

                                    <div class="small text-muted">
                                       {{$business->business_description}}
                                    </div>

                                    <dt>Operations since</dt>
                                        <dd>{{$business->operations_since}}</dd>
                                    <dl class="dl-horizontal m-t-md small col-md-6" style="text-align:left;">
                                        <dt>Business Category </dt>
                                        <dd>{{Controller::category_name($business->category)}}</dd><br>

                                        <dt>Business Phone</dt>
                                        <dd>{{$business->business_phone}}</dd><br>

                                        <dt>Business Email</dt>
                                        <dd>{{$business->business_email}}</dd><br>

                                       

                                        
                                    </dl>

                                       <dl class="dl-horizontal m-t-md small col-md-6" style="text-align:left;">
                                  
                                        <dt>Street Address </dt>
                                        <dd>{{$business->street_address}}</dd><br>

                                        <dt> Town </dt>
                                        <dd>{{$business->town}}</dd><br>

                                        <dt>County</dt>
                                        <dd>{{Controller::county_name($business->county)}}</dd><br>

                                        
                                    </dl>


                                </div>
                            </div>

                        </div>
                        <div class="ibox-footer">
                            
                        </div>
                    </div>

                </div>
            </div>






@endsection
