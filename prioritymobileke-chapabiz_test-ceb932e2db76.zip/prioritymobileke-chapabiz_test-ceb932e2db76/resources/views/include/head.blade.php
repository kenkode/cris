<meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="csrf-token" content="{{ csrf_token() }}">
    <title>{{ config('app.name', 'Api') }}</title>

    <link href="{{ asset('theme/css/bootstrap.min.css') }}" rel="stylesheet">
    <link href="{{ asset('theme/font-awesome/css/font-awesome.css') }}" rel="stylesheet">
    <link rel="stylesheet" href="{{ asset('theme/css/dataTables/datatables.min.css') }}" />

    <!-- Morris -->
    <link href="{{ asset('theme/css/plugins/morris/morris-0.4.3.min.css') }}" rel="stylesheet">

    <link href="{{ asset('theme/css/animate.css') }}" rel="stylesheet">
    <link href="{{ asset('theme/css/style.css') }}" rel="stylesheet">

    <link href="{{ asset('theme/css/plugins/iCheck/custom.css') }}" rel="stylesheet">

    <link href="{{ asset('theme/css/plugins/fullcalendar/fullcalendar.css') }}" rel="stylesheet">
    <link href="{{ asset('theme/css/plugins/fullcalendar/fullcalendar.print.css') }}" rel='stylesheet' media='print'>


    <link href="{{ asset('theme/css/plugins/dropzone/basic.css') }}" rel="stylesheet">
    <link href="{{ asset('theme/css/plugins/dropzone/dropzone.css') }}" rel="stylesheet">
    <link href="{{ asset('theme/css/plugins/jasny/jasny-bootstrap.min.css') }}" rel="stylesheet">
    <link href="{{ asset('theme/css/plugins/codemirror/codemirror.css') }}" rel="stylesheet">

     <link href="{{ asset('theme/css/bootstrap.min.css') }}" rel="stylesheet">
    <link href="{{ asset('theme/font-awesome/css/font-awesome.css') }}" rel="stylesheet">

    <!-- Morris -->
    <link href="{{ asset('theme/css/plugins/morris/morris-0.4.3.min.css') }}" rel="stylesheet">

     <link href="{{ asset('theme/css/plugins/summernote/summernote.css') }}" rel="stylesheet">
    <link href="{{ asset('theme/css/plugins/summernote/summernote-bs3.css') }}" rel="stylesheet">

    <link href="{{ asset('theme/css/animate.css') }}" rel="stylesheet">
    <link href="{{ asset('theme/css/style.css') }}" rel="stylesheet">



    <link href="{{ asset('theme/css/plugins/iCheck/custom.css') }}" rel="stylesheet">

    <link href="{{ asset('theme/css/plugins/fullcalendar/fullcalendar.css') }}" rel="stylesheet">
    <link href="{{ asset('theme/css/plugins/fullcalendar/fullcalendar.print.css') }}" rel='stylesheet' media='print'>


    <link href="{{ asset('theme/css/plugins/steps/jquery.steps.css') }}" rel="stylesheet">


    <link href="{{ asset('theme/css/plugins/chosen/bootstrap-chosen.css') }}" rel="stylesheet">

    <link href="{{ asset('theme/css/plugins/bootstrap-tagsinput/bootstrap-tagsinput.css') }}" rel="stylesheet">

    <link href="{{ asset('theme/css/plugins/colorpicker/bootstrap-colorpicker.min.css') }}" rel="stylesheet">

    <link href="{{ asset('theme/css/plugins/cropper/cropper.min.css') }}" rel="stylesheet">

    <link href="{{ asset('theme/css/plugins/switchery/switchery.css') }}" rel="stylesheet">

    <link href="{{ asset('theme/css/plugins/jasny/jasny-bootstrap.min.css') }}" rel="stylesheet">

    <link href="{{ asset('theme/css/plugins/nouslider/jquery.nouislider.css') }}" rel="stylesheet">

    <link href="{{ asset('theme/css/plugins/datapicker/datepicker3.css') }}" rel="stylesheet">

    <link href="{{ asset('theme/css/plugins/ionRangeSlider/ion.rangeSlider.css') }}" rel="stylesheet">
    <link href="{{ asset('theme/css/plugins/ionRangeSlider/ion.rangeSlider.skinFlat.css') }}" rel="stylesheet">

    <link href="{{ asset('theme/css/plugins/awesome-bootstrap-checkbox/awesome-bootstrap-checkbox.css') }}" rel="stylesheet">

    <link href="{{ asset('theme/css/plugins/clockpicker/clockpicker.css') }}" rel="stylesheet">

    <link href="{{ asset('theme/css/plugins/daterangepicker/daterangepicker-bs3.css') }}" rel="stylesheet">

    <link href="{{ asset('theme/css/plugins/select2/select2.min.css') }}" rel="stylesheet">

    <link href="{{ asset('theme/css/plugins/touchspin/jquery.bootstrap-touchspin.min.css') }}" rel="stylesheet">

    <link href="{{ asset('theme/css/plugins/dualListbox/bootstrap-duallistbox.min.css') }}" rel="stylesheet">

    <link href="{{ asset('theme/css/plugins/morris/morris-0.4.3.min.css') }}" rel="stylesheet">


    @yield('styles')

    <script>
        window.Laravel = {!! json_encode([
            'csrfToken' => csrf_token(),
        ]) !!};
    </script>
