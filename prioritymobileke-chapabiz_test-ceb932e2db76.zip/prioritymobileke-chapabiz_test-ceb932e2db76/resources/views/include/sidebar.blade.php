 <?php 

    use App\Http\Controllers\UserController;
   

    ?>

 <li class="active">
<a href="{{ url('/login') }}"><i class="fa fa-th-large"></i> <span class="nav-label">Dashboard</span> </a> </li>

@if(Auth::user()->role=='Administrator')
<li><a href="{{ url('/roles') }}"><i class="fa fa-pencil"></i> <span class="nav-label">Roles</span> </a> </li>
<li><a href="{{ url('/users') }}"><i class="fa fa-users"></i> <span class="nav-label">Users</span> </a> </li> 
<li><a href="{{ url('/business') }}"><i class="fa fa-building"></i> <span class="nav-label">Businesses</span> </a> </li>

<li>
    <a href="#"><i class="fa fa-money"></i> <span class="nav-label">Invoices</span><span class="fa arrow"></span></a>
    <ul class="nav nav-second-level collapse">
        <li><a href="{{ url('/paid-invoices') }}">Paid</a></li>
        <li><a href="{{ url('/unpaid-invoices') }}">Unpaid</a></li>
      
    </ul>
</li>


<li><a href="{{ url('/receipts') }}"><i class="fa fa-money"></i> <span class="nav-label">Receipts</span> </a> </li>
<li><a href="{{ url('/categories') }}"><i class="fa fa-pencil"></i> <span class="nav-label">Categories</span> </a> </li>
<li>
    <a href="#"><i class="fa fa-thumbs-up"></i> <span class="nav-label">User Rating</span><span class="fa arrow"></span></a>
    <ul class="nav nav-second-level collapse">
        <li><a href="{{ url('/ratings') }}">Likes/Dislikes</a></li>
      
    </ul>
</li>

<li><a href="{{ url('/ccare') }}"><i class="fa fa-envelope"></i> <span class="nav-label">Customer Care</span> </a> </li>
<li><a href="{{ url('/chat-login') }}"><i class="fa fa-envelope"></i> <span class="nav-label">Chat support</span> </a> </li>

<li><a href="{{ url('/messages') }}"><i class="fa fa-envelope"></i> <span class="nav-label">Messages</span> </a> </li>
<li><a href="{{ url('/settings') }}"><i class="fa fa-gears"></i> <span class="nav-label">Admin Settings</span> </a> </li>

@endif

@if(Auth::user()->role=='Agent') 

 <li><a href="{{ url('/business') }}"><i class="fa fa-building"></i> <span class="nav-label">Businesses</span> </a> </li> 
 <li><a href="{{ url('/categories') }}"><i class="fa fa-pencil"></i> <span class="nav-label">Categories</span> </a> </li>

 @endif 
  
@if(Auth::user()->role=='Owner') 

 <li><a href="{{ url('/business') }}"><i class="fa fa-building"></i> <span class="nav-label"> My Businesses</span> </a> </li>
 <li><a href="{{ url('/my-invoices') }}"><i class="fa fa-money"></i> <span class="nav-label">Invoices</span> </a> </li>
 <li><a href="{{ url('/my-receipts') }}"><i class="fa fa-money"></i> <span class="nav-label">Receipts</span> </a> </li> 
 <li><a href="{{ url('/ccare') }}"><i class="fa fa-envelope"></i> <span class="nav-label">Customer Care</span> </a> </li>
<li><a href="{{ url('/messages') }}"><i class="fa fa-envelope"></i> <span class="nav-label">Messages</span> </a> </li>
@endif


<li>
<a href="{{ url('/logout') }}"
    onclick="event.preventDefault();
             document.getElementById('logout-form').submit();">
 <i class="fa fa-sign-out"></i><span>Logout</span>
</a>

<form id="logout-form" action="{{ url('/logout') }}" method="POST" style="display: none;">
    {{ csrf_field() }}
</form>
</li>

   
