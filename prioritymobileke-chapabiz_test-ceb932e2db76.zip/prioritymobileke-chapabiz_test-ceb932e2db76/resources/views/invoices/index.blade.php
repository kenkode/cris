@extends('layouts.theme')

@section('style')
@endsection

@section('content')

<?php use App\Http\Controllers\Controller; ?>

     <div class="row wrapper border-bottom white-bg page-heading">
                <div class="col-lg-10">
                    <h2>Invoices</h2>
                    <ol class="breadcrumb">
                        <li>
                            <a href="">Home</a>
                        </li>
                        <li>
                            <a>Invoices</a>
                        </li>
                        <li class="active">
                            <strong>@if($invoices->first( )) {{$invoices[0]->status}} @endif</strong>
                        </li>
                    </ol>
                </div>
                <div class="col-lg-2">

                </div>
      </div>


        <div class="wrapper wrapper-content animated fadeInRight">
            <div class="row">
                <div class="col-lg-12">
                <div class="ibox float-e-margins">
                    <div class="ibox-title">

                      @if ($message = Session::get('success'))
                       <div class="alert alert-success">
                         <p>{{ $message }}</p>
                         </div>
                        @endif

                        <h5>Invoices</h5>


                        <div class="ibox-tools">


                            <a class="collapse-link">
                                <i class="fa fa-chevron-up"></i>
                            </a>
                            <a class="dropdown-toggle" data-toggle="dropdown" href="#">
                                <i class="fa fa-wrench"></i>
                            </a>
                            <ul class="dropdown-menu dropdown-user">
                                <li><a href="#">Config option 1</a>
                                </li>
                                <li><a href="#">Config option 2</a>
                                </li>
                            </ul>
                            <a class="close-link">
                                <i class="fa fa-times"></i>
                            </a>
                        </div>
                    </div>
                    <div class="ibox-content">
                      <div class="table-responsive">
                    <table class="table table-striped table-bordered table-hover invoices" >

                    <thead>
                      <tr>

                        <th>Id</th>
                        <th>Invoicee</th>
                        <th>Amount</th>
                        <th>Balance</th>
                        <th>Action</th>
                      </tr>
                    </thead>
                    <tbody>
                      <?php $amount=0; $balance=0;?>
                    @foreach ($invoices as $invoice)
                      <tr>

                          <td>{{ $invoice->id}}</td>
                          <td>{{ Controller::user_name($invoice->user_id)}}</td>
                          <td>Ksh :{{number_format($invoice->amount,2)}}</td>
                          <td>Ksh :{{number_format( $invoice->balance,2)}}</td>
                          <td>

                          <a class="btn btn-primary" href="{{ route('invoices.show',$invoice->id) }}">View</a>

                         </td>

                        </tr>
                        <?php $amount+=$invoice->amount; $balance+=$invoice->balance;?>
                        @endforeach
                    <tbody>
                    <tfoot>
                      <tr>

                        <th colspan="2">Total</th>
                        <th>Ksh :{{number_format($amount,2)}}</th>
                        <th>Ksh :{{number_format($balance,2)}}</th>
                        <th></th>
                      </tr>
                    </tfoot>
                    </table>
                        </div>

                    </div>
                </div>
            </div>
            </div>
        </div>
@endsection
@section('script')
        <script>
              $(document).ready(function(){
                  $('.invoices').DataTable({
                      pageLength: 25,
                      responsive: true,
                      dom: '<"html5buttons"B>lTfgitp',
                      buttons: [
                          { extend: 'copy'},
                          {extend: 'csv'},
                          {extend: 'excel', title: 'ExampleFile'},
                          {extend: 'pdf', title: 'ExampleFile'},

                          {extend: 'print',
                           customize: function (win){
                                  $(win.document.body).addClass('white-bg');
                                  $(win.document.body).css('font-size', '10px');

                                  $(win.document.body).find('table')
                                          .addClass('compact')
                                          .css('font-size', 'inherit');
                          }
                          }
                      ]

                  });

              });

          </script>

@endsection
