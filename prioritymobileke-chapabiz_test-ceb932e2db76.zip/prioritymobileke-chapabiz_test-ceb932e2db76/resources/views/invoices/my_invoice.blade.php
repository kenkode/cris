@extends('layouts.theme')
@section('content')

<?php use App\Http\Controllers\Controller; ?>

<div class="wrapper wrapper-content animated fadeInRight">
            <div class="row">
                <div class="col-lg-12">
                <div class="ibox float-e-margins">
                    <div class="ibox-title">
                                            

                        <div class="ibox-tools">
                      
                         <a class="btn btn-primary" href="{{ url('my-invoices') }}"> Back</a>
                      

                        </div>
                    </div>
                    <div class="ibox-content">

                         <div class="row">

                  <div class="table-responsive">

                     
                    <table class="table table-bordered table-hover invoice" > 

                    <div style="float:left; width:350px;">
                      <img src="{{asset(config('app.logo', '')) }}" style="width:150px;">
                      <p>Address</p>
                      <p>Phone:</p>
                      <strong>Billed To</strong>
                      <?php $user= Controller::user_by_id($invoice->user_id); ?>
                      <p>{{$user->first_name}} {{$user->last_name}}</p>
                      <p>Email :{{$user->email}}</p>
                     
                    </div>

                    <div style="float:right; width:200px;margin-top:30px; text-align: right;">
                       <h1>Invoice</h1>
                        <strong>Invoince # : </strong>{{$invoice->id}}<br>
                         <strong>Date: </strong>{{$invoice->created_at}}<br>
                        <strong> Due Date: </strong>{{$invoice->created_at}}
                    </div>                  
                   
                      <thead>
                     

                       <tr>
                       
                        <th >Description</th>
                        <th style="text-align:right;">Rate</th>
                        <th style="text-align:right;">Quantity</th>
                        <th style="text-align:right;">Amount</th> 
                      </tr>
                    </thead>

                    <tbody>

                     
                     

                      <tr>
                         
                          <td >{{Controller::businessname($invoice->business_id)}}</td>
                          <td style="text-align:right;">Ksh: {{number_format($invoice->amount,2)}}</td>
                          <td style="text-align:right;">1</td>
                          <td style="text-align:right;">Ksh: {{number_format($invoice->amount,2)}}</td>                        

                        </tr>



                         <tr>
                         
                          <td style="text-align:right;"></td>
                          <td style="text-align:right;"></td>
                          <td style="text-align:right;">Total</td>
                          <td style="text-align:right;">Ksh: {{number_format($invoice->amount,2)}}</td>                        

                        </tr>

                        <?php

                          $vat=(16/100)*$invoice->amount;

                         $paid=$invoice->amount+$vat-$invoice->balance; 


                        ?>?>

                     
                        <tr>
                         
                          <td style="text-align:right;"></td>
                          <td style="text-align:right;"></td>
                          <td style="text-align:right;">VAT (16%)</td>
                          <td style="text-align:right;">Ksh: {{number_format($vat,2)}}</td>                        

                        </tr>

                        <tr>
                         
                          <td style="text-align:right;"></td>
                          <td style="text-align:right;"></td>
                          <td style="text-align:right;">Amount Paid</td>
                          <td style="text-align:right;">Ksh: {{number_format($paid,2)}}</td>                        

                        </tr>
                    </tbody>
                    <tfoot>
                        <th  style="text-align:right;"></th>
                        <th  style="text-align:right;"></th>
                        <th  style="text-align:right;"> Total Due</th>
                        
                        <th style="text-align:right;">Ksh: {{number_format($invoice->balance,2)}}</th> 

                    </tfoot>
                    </table>
                  </div>                      

                           
                          </div>
                    </div>
                    
                </div>
            </div>
            </div>
  </div>

<script>

$('.invoice').DataTable({  
  responsive: true,
  filter:false,
  paging:false,
  sort:false,
  info:false,
  "bLengthChange": false,
  dom: '<"html5buttons"B>lTfgitp',
  buttons: [                   
     {extend: 'print',
     footer: true,
            exportOptions: {
                columns: ':visible'
                 },
       customize: function (win){
              $(win.document.body).addClass('white-bg');
               $(win.document.body).css('font-size', '10px') 
                            .prepend(' <div style="float:left; width:350px;"><img src="{{asset(config('app.logo', '')) }}" style="width:150px;"> <p>Address</p><p>Phone:</p><strong>To</strong><p>{{$user->first_name}} {{$user->last_name}}</p><p>Email :{{$user->email}}</p></div><div style="float:right; width:200px;margin-top:30px; text-align: right;"><h1>Invoice</h1><strong>Invoince # : </strong>{{$invoice->amount}}<br><strong>Date: </strong>{{$invoice->created_at}}</div> '); 

              $(win.document.body).find('table')
                      .addClass('compact')
                      .css('font-size', 'inherit');

      },title: ''
      }
  ]
});
</script>

@endsection
