<!DOCTYPE html>
<html>

<head>

    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

   <title>{{ config('app.name', 'SMS') }}</title>

    <link href="{{asset('theme/css/bootstrap.min.css') }}" rel="stylesheet">
    <link href="{{asset('theme/font-awesome/css/font-awesome.css') }}" rel="stylesheet">

    <link href="{{asset('theme/css/animate.css') }}" rel="stylesheet">
    <link href="{{asset('theme/css/style.css') }}" rel="stylesheet">

</head>

<body class="gray-bg">
<div class="navbar-wrapper">
        
</div>


    <div class="loginColumns animated fadeInDown">
        <div class="row" style="text-align: center;">
 
           
            <div class="col-md-6 col-md-offset-3">

    <img src="{{asset('images/logo-vert.png')}}"  style="width:100px">

<h3>{{ config('app.tagline', 'SMS') }}</h3>
                <div class="ibox-content">

             
                      @yield('content')

                    
                </div>
            </div>
        </div>
        <hr/>
        <div class="row">
            <div class="col-md-6 col-md-offset-3">
            
        </div>
    </div>

</body>

</html>                   
    