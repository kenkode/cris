<!DOCTYPE html>
<html>

<head>

    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

   <title>{{ config('app.name', 'Api') }}</title>

    <link href="{{asset('theme/css/bootstrap.min.css') }}" rel="stylesheet">
    <link href="{{asset('theme/font-awesome/css/font-awesome.css') }}" rel="stylesheet">

    <link href="{{asset('theme/css/animate.css') }}" rel="stylesheet">
    <link href="{{asset('theme/css/style.css') }}" rel="stylesheet">

</head>

<body class="gray-bg">
<div class="navbar-wrapper">
        <nav class="navbar navbar-fixed-top" role="navigation">
            <div class="container">
                <div class="navbar-header page-scroll">
                    <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#navbar" aria-expanded="false" aria-controls="navbar">
                        <span class="sr-only">Toggle navigation</span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                    </button>
                    <a href="{{url('/')}}"><img src="{{asset('images/ke.gif')}}" alt="Company Name" class="logo" width="70"></a>

                </div>
                <div id="navbar" class="navbar-collapse collapse">
                    <ul class="nav navbar-nav navbar-right">
                        <li><a class="page-scroll" href="{{url('/')}}">Home</a></li>
                     
                               
                
                    @if (Auth::check())

                    <li class="dropdown">
                    <a class="dropdown-toggle count-info" data-toggle="dropdown" href="#">{{ Auth::user()->name }}</a>
                    <ul class="dropdown-menu">
                        
                        
                        <li class="divider"></li>
                        @if(Auth::user()->role="admin")
                        <li><a href="{{ url('/home') }}">My Account</a></li>
                        @else
                        <li><a href="{{ url('/dashboard') }}">My Account</a></li>
                        @endif
                        <li class="divider"></li>

                         <li>
                                        <a href="{{ url('/logout') }}"
                                            onclick="event.preventDefault();
                                                     document.getElementById('logout-form').submit();">
                                            Logout
                                        </a>

                                        <form id="logout-form" action="{{ url('/logout') }}" method="POST" style="display: none;">
                                            {{ csrf_field() }}
                                        </form>
                                    </li>
                    </ul>
                    </li>
                        
                    @else
                       <li> <a href="{{ url('/login') }}">Login</a> </li>
                    @endif
                
                  
                    </ul>
                </div>
            </div>
        </nav>
</div>


    <div class="loginColumns animated fadeInDown">
        <div class="row">

           
            <div class="col-md-10 col-md-offset-1">
                <div class="ibox-content">


                      @yield('content')

                    
                </div>
            </div>
        </div>
        <hr/>
        <div class="row">
            <div class="col-md-6 col-md-offset-4">
                Copyright &copy; prioritymobile.co.ke <?PHP echo date("Y",time()) ;?>
            </div>
            
        </div>
    </div>

</body>

</html>                   
    