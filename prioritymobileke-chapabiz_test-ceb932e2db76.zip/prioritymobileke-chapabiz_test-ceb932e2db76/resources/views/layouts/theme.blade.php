<?php 

    use App\Http\Controllers\UserController;
    use App\Http\Controllers\Controller;

?>
<!DOCTYPE html>
<html>

<head>
@include('include.head')   

</head>

<body>
    <div id="wrapper">
    <nav class="navbar-default navbar-static-side" role="navigation">
        <div class="sidebar-collapse">
            <ul class="nav metismenu" id="side-menu">
                <li class="nav-header">
                     <?php $email= Auth::user()->email;?>
                <div class="dropdown profile-element"> <span>
                <img alt="image" class=" m-t-xs img-responsive" src="{{asset('images/logo-vert.png')}}" style="width:80px;" />
                             </span>
                    <a data-toggle="dropdown" class="dropdown-toggle" href="#">
                            <span class="clear"> <span class="block m-t-xs"> <strong class="font-bold">{{Auth::User()->first_name}} &nbsp {{Auth::User()->last_name}}</strong>
                             </span> <span class="text-muted text-xs block">{{Auth::User()->role}} <b class="caret"></b></span> </span> </a>
                    <ul class="dropdown-menu animated fadeInRight m-t-xs">
                        <li><a href="{{ url('/profile') }}">Profile</a></li>
                        <li><a href="{{ url('/password-edit') }}">Change Password</a></li>
                        <li class="divider"></li>
                        <li><a href="{{ url('/logout') }}"
                        onclick="event.preventDefault();
                                 document.getElementById('logout-form').submit();">
                        Logout
                    </a></li>
                    </ul>
                </div>
                <div class="logo-element">
                    IN+
                </div>
            </li>
                

                 @include('include.sidebar')
                
            </ul>

        </div>
    </nav>

        <div id="page-wrapper" class="gray-bg">
        <div class="row border-bottom">
        <nav class="navbar navbar-static-top white-bg" role="navigation" style="margin-bottom: 0">
        <div class="navbar-header">
            <a class="navbar-minimalize minimalize-styl-2 btn btn-primary " href="#"><i class="fa fa-bars"></i> </a>
            <form role="search" class="navbar-form-custom" action="search_results.html">
                <div class="form-group">
                    <input type="text" placeholder="Search for something..." class="form-control" name="top-search" id="top-search">
                </div>
            </form>
        </div>
            <ul class="nav navbar-top-links navbar-right">
             
                <li>
                    <a href="{{ url('/logout') }}" 
                        onclick="event.preventDefault();
                                 document.getElementById('logout-form').submit();">
                                 <i class="fa fa-sign-out"></i>
                        Logout
                    </a>

                    <form id="logout-form" action="{{ url('/logout') }}" method="POST" style="display: none;">
                        {{ csrf_field() }}
                    </form>
                </li>
                 

            </ul>

        </nav>
        </div>
        @include('flash::message')
        @include('include.footer')


             


               @yield('content')

               
        

       


        <div class="footer">
            
            <div>
               <p><strong>&copy; <?php echo date('Y',time());?> Priority Mobile</strong></p>
            </div>
        </div>

        </div>
       
    </div>
   
   
</body>
</html>

