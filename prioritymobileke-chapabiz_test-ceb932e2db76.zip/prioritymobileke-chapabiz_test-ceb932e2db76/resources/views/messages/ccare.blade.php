@extends('layouts.theme')
@section('content')

<?php use App\Http\Controllers\Controller;?>

    
          
        <div class="wrapper wrapper-content">
        <div class="row">
         
            <div class="col-lg-12 animated fadeInRight">
            <div class="mail-box-header">

                <form method="get" action="index.html" class="pull-right mail-search">
                    <div class="input-group">
                        <input type="text" class="form-control input-sm" name="search" placeholder="Search email">
                        <div class="input-group-btn">
                            <button type="submit" class="btn btn-sm btn-primary">
                                Search
                            </button>
                        </div>
                    </div>
                </form>
                <h2>
                    Compliments and Complains
                </h2>
                <div class="mail-tools tooltip-demo m-t-md">
                    
                  <a href="{{Request::url()}}">  <button class="btn btn-white btn-sm" data-toggle="tooltip" data-placement="left" title="Refresh inbox"><i class="fa fa-refresh"></i> Refresh</button></a>
                 

                </div>
            </div>
                <div class="mail-box">

                <table class="table table-hover table-mail">
                <tbody>                

                 @foreach ($messages as $msg)

                   @if($msg->direction==0)
                <tr class="{{$msg->status}}">
                    <td class="check-mail">
                        <input type="checkbox" class="i-checks">
                    </td>
                    <td class="mail-ontact"><a href="{{route('messages.show',$msg->id)}}">{{ Controller::user_name($msg->user_id)}}</a> 
                     @if($msg->replied==1) <span class="label label-primary pull-right">Replied</span>@endif 
                    </td>
                    <td class="mail-subject"><a href="{{route('messages.show',$msg->id)}}">{{ $msg->msg_title }}</a></td>
                    <td class="text-right mail-date">{{ Controller::businessname($msg->business_id)}}</td>
                    <td class="text-right mail-date">{{ $msg->created_at }}</td>
                </tr>
                   @else

                    <tr class="{{$msg->status}}">
                    <td class="check-mail">
                        <input type="checkbox" class="i-checks">
                    </td>

                    <td class="text-right mail-date">{{ Controller::businessname($msg->business_id)}}</td>
                    
                     @if($msg->replied==1) <span class="label label-primary pull-right">Replied</span>@endif 
                    </td>
                    <td class="mail-subject"><a href="{{route('messages.show',$msg->id)}}">{{ $msg->msg_title }}</a></td>
                    <td class="mail-ontact"><a href="{{route('messages.show',$msg->id)}}">{{ Controller::user_name($msg->user_id)}}</a> 
                    <td class="text-right mail-date">{{ $msg->created_at }}</td>
                </tr>

                   @endif

                @endforeach 


                
                </tbody>
                </table>


                </div>
            </div>
        </div>
        </div>

        

@endsection
