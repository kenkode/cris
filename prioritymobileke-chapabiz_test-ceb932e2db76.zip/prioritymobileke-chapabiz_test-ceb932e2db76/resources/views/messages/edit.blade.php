@extends('layouts.theme')
@section('content')
<?php use App\Http\Controllers\Controller;?>

 <div class="wrapper wrapper-content">
        <div class="row">
          
            <div class="col-lg-12 animated fadeInRight">
            <div class="mail-box-header">
                <div class="pull-right tooltip-demo">
                    
                    <a href="{{URL::previous() }}" class="btn btn-danger btn-sm" data-toggle="tooltip" data-placement="top" title="Discard email"><i class="fa fa-times"></i> Discard</a>
                </div>
                <h2>
                    Reply
                </h2>
            </div>
                <div class="mail-box">

                <div class="mail-body">


{!! Form::model($message, ['method' => 'PATCH','route' => ['messages.update', $message->id],'files'=>'true','class'=>'form-horizontal']) !!} 
                        <div class="form-group"><label class="col-sm-2 control-label">To:</label>

                            <div class="col-sm-10"><input type="text" class="form-control" name="email" value="{{Controller::user_by_id($message->user_id)->email}}"></div>

                        <input type="hidden"  name="user_id" value="{{$message->user_id}}">
                        <input type="hidden"  name="business_id" value="{{$message->business_id}}">
                        <input type="hidden"  name="direction" value="1">
                        </div>
                        <div class="form-group"><label class="col-sm-2 control-label">Subject:</label>

                            <div class="col-sm-10">{!! Form::text('msg_title', null, array('placeholder' => 'subject','class' => 'form-control')) !!}</div>
                        </div>
                      

                </div>

                    <div class="mail-text h-200">

                        <textarea name="msg_body" class="summernote form-control">
                           {!!$message->msg_body!!}

                        </textarea>
<div class="clearfix"></div>
                        </div>
                    <div class="mail-body text-right tooltip-demo">
                        <button  type="submit" class="btn btn-sm btn-primary" data-toggle="tooltip" data-placement="top" title="Send"><i class="fa fa-reply"></i> Send</button>
                        <a href="{{URL::previous() }}" class="btn btn-white btn-sm" data-toggle="tooltip" data-placement="top" title="Discard email"><i class="fa fa-times"></i> Discard</a>
                       
                    </div>
                    <div class="clearfix"></div>


 {!! Form::close() !!}
                </div>
            </div>
        </div>
        </div>


  <script>

        $('.chosen-select').chosen({width: "100%"});

    </script>

@endsection
