@extends('layouts.theme')
@section('content')

<?php use App\Http\Controllers\Controller;?>

 <div class="wrapper wrapper-content">
        <div class="row">
            
            <div class="col-lg-12 animated fadeInRight">
            <div class="mail-box-header">
                <div class="pull-right tooltip-demo">
                    <a href="{{route('messages.edit',$message->id)}}" class="btn btn-white btn-sm" data-toggle="tooltip" data-placement="top" title="Reply"><i class="fa fa-reply"></i> Reply</a>
                   
                    <a href="mailbox.html" class="btn btn-white btn-sm" data-toggle="tooltip" data-placement="top" title="Move to trash"><i class="fa fa-trash-o"></i> </a>
                </div>
                <h2>
                    View Message
                </h2>
                <div class="mail-tools tooltip-demo m-t-md">


                    <h3>
                        <span class="font-normal">Subject: </span>{{$message->msg_title}}
                    </h3>
                    <h5>
                        <span class="pull-right font-normal">{{$message->created_at}}</span>
                        <span class="font-normal">From: </span>{{ Controller::user_name($message->user_id)}}
                    </h5>
                </div>
            </div>
                <div class="mail-box">


                <div class="mail-body">
                    <p>
                        {!!$message->msg_body!!}
                    </p>
                  
                </div>
                 
                        <div class="mail-body text-right tooltip-demo">
                                <a class="btn btn-sm btn-white" href="{{route('messages.edit',$message->id)}}"><i class="fa fa-reply"></i> Reply</a>
                               
                               <a href="{{url('delete-msg',$message->id)}}"> <button  class="btn btn-sm btn-white"><i class="fa fa-trash-o"></i> Remove</button></a>
                        </div>
                        <div class="clearfix"></div>


                </div>
            </div>
        </div>
        </div>


@endsection
